# TradeTellerAI Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
### Added
- Initial support for cryptocurrency market analysis
- Dark/light mode switching capability
- New candlestick pattern: 3 Bar Play

### Changed
- Improved TensorFlow.js model loading performance by 40%
- Updated technical indicators library to v3.2.0
- Enhanced news sentiment analysis accuracy

## [1.0.0] - 2023-08-15
### Added
- Initial public release
- Core technical analysis (RSI, MACD, EMA)
- Candlestick pattern recognition (15 patterns)
- News sentiment scoring system
- Trade journal with performance analytics

### Fixed
- Fixed memory leak in TensorFlow.js model inference
- Resolved chart rendering issues on high-DPI displays
- Corrected timezone handling for market sessions

## [0.9.0-beta] - 2023-07-20
### Added
- Beta testing framework
- Basic risk management calculator
- Initial broker performance comparison
- Dynamic lookback window feature

### Changed
- Optimized WASM backend for TensorFlow.js
- Reduced bundle size by 35%
- Improved cross-browser compatibility

## [0.5.0-alpha] - 2023-05-10
### Added
- Proof-of-concept technical analysis
- Basic charting functionality
- Local storage for trade history
- Chrome extension manifest v3 setup

### Security
- Implemented strict Content Security Policy
- Added model file integrity checks
- Sandboxed TensorFlow.js execution