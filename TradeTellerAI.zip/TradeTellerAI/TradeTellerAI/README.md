# 🧠 TradeTellerAI - AI-Powered Trading Assistant

![TradeTellerAI Banner](assets/images/banner.png)

**Professional-grade trading analysis powered by TensorFlow.js**  
Real-time market insights, technical pattern recognition, and sentiment analysis - 100% client-side in your browser.

[![Chrome Web Store](https://img.shields.io/chrome-web-store/v/your-extension-id?label=Chrome%20Web%20Store)](https://chrome.google.com/webstore/detail/tradetellerai/your-extension-id)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![TensorFlow.js](https://img.shields.io/badge/TensorFlow.js-4.2.0-orange)](https://www.tensorflow.org/js)

## 🌟 Features

### AI-Powered Market Analysis
- **Real-time Technical Indicators** (RSI, MACD, Bollinger Bands)
- **Candlestick Pattern Recognition** (50+ patterns detected)
- **News Sentiment Scoring** (Universal Sentence Encoder)
- **Combined AI Prediction Engine**

### Advanced Trading Tools
- Dynamic Lookback Window (1-30 days adaptive)
- Time-bound Probability Forecasts
- Broker Performance Analytics
- Risk Management Calculator

### Client-Side Privacy
- No data leaves your browser
- All AI models run locally
- IndexedDB for trade journal

## 🚀 Installation

### Chrome Web Store
1. Visit [Chrome Web Store listing](#)
2. Click "Add to Chrome"
3. Pin the extension for quick access

### Development Build
```bash
git clone https://github.com/your-repo/tradeteller-ai.git
cd tradeteller-ai
npm install
npm run build