// ai/aiProcessor.js
import * as tf from '@tensorflow/tfjs';
import { calculateRSI } from '../utils/tradingMath';
import { normalizeData } from '../services/dataNormalizer';
import { getOptimalLookback } from './lookbackLogic';
import { analyzeCandlePattern } from './candleAnalysisProcessor';
import { logger } from '../utils/logger';
import { config } from '../constants/config';

/**
 * Core AI Processor for TradeTellerAI
 * Handles technical analysis, pattern recognition, and prediction fusion
 */

// Load TensorFlow.js models
let models = {
  rsi: null,
  macd: null,
  ema: null,
  pattern: null,
  sentiment: null,
  combined: null
};

// Model loading status
let modelsLoaded = false;

/**
 * Load all AI models from local storage
 */
export const loadModels = async () => {
  try {
    logger.info('Loading AI models...');
    
    // Load technical analysis models
    models.rsi = await tf.loadLayersModel('ai/models/technicalAnalysis/rsi_model/model.json');
    models.macd = await tf.loadLayersModel('ai/models/technicalAnalysis/macd_model/model.json');
    models.ema = await tf.loadLayersModel('ai/models/technicalAnalysis/ema_model/model.json');
    
    // Load pattern recognition models
    models.pattern = await tf.loadLayersModel('ai/models/technicalAnalysis/pattern_recognition/model.json');
    
    // Load sentiment analysis model
    models.sentiment = await tf.loadLayersModel('ai/models/fundamentalAnalysis/sentiment_model/model.json');
    
    // Load combined prediction model
    models.combined = await tf.loadLayersModel('ai/models/combinedPrediction/buy_sell_model/model.json');
    
    modelsLoaded = true;
    logger.info('All AI models loaded successfully');
    return true;
  } catch (error) {
    logger.error('Failed to load models:', error);
    modelsLoaded = false;
    return false;
  }
};

/**
 * Process market data through all AI models
 * @param {Array} marketData - Raw market data array
 * @param {Object} newsData - News sentiment data
 * @returns {Promise<Object>} - AI predictions object
 */
export const processMarketData = async (marketData, newsData) => {
  if (!modelsLoaded) {
    await loadModels();
  }

  try {
    logger.debug('Processing market data through AI models...');
    
    // 1. Normalize and prepare data
    const normalizedData = normalizeData(marketData);
    const lookbackPeriod = getOptimalLookback(normalizedData);
    
    // 2. Technical Indicators Calculation
    const technicalAnalysis = {
      rsi: calculateRSI(normalizedData.closePrices, config.rsiPeriod),
      macd: calculateMACD(normalizedData.closePrices),
      ema: calculateEMA(normalizedData.closePrices, config.emaPeriods),
      lookbackPeriod
    };
    
    // 3. Candle Pattern Analysis
    const candleAnalysis = analyzeCandlePattern(normalizedData, lookbackPeriod);
    
    // 4. Sentiment Analysis
    const sentimentAnalysis = await analyzeSentiment(newsData);
    
    // 5. Combined Prediction
    const combinedPrediction = await generateCombinedPrediction({
      technical: technicalAnalysis,
      candle: candleAnalysis,
      sentiment: sentimentAnalysis
    });
    
    logger.debug('AI processing completed');
    
    return {
      technicalAnalysis,
      candleAnalysis,
      sentimentAnalysis,
      combinedPrediction,
      timestamp: new Date().toISOString()
    };
    
  } catch (error) {
    logger.error('Error processing market data:', error);
    throw error;
  }
};

/**
 * Calculate MACD values
 * @param {Array} prices - Array of closing prices
 * @returns {Object} - MACD values
 */
const calculateMACD = (prices) => {
  const fastEMA = calculateEMA(prices, config.macdFastPeriod);
  const slowEMA = calculateEMA(prices, config.macdSlowPeriod);
  const macdLine = fastEMA.map((val, idx) => val - slowEMA[idx]);
  const signalLine = calculateEMA(macdLine, config.macdSignalPeriod);
  const histogram = macdLine.map((val, idx) => val - signalLine[idx]);
  
  return {
    macdLine,
    signalLine,
    histogram,
    crossover: detectCrossovers(macdLine, signalLine)
  };
};

/**
 * Calculate Exponential Moving Average
 * @param {Array} prices - Price data
 * @param {number} period - EMA period
 * @returns {Array} - EMA values
 */
const calculateEMA = (prices, period) => {
  const ema = [];
  const multiplier = 2 / (period + 1);
  
  // Simple moving average for first value
  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += prices[i];
  }
  ema[period - 1] = sum / period;
  
  // EMA for subsequent values
  for (let i = period; i < prices.length; i++) {
    ema[i] = (prices[i] - ema[i - 1]) * multiplier + ema[i - 1];
  }
  
  return ema;
};

/**
 * Detect MACD line crossovers
 * @param {Array} macdLine - MACD values
 * @param {Array} signalLine - Signal line values
 * @returns {Array} - Crossover events
 */
const detectCrossovers = (macdLine, signalLine) => {
  const crossovers = [];
  
  for (let i = 1; i < macdLine.length; i++) {
    const prevMacd = macdLine[i - 1];
    const prevSignal = signalLine[i - 1];
    const currMacd = macdLine[i];
    const currSignal = signalLine[i];
    
    // Bullish crossover
    if (prevMacd < prevSignal && currMacd > currSignal) {
      crossovers.push({ index: i, type: 'bullish' });
    }
    // Bearish crossover
    else if (prevMacd > prevSignal && currMacd < currSignal) {
      crossovers.push({ index: i, type: 'bearish' });
    }
  }
  
  return crossovers;
};

/**
 * Analyze news sentiment using AI model
 * @param {Object} newsData - News data with headlines and sources
 * @returns {Promise<Object>} - Sentiment analysis results
 */
const analyzeSentiment = async (newsData) => {
  try {
    if (!newsData || !newsData.headlines || newsData.headlines.length === 0) {
      return {
        score: 0,
        sentiment: 'neutral',
        positive: 0,
        negative: 0,
        neutral: 0
      };
    }
    
    // Prepare input tensor
    const inputTensor = tf.tensor2d(
      newsData.headlines.map(headline => headline.embedding),
      [newsData.headlines.length, config.sentimentInputSize]
    );
    
    // Run model prediction
    const predictions = models.sentiment.predict(inputTensor);
    const scores = await predictions.array();
    
    // Calculate aggregate sentiment
    let positive = 0;
    let negative = 0;
    let neutral = 0;
    
    scores.forEach(score => {
      if (score[0] > 0.6) positive++;
      else if (score[0] < 0.4) negative++;
      else neutral++;
    });
    
    const avgScore = scores.reduce((sum, score) => sum + score[0], 0) / scores.length;
    const overallSentiment = avgScore > 0.6 ? 'positive' : avgScore < 0.4 ? 'negative' : 'neutral';
    
    return {
      score: avgScore,
      sentiment: overallSentiment,
      positive,
      negative,
      neutral,
      total: newsData.headlines.length
    };
    
  } catch (error) {
    logger.error('Error in sentiment analysis:', error);
    return {
      score: 0,
      sentiment: 'neutral',
      positive: 0,
      negative: 0,
      neutral: 0,
      total: 0,
      error: 'Failed to analyze sentiment'
    };
  }
};

/**
 * Generate combined prediction from all analysis results
 * @param {Object} inputs - Analysis results from all models
 * @returns {Promise<Object>} - Combined prediction with confidence
 */
const generateCombinedPrediction = async (inputs) => {
  try {
    // Prepare input features for combined model
    const features = [
      inputs.technicalAnalysis.rsi.slice(-1)[0] / 100, // Normalize RSI
      inputs.technicalAnalysis.macd.histogram.slice(-1)[0],
      inputs.technicalAnalysis.macd.crossover.length > 0 ? 
        (inputs.technicalAnalysis.macd.crossover.slice(-1)[0].type === 'bullish' ? 1 : -1) : 0,
      inputs.candleAnalysis.patternStrength || 0,
      inputs.sentiment.score,
      inputs.sentiment.positive / (inputs.sentiment.total || 1)
    ];
    
    // Create tensor and predict
    const inputTensor = tf.tensor2d([features], [1, features.length]);
    const prediction = models.combined.predict(inputTensor);
    const [confidence, direction] = await prediction.array();
    
    return {
      direction: direction[0] > 0.5 ? 'buy' : 'sell',
      confidence: Math.round(confidence[0] * 100),
      features,
      timestamp: new Date().toISOString()
    };
    
  } catch (error) {
    logger.error('Error generating combined prediction:', error);
    return {
      direction: 'neutral',
      confidence: 0,
      error: 'Failed to generate prediction'
    };
  }
};

/**
 * Get model loading status
 * @returns {boolean} - True if models are loaded
 */
export const areModelsLoaded = () => modelsLoaded;

// Initialize models when processor is imported
loadModels().catch(error => {
  logger.error('Initial model loading failed:', error);
});