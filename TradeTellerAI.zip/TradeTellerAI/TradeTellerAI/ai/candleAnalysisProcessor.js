// ai/candleAnalysisProcessor.js
import * as tf from '@tensorflow/tfjs';
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { patternDefinitions } from '../constants/patternDefinitions';
import { normalizeCandleData } from '../utils/candleUtils';

/**
 * Candle Pattern Analysis Processor for TradeTellerAI
 * Identifies and analyzes candlestick patterns using AI and rule-based methods
 */

// Loaded candle pattern model
let candleModel = null;
const MODEL_PATH = 'ai/models/technicalAnalysis/pattern_recognition/candle_analysis/model.json';

// Pattern importance weights
const PATTERN_WEIGHTS = {
  STRONG_REVERSAL: 0.9,
  WEAK_REVERSAL: 0.6,
  CONTINUATION: 0.7,
  NEUTRAL: 0.3
};

/**
 * Load candle pattern recognition model
 */
export const loadCandleModel = async () => {
  try {
    logger.info('Loading candle pattern recognition model...');
    candleModel = await tf.loadLayersModel(MODEL_PATH);
    logger.info('Candle pattern model loaded successfully');
    return true;
  } catch (error) {
    logger.error('Failed to load candle pattern model:', error);
    candleModel = null;
    return false;
  }
};

/**
 * Analyze candle patterns in market data
 * @param {Object} normalizedData - Normalized market data
 * @param {number} lookbackPeriod - Analysis lookback period
 * @returns {Object} - Candle pattern analysis results
 */
export const analyzeCandlePattern = (normalizedData, lookbackPeriod) => {
  try {
    // Extract recent candles based on lookback period
    const recentCandles = getRecentCandles(normalizedData, lookbackPeriod);
    
    // Detect patterns using both AI and rule-based methods
    const ruleBasedPatterns = detectRuleBasedPatterns(recentCandles);
    const aiPatterns = detectAIPatterns(recentCandles);
    
    // Combine and prioritize patterns
    const combinedPatterns = combinePatterns(ruleBasedPatterns, aiPatterns);
    
    // Calculate overall pattern strength and direction
    const patternStrength = calculatePatternStrength(combinedPatterns);
    const hasStrongPattern = patternStrength > config.patternStrengthThreshold;
    
    logger.debug('Candle pattern analysis completed', {
      ruleBasedPatterns,
      aiPatterns,
      combinedPatterns,
      patternStrength
    });
    
    return {
      patterns: combinedPatterns,
      patternStrength,
      hasStrongPattern,
      lookbackUsed: lookbackPeriod,
      candleCount: recentCandles.length,
      timestamp: new Date().toISOString()
    };
    
  } catch (error) {
    logger.error('Error in candle pattern analysis:', error);
    return getFallbackAnalysis(lookbackPeriod);
  }
};

/**
 * Get recent candles for analysis
 */
const getRecentCandles = (data, lookback) => {
  const endIdx = data.timestamps.length - 1;
  const startIdx = Math.max(0, endIdx - lookback + 1);
  
  return {
    open: data.openPrices.slice(startIdx, endIdx + 1),
    high: data.highPrices.slice(startIdx, endIdx + 1),
    low: data.lowPrices.slice(startIdx, endIdx + 1),
    close: data.closePrices.slice(startIdx, endIdx + 1),
    volume: data.volumes.slice(startIdx, endIdx + 1),
    timestamps: data.timestamps.slice(startIdx, endIdx + 1)
  };
};

/**
 * Detect patterns using rule-based methods
 */
const detectRuleBasedPatterns = (candles) => {
  const patterns = [];
  const candleCount = candles.close.length;
  
  // Need at least 2 candles for pattern detection
  if (candleCount < 2) return patterns;
  
  // Check each defined pattern
  patternDefinitions.forEach(pattern => {
    // Single candle patterns
    if (pattern.requiredCandles === 1) {
      for (let i = 0; i < candleCount; i++) {
        if (checkSingleCandlePattern(candles, i, pattern)) {
          patterns.push({
            name: pattern.name,
            type: pattern.type,
            direction: pattern.direction,
            position: i,
            confidence: pattern.confidence,
            method: 'rule-based'
          });
        }
      }
    }
    // Multi-candle patterns
    else {
      for (let i = 0; i <= candleCount - pattern.requiredCandles; i++) {
        if (checkMultiCandlePattern(candles, i, pattern)) {
          patterns.push({
            name: pattern.name,
            type: pattern.type,
            direction: pattern.direction,
            position: i,
            confidence: pattern.confidence,
            method: 'rule-based'
          });
        }
      }
    }
  });
  
  return patterns;
};

/**
 * Check single candle pattern conditions
 */
const checkSingleCandlePattern = (candles, index, pattern) => {
  const { open, high, low, close } = candles;
  const candle = { open: open[index], high: high[index], low: low[index], close: close[index] };
  
  // Check body size
  const bodySize = Math.abs(open[index] - close[index]);
  const totalRange = high[index] - low[index];
  const bodyRatio = totalRange > 0 ? bodySize / totalRange : 0;
  
  if (pattern.maxBodyRatio && bodyRatio > pattern.maxBodyRatio) return false;
  if (pattern.minBodyRatio && bodyRatio < pattern.minBodyRatio) return false;
  
  // Check upper/lower wick requirements
  if (pattern.upperWickRatio) {
    const upperWick = high[index] - Math.max(open[index], close[index]);
    const upperWickRatio = totalRange > 0 ? upperWick / totalRange : 0;
    if (upperWickRatio < pattern.upperWickRatio[0] || upperWickRatio > pattern.upperWickRatio[1]) return false;
  }
  
  if (pattern.lowerWickRatio) {
    const lowerWick = Math.min(open[index], close[index]) - low[index];
    const lowerWickRatio = totalRange > 0 ? lowerWick / totalRange : 0;
    if (lowerWickRatio < pattern.lowerWickRatio[0] || lowerWickRatio > pattern.lowerWickRatio[1]) return false;
  }
  
  // Check color requirement
  if (pattern.bullish && close[index] <= open[index]) return false;
  if (pattern.bearish && close[index] >= open[index]) return false;
  
  return true;
};

/**
 * Check multi-candle pattern conditions
 */
const checkMultiCandlePattern = (candles, startIndex, pattern) => {
  // Implementation would check relationships between multiple candles
  // This is simplified - actual implementation would be more detailed
  const requiredCandles = pattern.requiredCandles;
  
  // Check engulfing pattern example
  if (pattern.name === 'Bullish Engulfing') {
    const first = {
      open: candles.open[startIndex],
      close: candles.close[startIndex]
    };
    const second = {
      open: candles.open[startIndex + 1],
      close: candles.close[startIndex + 1]
    };
    
    return first.close < first.open && // First candle is bearish
           second.close > second.open && // Second candle is bullish
           second.open < first.close && // Second opens below first close
           second.close > first.open; // Second closes above first open
  }
  
  // Add other pattern checks here...
  
  return false;
};

/**
 * Detect patterns using AI model
 */
const detectAIPatterns = (candles) => {
  if (!candleModel || candles.close.length < 5) return [];
  
  try {
    // Normalize candle data for model input
    const inputData = normalizeCandleData(candles);
    const inputTensor = tf.tensor3d([inputData], [1, inputData.length, 5]); // [batch, steps, features]
    
    // Make prediction
    const prediction = candleModel.predict(inputTensor);
    const predictions = prediction.arraySync()[0];
    
    // Process predictions
    const patterns = [];
    predictions.forEach((pred, idx) => {
      if (pred > config.aiPatternThreshold) {
        const patternInfo = getPatternInfoFromIndex(idx);
        patterns.push({
          name: patternInfo.name,
          type: patternInfo.type,
          direction: patternInfo.direction,
          position: candles.close.length - 1, // Most recent candle
          confidence: pred,
          method: 'AI'
        });
      }
    });
    
    return patterns;
  } catch (error) {
    logger.error('AI pattern detection failed:', error);
    return [];
  }
};

/**
 * Combine and prioritize patterns from different detection methods
 */
const combinePatterns = (ruleBased, aiBased) => {
  const combined = [...ruleBased];
  
  // Add AI patterns if they don't conflict with stronger rule-based patterns
  aiBased.forEach(aiPattern => {
    const conflicting = ruleBased.some(rbPattern => 
      rbPattern.position === aiPattern.position && 
      rbPattern.confidence > aiPattern.confidence
    );
    
    if (!conflicting) {
      combined.push(aiPattern);
    }
  });
  
  // Sort by confidence and recentness
  return combined.sort((a, b) => {
    // More recent patterns first
    if (a.position !== b.position) return b.position - a.position;
    // Higher confidence first
    return b.confidence - a.confidence;
  });
};

/**
 * Calculate overall pattern strength
 */
const calculatePatternStrength = (patterns) => {
  if (patterns.length === 0) return 0;
  
  // Get the strongest pattern (most recent and highest confidence)
  const strongestPattern = patterns[0];
  
  // Apply weight based on pattern type
  const typeWeight = PATTERN_WEIGHTS[strongestPattern.type] || 0.5;
  
  // Final strength is confidence * type weight
  return strongestPattern.confidence * typeWeight;
};

/**
 * Get fallback analysis when error occurs
 */
const getFallbackAnalysis = (lookback) => ({
  patterns: [],
  patternStrength: 0,
  hasStrongPattern: false,
  lookbackUsed: lookback,
  candleCount: 0,
  timestamp: new Date().toISOString(),
  error: 'Analysis failed'
});

/**
 * Get pattern info from AI model output index
 */
const getPatternInfoFromIndex = (index) => {
  // This would map the model's output indices to known patterns
  // Simplified for example - actual implementation would have full mapping
  const patternMap = {
    0: { name: 'Hammer', type: 'STRONG_REVERSAL', direction: 'bullish' },
    1: { name: 'Shooting Star', type: 'STRONG_REVERSAL', direction: 'bearish' },
    // ... other patterns
  };
  
  return patternMap[index] || { name: 'Unknown', type: 'NEUTRAL', direction: 'neutral' };
};

// Initialize model on import
loadCandleModel().catch(error => {
  logger.error('Initial candle model loading failed:', error);
});