// ai/directionalPrediction.js
import * as tf from '@tensorflow/tfjs';
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { getTimeBins } from '../utils/dateUtils';
import { calculateProbabilityDistribution } from '../utils/statsCalculator';

/**
 * Directional Probability Prediction Engine for TradeTellerAI
 * Predicts price movement probabilities over different time horizons
 */

// Loaded model instance
let directionalModel = null;
const MODEL_PATH = 'ai/models/combinedPrediction/directional_prob_model/model.json';

// Time horizons for prediction (in hours)
const TIME_HORIZONS = [1, 2, 4, 8, 24];

/**
 * Load directional prediction model
 */
export const loadDirectionalModel = async () => {
  try {
    logger.info('Loading directional prediction model...');
    directionalModel = await tf.loadLayersModel(MODEL_PATH);
    logger.info('Directional prediction model loaded successfully');
    return true;
  } catch (error) {
    logger.error('Failed to load directional model:', error);
    directionalModel = null;
    return false;
  }
};

/**
 * Generate directional predictions for multiple time horizons
 * @param {Object} marketData - Processed market data
 * @param {Object} technicals - Technical indicators
 * @param {Object} sentiment - Sentiment analysis results
 * @returns {Promise<Object>} - Directional predictions
 */
export const generateDirectionalPredictions = async (marketData, technicals, sentiment) => {
  if (!directionalModel) {
    await loadDirectionalModel();
  }

  try {
    // Prepare input features
    const features = prepareDirectionalFeatures(marketData, technicals, sentiment);
    
    // Create input tensor
    const inputTensor = tf.tensor2d([features], [1, features.length]);
    
    // Make prediction
    const prediction = directionalModel.predict(inputTensor);
    const predictionArray = await prediction.array();
    
    // Process output
    const results = processDirectionalOutput(predictionArray[0]);
    
    logger.debug('Directional predictions generated', { results });
    return results;
    
  } catch (error) {
    logger.error('Error generating directional predictions:', error);
    return getFallbackPrediction();
  }
};

/**
 * Prepare input features for directional prediction
 */
const prepareDirectionalFeatures = (marketData, technicals, sentiment) => {
  const { closePrices, volumes } = marketData;
  const lastPrice = closePrices[closePrices.length - 1];
  
  // Technical features
  const rsi = technicals.rsi.slice(-1)[0] / 100; // Normalized
  const macdHist = technicals.macd.histogram.slice(-1)[0];
  const ema20 = technicals.ema[0].slice(-1)[0];
  const ema50 = technicals.ema[1].slice(-1)[0];
  const ema200 = technicals.ema[2].slice(-1)[0];
  
  // Price features
  const priceAboveEMA20 = lastPrice > ema20 ? 1 : 0;
  const priceAboveEMA50 = lastPrice > ema50 ? 1 : 0;
  const ema20Above50 = ema20 > ema50 ? 1 : 0;
  
  // Volume features
  const volumeAvg5 = volumes.slice(-5).reduce((a, b) => a + b, 0) / 5;
  const volumeAvg20 = volumes.slice(-20).reduce((a, b) => a + b, 0) / 20;
  const volumeRatio = volumeAvg5 / (volumeAvg20 || 1);
  
  // Sentiment features
  const sentimentScore = sentiment.score;
  const positiveRatio = sentiment.positive / (sentiment.total || 1);
  
  return [
    rsi,
    macdHist,
    priceAboveEMA20,
    priceAboveEMA50,
    ema20Above50,
    volumeRatio,
    sentimentScore,
    positiveRatio,
    lastPrice / ema20,
    lastPrice / ema50,
    lastPrice / ema200
  ];
};

/**
 * Process raw model output into structured predictions
 */
const processDirectionalOutput = (rawOutput) => {
  // The model outputs probabilities for each time horizon
  // Output shape: [time_horizons * 3] (up, neutral, down probabilities for each horizon)
  const predictions = {};
  const binSize = 3; // up, neutral, down for each horizon
  
  TIME_HORIZONS.forEach((horizon, index) => {
    const startIdx = index * binSize;
    const [upProb, neutralProb, downProb] = rawOutput.slice(startIdx, startIdx + binSize);
    
    // Apply softmax to ensure probabilities sum to 1
    const total = upProb + neutralProb + downProb;
    const normalizedUp = upProb / total;
    const normalizedNeutral = neutralProb / total;
    const normalizedDown = downProb / total;
    
    predictions[`${horizon}h`] = {
      up: parseFloat(normalizedUp.toFixed(3)),
      neutral: parseFloat(normalizedNeutral.toFixed(3)),
      down: parseFloat(normalizedDown.toFixed(3)),
      confidence: Math.max(normalizedUp, normalizedDown),
      direction: normalizedUp > normalizedDown ? 'up' : 'down'
    };
  });
  
  // Add overall prediction by aggregating all horizons
  const aggregated = calculateProbabilityDistribution(
    Object.values(predictions).map(p => [p.up, p.neutral, p.down])
  );
  
  predictions.overall = {
    up: aggregated[0],
    neutral: aggregated[1],
    down: aggregated[2],
    confidence: Math.max(aggregated[0], aggregated[2]),
    direction: aggregated[0] > aggregated[2] ? 'up' : 'down'
  };
  
  return predictions;
};

/**
 * Get fallback prediction when model fails
 */
const getFallbackPrediction = () => {
  const fallback = {};
  TIME_HORIZONS.forEach(horizon => {
    fallback[`${horizon}h`] = {
      up: 0.33,
      neutral: 0.34,
      down: 0.33,
      confidence: 0.33,
      direction: 'neutral'
    };
  });
  
  fallback.overall = {
    up: 0.33,
    neutral: 0.34,
    down: 0.33,
    confidence: 0.33,
    direction: 'neutral'
  };
  
  return fallback;
};

/**
 * Get time horizons used for predictions
 */
export const getTimeHorizons = () => [...TIME_HORIZONS];

/**
 * Format predictions for UI display
 */
export const formatPredictionsForUI = (predictions) => {
  return TIME_HORIZONS.map(horizon => {
    const key = `${horizon}h`;
    return {
      time: `${horizon} Hour${horizon !== 1 ? 's' : ''}`,
      probability: predictions[key].up * 100,
      direction: predictions[key].direction,
      confidence: predictions[key].confidence * 100
    };
  });
};

// Initialize model on import
loadDirectionalModel().catch(error => {
  logger.error('Initial directional model loading failed:', error);
});