// ai/lookbackLogic.js
import { logger } from '../utils/logger';
import { calculateVolatility } from '../utils/tradingMath';
import { config } from '../constants/config';
import { detectTrend } from '../utils/statsCalculator';
import { newsImpactLevel } from '../services/newsScanner';

/**
 * Dynamic Lookback Window Logic for TradeTellerAI
 * Determines optimal historical data period based on market conditions
 */

// Lookback presets for different market conditions
const LOOKBACK_PRESETS = {
  HIGH_VOLATILITY: { min: 1, max: 3 },
  SIDEWAYS: { min: 7, max: 14 },
  TRENDING: { min: 14, max: 30 },
  NEWS_DRIVEN: { min: 3, max: 5 },
  DEFAULT: { min: 7, max: 14 }
};

/**
 * Get optimal lookback period based on market conditions
 * @param {Array} normalizedData - Normalized market data
 * @param {Object} newsData - Current news sentiment data
 * @returns {number} - Optimal lookback period in days
 */
export const getOptimalLookback = (normalizedData, newsData = null) => {
  try {
    // 1. Analyze market conditions
    const conditions = analyzeMarketConditions(normalizedData, newsData);
    
    // 2. Determine lookback range based on conditions
    const lookbackRange = getLookbackRange(conditions);
    
    // 3. Calculate final lookback period with adaptive logic
    const lookback = calculateAdaptiveLookback(normalizedData, lookbackRange);
    
    logger.debug(`Determined lookback period: ${lookback} days`, {
      conditions,
      lookbackRange,
      finalLookback: lookback
    });
    
    return lookback;
  } catch (error) {
    logger.error('Error calculating lookback period:', error);
    return LOOKBACK_PRESETS.DEFAULT.min;
  }
};

/**
 * Analyze current market conditions
 * @param {Array} data - Market data
 * @param {Object} newsData - News sentiment data
 * @returns {Object} - Market conditions analysis
 */
const analyzeMarketConditions = (data, newsData) => {
  const closePrices = data.closePrices || [];
  const lastIndex = closePrices.length - 1;
  
  // Calculate technical metrics
  const volatility = calculateVolatility(closePrices);
  const trend = detectTrend(closePrices);
  const recentVolume = data.volumes ? data.volumes.slice(-5).reduce((a, b) => a + b, 0) / 5 : 0;
  const avgVolume = data.volumes ? data.volumes.reduce((a, b) => a + b, 0) / data.volumes.length : 0;
  
  // Analyze news impact if available
  let newsImpact = 0;
  if (newsData) {
    newsImpact = newsImpactLevel(newsData);
  }
  
  return {
    volatility,
    trendStrength: trend.strength,
    trendDirection: trend.direction,
    volumeRatio: recentVolume / (avgVolume || 1),
    newsImpact,
    priceChange: closePrices[lastIndex] / closePrices[0] - 1
  };
};

/**
 * Get lookback range based on market conditions
 * @param {Object} conditions - Market conditions
 * @returns {Object} - Min/max lookback range
 */
const getLookbackRange = (conditions) => {
  const { volatility, trendStrength, trendDirection, newsImpact, volumeRatio } = conditions;
  
  // Priority 1: News-driven market
  if (newsImpact > config.newsImpactThreshold) {
    return LOOKBACK_PRESETS.NEWS_DRIVEN;
  }
  
  // Priority 2: High volatility
  if (volatility > config.highVolatilityThreshold || volumeRatio > config.highVolumeThreshold) {
    return LOOKBACK_PRESETS.HIGH_VOLATILITY;
  }
  
  // Priority 3: Strong trend
  if (trendStrength > config.strongTrendThreshold) {
    return LOOKBACK_PRESETS.TRENDING;
  }
  
  // Priority 4: Sideways market
  if (trendStrength < config.weakTrendThreshold) {
    return LOOKBACK_PRESETS.SIDEWAYS;
  }
  
  // Default range
  return LOOKBACK_PRESETS.DEFAULT;
};

/**
 * Calculate adaptive lookback within determined range
 * @param {Array} data - Market data
 * @param {Object} range - Min/max lookback range
 * @returns {number} - Calculated lookback period
 */
const calculateAdaptiveLookback = (data, range) => {
  const { min, max } = range;
  const closePrices = data.closePrices || [];
  
  // If we don't have enough data, use minimum
  if (closePrices.length < min) {
    return Math.max(1, closePrices.length - 1);
  }
  
  // Calculate price change metrics
  const shortTermChange = Math.abs(
    closePrices[closePrices.length - 1] / closePrices[closePrices.length - min] - 1
  );
  const longTermChange = Math.abs(
    closePrices[closePrices.length - 1] / closePrices[0] - 1
  );
  
  // Adjust based on recent price movement
  const changeRatio = shortTermChange / (longTermChange || 0.01);
  const dynamicLookback = Math.round(
    min + (max - min) * (1 - Math.min(1, changeRatio))
  );
  
  // Ensure within bounds
  return Math.max(min, Math.min(max, dynamicLookback));
};

/**
 * Get default lookback range for initialization
 * @returns {Object} - Default min/max lookback
 */
export const getDefaultLookbackRange = () => {
  return { ...LOOKBACK_PRESETS.DEFAULT };
};

/**
 * Get all lookback presets for UI display
 * @returns {Object} - All lookback presets
 */
export const getLookbackPresets = () => {
  return { ...LOOKBACK_PRESETS };
};