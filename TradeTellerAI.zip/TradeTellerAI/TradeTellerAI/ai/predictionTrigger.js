// ai/predictionTrigger.js
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { getMarketPhase } from '../utils/dateUtils';
import { calculateVolatility } from '../utils/tradingMath';
import { analyzeRecentNews } from '../services/newsScanner';

/**
 * Prediction Trigger Logic for TradeTellerAI
 * Determines optimal times to generate predictions based on market conditions
 */

// Prediction trigger state
const triggerState = {
  lastPredictionTime: null,
  lastPredictionType: null,
  marketPhase: 'UNKNOWN',
  volatilityState: 'NORMAL',
  newsSensitivity: 0
};

// Minimum intervals between predictions (in milliseconds)
const PREDICTION_INTERVALS = {
  ROUTINE: config.predictionIntervals.routine * 60 * 1000, // 15 minutes default
  HIGH_VOLATILITY: config.predictionIntervals.highVolatility * 60 * 1000, // 5 minutes
  NEWS_EVENT: config.predictionIntervals.newsEvent * 60 * 1000, // 2 minutes
  MARKET_OPEN: config.predictionIntervals.marketOpen * 60 * 1000 // 10 minutes
};

/**
 * Determine if prediction should be triggered
 * @param {Object} marketData - Current market data
 * @param {Object} newsData - Current news data
 * @returns {Object} - { shouldTrigger: boolean, triggerType: string, reason: string }
 */
export const shouldTriggerPrediction = (marketData, newsData) => {
  try {
    // Update current market state
    updateTriggerState(marketData, newsData);

    // Check if we're in force-trigger state (e.g., major news event)
    const forceTrigger = checkForceTriggerConditions(newsData);
    if (forceTrigger.shouldTrigger) {
      return forceTrigger;
    }

    // Check time-based triggering
    if (shouldTriggerByTime()) {
      return {
        shouldTrigger: true,
        triggerType: 'ROUTINE',
        reason: `Scheduled prediction due (${config.predictionIntervals.routine} min interval)`
      };
    }

    // Check volatility-based triggering
    const volatilityTrigger = checkVolatilityTrigger(marketData);
    if (volatilityTrigger.shouldTrigger) {
      return volatilityTrigger;
    }

    // Check market phase transitions
    const phaseTrigger = checkMarketPhaseTrigger();
    if (phaseTrigger.shouldTrigger) {
      return phaseTrigger;
    }

    // No trigger conditions met
    return {
      shouldTrigger: false,
      triggerType: null,
      reason: 'No triggering conditions met'
    };

  } catch (error) {
    logger.error('Error in prediction trigger logic:', error);
    return {
      shouldTrigger: false,
      triggerType: null,
      reason: 'Error in trigger logic'
    };
  }
};

/**
 * Update internal trigger state
 */
const updateTriggerState = (marketData, newsData) => {
  // Update market phase
  triggerState.marketPhase = getMarketPhase();
  
  // Update volatility state
  const volatility = calculateVolatility(marketData.closePrices);
  triggerState.volatilityState = volatility > config.highVolatilityThreshold ? 
    'HIGH' : 'NORMAL';
  
  // Update news sensitivity
  triggerState.newsSensitivity = analyzeRecentNews(newsData).impactScore;
  
  logger.debug('Updated prediction trigger state', { ...triggerState });
};

/**
 * Check for force-trigger conditions (immediate prediction)
 */
const checkForceTriggerConditions = (newsData) => {
  // Major news event detection
  if (triggerState.newsSensitivity > config.newsEventThreshold) {
    return {
      shouldTrigger: true,
      triggerType: 'NEWS_EVENT',
      reason: `Major news event detected (score: ${triggerState.newsSensitivity})`
    };
  }

  // Extreme volatility spike
  if (triggerState.volatilityState === 'HIGH' && 
      triggerState.lastPredictionType !== 'HIGH_VOLATILITY') {
    return {
      shouldTrigger: true,
      triggerType: 'HIGH_VOLATILITY',
      reason: 'Extreme volatility detected'
    };
  }

  // Market open/close transitions
  if (triggerState.marketPhase === 'OPENING' && 
      triggerState.lastPredictionType !== 'MARKET_OPEN') {
    return {
      shouldTrigger: true,
      triggerType: 'MARKET_OPEN',
      reason: 'Market opening phase detected'
    };
  }

  return { shouldTrigger: false };
};

/**
 * Check if enough time has passed for routine prediction
 */
const shouldTriggerByTime = () => {
  if (!triggerState.lastPredictionTime) {
    return true; // First prediction
  }

  const elapsed = Date.now() - triggerState.lastPredictionTime;
  const requiredInterval = PREDICTION_INTERVALS[triggerState.lastPredictionType] || 
                         PREDICTION_INTERVALS.ROUTINE;

  return elapsed >= requiredInterval;
};

/**
 * Check volatility-based trigger conditions
 */
const checkVolatilityTrigger = (marketData) => {
  if (triggerState.volatilityState !== 'HIGH') {
    return { shouldTrigger: false };
  }

  // Check if we've had a significant move since last prediction
  if (triggerState.lastPredictionTime) {
    const lastClose = marketData.closePrices[marketData.closePrices.length - 1];
    const prevClose = marketData.closePrices.find((_, idx, arr) => {
      return idx < arr.length - 1 && arr[idx + 1].timestamp > triggerState.lastPredictionTime;
    })?.price || lastClose;

    const movePercent = Math.abs(lastClose / prevClose - 1) * 100;
    if (movePercent > config.volatilityMoveThreshold) {
      return {
        shouldTrigger: true,
        triggerType: 'VOLATILITY_MOVE',
        reason: `Significant price move detected (${movePercent.toFixed(2)}%)`
      };
    }
  }

  return { shouldTrigger: false };
};

/**
 * Check market phase transition triggers
 */
const checkMarketPhaseTrigger = () => {
  const currentPhase = triggerState.marketPhase;
  const lastPhase = triggerState.lastMarketPhase;

  // Only trigger on phase transitions
  if (lastPhase && currentPhase !== lastPhase) {
    // Special handling for market open/close
    if (currentPhase === 'OPENING' || currentPhase === 'CLOSING') {
      return {
        shouldTrigger: true,
        triggerType: 'PHASE_TRANSITION',
        reason: `Market phase changed to ${currentPhase}`
      };
    }
  }

  return { shouldTrigger: false };
};

/**
 * Record that a prediction was just made
 * @param {string} triggerType - Type of trigger that caused the prediction
 */
export const recordPredictionTrigger = (triggerType) => {
  triggerState.lastPredictionTime = Date.now();
  triggerState.lastPredictionType = triggerType;
  triggerState.lastMarketPhase = triggerState.marketPhase;
  logger.debug(`Recorded prediction trigger: ${triggerType}`);
};

/**
 * Get current trigger state (for debugging/UI)
 */
export const getTriggerState = () => {
  return {
    ...triggerState,
    timeSinceLastPrediction: triggerState.lastPredictionTime ? 
      (Date.now() - triggerState.lastPredictionTime) / 60000 : null
  };
};

/**
 * Reset trigger state (for testing/new session)
 */
export const resetTriggerState = () => {
  triggerState.lastPredictionTime = null;
  triggerState.lastPredictionType = null;
  triggerState.marketPhase = 'UNKNOWN';
  triggerState.volatilityState = 'NORMAL';
  triggerState.newsSensitivity = 0;
  logger.info('Reset prediction trigger state');
};