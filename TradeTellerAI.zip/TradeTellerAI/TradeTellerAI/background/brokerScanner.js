// background/brokerScanner.js
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { fetchWithTimeout } from '../utils/networkUtils';
import { calculateExecutionQuality } from '../utils/tradingMath';
import { storeBrokerData } from '../services/userHistory';

// Supported brokers with their API endpoints
const BROKERS = [
  {
    id: 'oanda',
    name: 'OANDA',
    apiEndpoint: config.brokerApis.oanda,
    icon: '../assets/icons/broker-logos/oanda.png',
    tiers: ['Standard', 'Premium', 'Professional']
  },
  {
    id: 'pepperstone',
    name: 'Pepperstone',
    apiEndpoint: config.brokerApis.pepperstone,
    icon: '../assets/icons/broker-logos/pepperstone.png',
    tiers: ['Razor', 'Standard']
  },
  {
    id: 'fxcm',
    name: 'FXCM',
    apiEndpoint: config.brokerApis.fxcm,
    icon: '../assets/icons/broker-logos/fxcm.png',
    tiers: ['Active Trader', 'Standard']
  },
  {
    id: 'icmarkets',
    name: 'IC Markets',
    apiEndpoint: config.brokerApis.icmarkets,
    icon: '../assets/icons/broker-logos/icmarkets.png',
    tiers: ['Raw Spread', 'Standard']
  }
];

// Cache for broker data
const brokerCache = {
  lastUpdated: null,
  data: null,
  executionStats: {}
};

/**
 * Scan all supported brokers for execution metrics
 * @param {string} symbol - Trading symbol to analyze
 * @param {number} sampleSize - Number of trades to analyze
 * @returns {Promise<Array>} Array of broker analysis results
 */
export const scanBrokers = async (symbol, sampleSize = 100) => {
  try {
    logger.info(`Starting broker scan for ${symbol}, sample size: ${sampleSize}`);

    const results = [];
    const errors = [];
    const startTime = Date.now();

    // Scan each broker in parallel
    await Promise.all(BROKERS.map(async broker => {
      try {
        const brokerData = await analyzeBrokerExecution(broker, symbol, sampleSize);
        results.push(brokerData);
        
        // Update cache
        brokerCache.executionStats[broker.id] = brokerData.stats;
      } catch (error) {
        errors.push({
          broker: broker.id,
          error: error.message
        });
        logger.warn(`Failed to scan broker ${broker.id}: ${error.message}`);
      }
    }));

    // Sort results by execution quality score
    results.sort((a, b) => b.stats.qualityScore - a.stats.qualityScore);

    // Update cache
    brokerCache.data = results;
    brokerCache.lastUpdated = Date.now();
    
    // Store results in history
    await storeBrokerData({
      symbol,
      timestamp: startTime,
      results,
      errors,
      durationMs: Date.now() - startTime
    });

    logger.info(`Broker scan completed for ${symbol}. Success: ${results.length}, Errors: ${errors.length}`);
    
    return {
      success: results,
      errors,
      fromCache: false
    };
  } catch (error) {
    logger.error(`Broker scan failed for ${symbol}: ${error.message}`);
    
    // Return cached data if available
    if (brokerCache.data) {
      logger.warn('Returning cached broker data');
      return {
        success: brokerCache.data,
        errors: [],
        fromCache: true
      };
    }
    
    throw error;
  }
};

/**
 * Analyze a single broker's execution quality
 */
async function analyzeBrokerExecution(broker, symbol, sampleSize) {
  const startTime = Date.now();
  
  // Fetch execution data from broker API
  const executionData = await fetchExecutionData(broker, symbol, sampleSize);
  
  // Calculate execution metrics
  const stats = calculateExecutionMetrics(executionData, broker);
  
  // Generate AI recommendation
  const recommendation = generateBrokerRecommendation(stats);
  
  return {
    broker: {
      id: broker.id,
      name: broker.name,
      icon: broker.icon,
      tier: executionData.accountTier || broker.tiers[0]
    },
    stats,
    recommendation,
    analysisTimeMs: Date.now() - startTime
  };
}

/**
 * Fetch execution data from broker API
 */
async function fetchExecutionData(broker, symbol, sampleSize) {
  const url = `${broker.apiEndpoint}/execution?symbol=${symbol}&samples=${sampleSize}`;
  
  try {
    const response = await fetchWithTimeout(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${config.apiKeys.brokerData}`,
        'Content-Type': 'application/json'
      },
      timeout: 8000
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    throw new Error(`Failed to fetch execution data: ${error.message}`);
  }
}

/**
 * Calculate execution metrics from raw data
 */
function calculateExecutionMetrics(data, broker) {
  if (!data || !data.executions || !data.executions.length) {
    throw new Error('No execution data received');
  }

  const executions = data.executions;
  const spreads = executions.map(e => e.spread);
  const slippages = executions.map(e => e.slippage);
  const latencies = executions.map(e => e.latencyMs);
  const rejections = executions.filter(e => e.rejected).length;

  return {
    spread: {
      avg: calculateExecutionQuality.avg(spreads),
      max: Math.max(...spreads),
      min: Math.min(...spreads),
      stdev: calculateExecutionQuality.stdev(spreads)
    },
    slippage: {
      avg: calculateExecutionQuality.avg(slippages),
      max: Math.max(...slippages),
      min: Math.min(...slippages),
      positive: slippages.filter(s => s > 0).length,
      negative: slippages.filter(s => s < 0).length
    },
    latency: {
      avg: calculateExecutionQuality.avg(latencies),
      max: Math.max(...latencies),
      p99: calculateExecutionQuality.percentile(latencies, 99),
      p95: calculateExecutionQuality.percentile(latencies, 95)
    },
    rejectionRate: rejections / executions.length,
    qualityScore: calculateExecutionQuality.score({
      avgSpread: calculateExecutionQuality.avg(spreads),
      avgSlippage: calculateExecutionQuality.avg(slippages),
      avgLatency: calculateExecutionQuality.avg(latencies),
      rejectionRate: rejections / executions.length
    }, broker.id),
    sampleSize: executions.length,
    lastUpdated: new Date().toISOString()
  };
}

/**
 * Generate AI recommendation based on execution stats
 */
function generateBrokerRecommendation(stats) {
  let recommendation = 'Neutral';
  let confidence = 'Medium';
  let strengths = [];
  let weaknesses = [];

  // Evaluate based on quality score
  if (stats.qualityScore >= 85) {
    recommendation = 'Strong Buy';
    confidence = 'High';
    strengths = ['Excellent execution', 'Low latency', 'Tight spreads'];
  } else if (stats.qualityScore >= 70) {
    recommendation = 'Buy';
    confidence = 'Medium';
    strengths = ['Good execution', 'Competitive spreads'];
    weaknesses = ['Occasional slippage'];
  } else if (stats.qualityScore >= 50) {
    recommendation = 'Neutral';
    confidence = 'Medium';
    strengths = ['Average execution'];
    weaknesses = ['Higher spreads', 'Some latency'];
  } else {
    recommendation = 'Avoid';
    confidence = 'High';
    weaknesses = ['High spreads', 'Frequent slippage', 'Latency issues'];
  }

  // Special considerations
  if (stats.rejectionRate > 0.1) {
    weaknesses.push('High order rejection');
    if (recommendation !== 'Avoid') {
      recommendation = 'Caution';
      confidence = 'High';
    }
  }

  if (stats.slippage.positive > stats.slippage.negative * 1.5) {
    strengths.push('Positive slippage bias');
  }

  return {
    recommendation,
    confidence,
    strengths,
    weaknesses,
    suitableFor: getSuitableStrategies(stats)
  };
}

/**
 * Determine suitable trading strategies based on broker stats
 */
function getSuitableStrategies(stats) {
  const strategies = [];
  
  if (stats.latency.avg < 50 && stats.latency.p99 < 100) {
    strategies.push('High Frequency Trading', 'Scalping');
  }
  
  if (stats.spread.avg < 1.5 && stats.slippage.avg < 0.5) {
    strategies.push('Day Trading', 'Swing Trading');
  }
  
  if (stats.spread.stdev < 0.3 && stats.rejectionRate < 0.05) {
    strategies.push('Algorithmic Trading');
  }
  
  if (stats.spread.avg < 0.8) {
    strategies.push('Arbitrage');
  }
  
  return strategies.length > 0 
    ? [...new Set(strategies)] 
    : ['General Trading'];
}

/**
 * Get cached broker data
 */
export const getCachedBrokerData = () => ({
  lastUpdated: brokerCache.lastUpdated,
  brokers: brokerCache.data ? brokerCache.data.map(b => b.broker.id) : [],
  executionStats: brokerCache.executionStats
});

/**
 * Get broker metadata
 */
export const getBrokerMetadata = () => BROKERS.map(broker => ({
  id: broker.id,
  name: broker.name,
  icon: broker.icon,
  tiers: broker.tiers
}));