// background/contentScriptManager.js
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { storeContentScriptData } from '../services/userHistory';

// Active content script connections
const activeConnections = new Map();

// Supported trading platforms and their injection rules
const PLATFORMS = {
  tradingview: {
    name: 'TradingView',
    match: ['*://*.tradingview.com/*'],
    scripts: ['../content/injectScripts/tradingview.js'],
    styles: ['../content/styles/tradingview.css']
  },
  metatrader: {
    name: 'MetaTrader Web',
    match: ['*://*.metatrader-web.com/*', '*://*.metatrader5.com/*'],
    scripts: ['../content/injectScripts/metatrader.js'],
    styles: []
  },
  ninjatrader: {
    name: 'NinjaTrader',
    match: ['*://*.ninjatrader.com/*'],
    scripts: ['../content/injectScripts/ninjatrader.js'],
    styles: ['../content/styles/ninjatrader.css']
  }
};

/**
 * Initialize content script management
 */
export const initContentScriptManager = () => {
  chrome.runtime.onConnect.addListener(handleContentScriptConnection);
  chrome.runtime.onMessage.addListener(handleContentScriptMessage);
  
  // Set up declarative content rules for automatic injection
  setupDeclarativeContentRules();
  
  logger.info('Content Script Manager initialized');
};

/**
 * Handle new content script connections
 */
function handleContentScriptConnection(port) {
  if (port.name.startsWith('tradeTellerContentScript_')) {
    const tabId = port.sender?.tab?.id;
    if (!tabId) return;
    
    const platform = port.name.split('_')[1];
    
    // Store the connection
    activeConnections.set(tabId, {
      port,
      platform,
      status: 'connected',
      lastActivity: Date.now()
    });
    
    logger.debug(`Content script connected for tab ${tabId} (${platform})`);
    
    // Set up port listeners
    port.onMessage.addListener((message) => 
      handleContentScriptMessage(message, { tab: { id: tabId } }));
    
    port.onDisconnect.addListener(() => {
      activeConnections.delete(tabId);
      logger.debug(`Content script disconnected for tab ${tabId}`);
    });
  }
}

/**
 * Handle messages from content scripts
 */
function handleContentScriptMessage(message, sender, sendResponse) {
  const tabId = sender?.tab?.id;
  if (!tabId || !activeConnections.has(tabId)) return;
  
  const connection = activeConnections.get(tabId);
  connection.lastActivity = Date.now();
  
  logger.debug(`Message from tab ${tabId}:`, message.type);
  
  switch (message.type) {
    case 'PAGE_ANALYSIS_READY':
      handlePageAnalysisReady(tabId, message.data);
      break;
      
    case 'DOM_EVENT_DETECTED':
      handleDomEvent(tabId, message.event);
      break;
      
    case 'TRADE_EXECUTION_DETECTED':
      handleTradeExecution(tabId, message.tradeData);
      break;
      
    case 'REQUEST_CONFIG':
      sendResponse({ config: getPlatformConfig(connection.platform) });
      return true; // Keep message channel open
      
    case 'REQUEST_INJECTION':
      handleInjectionRequest(tabId, message.payload);
      break;
      
    default:
      logger.warn(`Unknown message type from tab ${tabId}: ${message.type}`);
  }
}

/**
 * Handle page analysis completion from content script
 */
async function handlePageAnalysisReady(tabId, analysisData) {
  try {
    const connection = activeConnections.get(tabId);
    if (!connection) return;
    
    logger.info(`Page analysis complete for tab ${tabId} (${connection.platform})`);
    
    // Store the analysis data
    await storeContentScriptData({
      tabId,
      platform: connection.platform,
      timestamp: Date.now(),
      data: analysisData,
      url: await getTabUrl(tabId)
    });
    
    // Notify other parts of the extension
    chrome.runtime.sendMessage({
      type: 'CONTENT_ANALYSIS_READY',
      tabId,
      platform: connection.platform,
      data: analysisData
    });
    
  } catch (error) {
    logger.error(`Failed to handle page analysis for tab ${tabId}:`, error);
  }
}

/**
 * Handle DOM events from trading platforms
 */
function handleDomEvent(tabId, eventData) {
  // Implement event-specific logic here
  logger.debug(`DOM event from tab ${tabId}:`, eventData.eventType);
  
  // Example: Chart timeframe changed
  if (eventData.eventType === 'TIMEFRAME_CHANGE') {
    chrome.runtime.sendMessage({
      type: 'CHART_TIMEFRAME_CHANGED',
      tabId,
      timeframe: eventData.timeframe
    });
  }
}

/**
 * Handle detected trade executions
 */
async function handleTradeExecution(tabId, tradeData) {
  try {
    logger.info(`Trade execution detected in tab ${tabId}:`, tradeData);
    
    // Store trade execution data
    await storeContentScriptData({
      tabId,
      type: 'TRADE_EXECUTION',
      timestamp: Date.now(),
      data: tradeData,
      url: await getTabUrl(tabId)
    });
    
    // Notify other parts of the extension
    chrome.runtime.sendMessage({
      type: 'TRADE_EXECUTED',
      tabId,
      tradeData
    });
    
  } catch (error) {
    logger.error(`Failed to handle trade execution for tab ${tabId}:`, error);
  }
}

/**
 * Handle injection requests from content scripts
 */
function handleInjectionRequest(tabId, payload) {
  const connection = activeConnections.get(tabId);
  if (!connection) return;
  
  logger.debug(`Injection request from tab ${tabId}:`, payload.requestType);
  
  switch (payload.requestType) {
    case 'INDICATOR_ADD':
      injectAdditionalScript(tabId, '../content/injectScripts/indicators.js');
      break;
      
    case 'CHART_ENHANCE':
      injectAdditionalScript(tabId, '../content/injectScripts/chartEnhancements.js');
      break;
      
    default:
      logger.warn(`Unknown injection request type: ${payload.requestType}`);
  }
}

/**
 * Set up declarative content rules for automatic injection
 */
function setupDeclarativeContentRules() {
  if (!chrome.declarativeContent) {
    logger.warn('Declarative content API not available');
    return;
  }
  
  try {
    const rules = Object.values(PLATFORMS).map(platform => {
      return {
        conditions: platform.match.map(url => new chrome.declarativeContent.PageStateMatcher({
          pageUrl: { urlMatches: url }
        })),
        actions: [
          new chrome.declarativeContent.RequestContentScript({
            js: platform.scripts,
            css: platform.styles
          })
        ]
      };
    });
    
    chrome.declarativeContent.onPageChanged.removeRules(undefined, () => {
      chrome.declarativeContent.onPageChanged.addRules(rules, () => {
        if (chrome.runtime.lastError) {
          logger.error('Failed to set declarative rules:', chrome.runtime.lastError);
        } else {
          logger.info(`Declarative content rules set for ${rules.length} platforms`);
        }
      });
    });
  } catch (error) {
    logger.error('Error setting up declarative content rules:', error);
  }
}

/**
 * Inject additional scripts into a tab
 */
function injectAdditionalScript(tabId, scriptPath) {
  chrome.scripting.executeScript({
    target: { tabId },
    files: [scriptPath]
  }).then(() => {
    logger.debug(`Injected additional script into tab ${tabId}: ${scriptPath}`);
  }).catch(error => {
    logger.error(`Failed to inject script into tab ${tabId}:`, error);
  });
}

/**
 * Get configuration for a specific platform
 */
function getPlatformConfig(platform) {
  return {
    ...config.contentScriptDefaults,
    platformSpecific: config.platformSettings[platform] || {}
  };
}

/**
 * Get URL of a tab
 */
async function getTabUrl(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    return tab.url;
  } catch (error) {
    logger.warn(`Failed to get URL for tab ${tabId}:`, error);
    return null;
  }
}

/**
 * Get active content script connections
 */
export const getActiveConnections = () => {
  return Array.from(activeConnections.entries()).map(([tabId, data]) => ({
    tabId,
    platform: data.platform,
    status: data.status,
    lastActivity: data.lastActivity
  }));
};

/**
 * Send message to a content script
 */
export const sendToContentScript = (tabId, message) => {
  const connection = activeConnections.get(tabId);
  if (!connection || connection.status !== 'connected') {
    logger.warn(`No active connection for tab ${tabId}`);
    return false;
  }
  
  try {
    connection.port.postMessage(message);
    return true;
  } catch (error) {
    logger.error(`Failed to send message to tab ${tabId}:`, error);
    return false;
  }
};