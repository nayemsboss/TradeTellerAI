// background/marketScraper.js
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { normalizeMarketData } from '../services/dataNormalizer';
import { getLookbackWindow } from '../ai/lookbackLogic';
import { fetchWithTimeout } from '../utils/networkUtils';

// Supported data sources with priority order
const DATA_SOURCES = [
  {
    name: 'primary_api',
    url: config.apiEndpoints.primary,
    parser: parsePrimaryApiResponse,
    fallback: true,
    timeout: 5000
  },
  {
    name: 'secondary_api',
    url: config.apiEndpoints.secondary,
    parser: parseSecondaryApiResponse,
    fallback: true,
    timeout: 5000
  },
  {
    name: 'fallback_scraper',
    url: config.scraperEndpoints.fallback,
    parser: parseScrapedData,
    fallback: false,
    timeout: 8000
  }
];

// Cache for scraped data
const dataCache = {
  marketData: null,
  lastUpdated: null,
  sourceUsed: null
};

/**
 * Main function to scrape live market data
 * @param {string} symbol - Trading symbol to scrape data for
 * @param {boolean} forceRefresh - Bypass cache if true
 * @returns {Promise<Object>} Normalized market data
 */
export const scrapeLiveMarketData = async (symbol, forceRefresh = false) => {
  try {
    // Check cache first if not forcing refresh
    if (!forceRefresh && dataCache.marketData && 
        Date.now() - dataCache.lastUpdated < config.cacheTTL) {
      logger.debug(`Returning cached market data for ${symbol} from ${dataCache.sourceUsed}`);
      return dataCache.marketData;
    }

    logger.info(`Starting market data scrape for ${symbol}`);
    
    // Determine optimal lookback window
    const lookback = await getLookbackWindow(symbol);
    
    let scrapedData;
    let lastError;
    
    // Try each data source in priority order
    for (const source of DATA_SOURCES) {
      try {
        logger.debug(`Attempting to fetch from ${source.name}`);
        
        const response = await fetchWithTimeout(
          buildUrl(source.url, symbol, lookback),
          source.timeout
        );
        
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const rawData = await response.json();
        scrapedData = source.parser(rawData, symbol);
        
        // Validate parsed data
        if (!validateMarketData(scrapedData)) {
          throw new Error('Data validation failed');
        }
        
        // Normalize and cache the data
        const normalizedData = normalizeMarketData(scrapedData);
        
        dataCache.marketData = normalizedData;
        dataCache.lastUpdated = Date.now();
        dataCache.sourceUsed = source.name;
        
        logger.info(`Successfully scraped data from ${source.name}`);
        return normalizedData;
      } catch (error) {
        lastError = error;
        logger.warn(`Failed to scrape from ${source.name}: ${error.message}`);
        
        // If this was a fallback source, continue to next
        if (!source.fallback) break;
      }
    }
    
    // All sources failed
    throw new Error(`All data sources failed: ${lastError?.message || 'Unknown error'}`);
  } catch (error) {
    logger.error(`Market data scrape failed for ${symbol}: ${error.message}`);
    
    // Return cached data if available (even if stale)
    if (dataCache.marketData) {
      logger.warn('Returning stale cached data as fallback');
      return dataCache.marketData;
    }
    
    throw error;
  }
};

/**
 * Parse primary API response format
 */
function parsePrimaryApiResponse(data, symbol) {
  if (!data || !data.timeSeries) {
    throw new Error('Invalid primary API response format');
  }

  return {
    symbol,
    meta: {
      source: 'primary_api',
      currency: data.currency || 'USD',
      timezone: data.timezone || 'UTC'
    },
    series: Object.entries(data.timeSeries).map(([timestamp, values]) => ({
      timestamp: parseInt(timestamp),
      open: parseFloat(values.open),
      high: parseFloat(values.high),
      low: parseFloat(values.low),
      close: parseFloat(values.close),
      volume: parseFloat(values.volume) || 0
    })).sort((a, b) => a.timestamp - b.timestamp)
  };
}

/**
 * Parse secondary API response format
 */
function parseSecondaryApiResponse(data, symbol) {
  if (!data || !data.bars) {
    throw new Error('Invalid secondary API response format');
  }

  return {
    symbol,
    meta: {
      source: 'secondary_api',
      currency: data.currency || 'USD',
      timezone: data.timezone || 'UTC'
    },
    series: data.bars.map(bar => ({
      timestamp: new Date(bar.t).getTime(),
      open: bar.o,
      high: bar.h,
      low: bar.l,
      close: bar.c,
      volume: bar.v || 0
    })).sort((a, b) => a.timestamp - b.timestamp)
  };
}

/**
 * Parse HTML scraped data
 */
function parseScrapedData(html, symbol) {
  // This would use DOM parsing in a real implementation
  // For now, we'll mock the structure
  throw new Error('HTML scraping not implemented yet');
}

/**
 * Validate scraped market data structure
 */
function validateMarketData(data) {
  if (!data || !data.symbol || !data.series || !Array.isArray(data.series)) {
    return false;
  }
  
  return data.series.every(point => (
    typeof point.timestamp === 'number' &&
    typeof point.open === 'number' &&
    typeof point.high === 'number' &&
    typeof point.low === 'number' &&
    typeof point.close === 'number' &&
    point.high >= point.low &&
    point.high >= point.open &&
    point.high >= point.close &&
    point.low <= point.open &&
    point.low <= point.close
  ));
}

/**
 * Build URL with parameters for the data source
 */
function buildUrl(baseUrl, symbol, lookback) {
  const params = new URLSearchParams();
  params.append('symbol', symbol);
  params.append('interval', '1m');
  params.append('lookback', lookback);
  params.append('apikey', config.apiKeys.marketData);
  
  return `${baseUrl}?${params.toString()}`;
}

/**
 * Get the current data cache state
 */
export const getDataCacheState = () => ({
  lastUpdated: dataCache.lastUpdated,
  sourceUsed: dataCache.sourceUsed,
  dataSymbol: dataCache.marketData?.symbol || null,
  dataPoints: dataCache.marketData?.series?.length || 0
});