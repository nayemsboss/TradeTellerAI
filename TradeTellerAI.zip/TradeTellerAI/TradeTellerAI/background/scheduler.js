// background/scheduler.js
import { fetchMarketData } from '../services/apiFetcher';
import { normalizeMarketData } from '../services/dataNormalizer';
import { processTechnicalAnalysis } from '../ai/aiProcessor';
import { triggerAlerts } from '../services/alertSystem';
import { logger } from '../utils/logger';
import { config } from '../constants/config';

// Task scheduler configuration
const SCHEDULER_CONFIG = {
  MARKET_DATA_INTERVAL: config.marketDataRefreshInterval || 30000, // 30 seconds
  ANALYSIS_INTERVAL: config.analysisInterval || 60000, // 1 minute
  SENTIMENT_UPDATE_INTERVAL: config.sentimentInterval || 180000, // 3 minutes
  PERFORMANCE_REPORT_INTERVAL: config.performanceInterval || 86400000, // 24 hours
};

// Active timers storage
const activeTimers = {
  marketDataTimer: null,
  analysisTimer: null,
  sentimentTimer: null,
  performanceTimer: null,
};

// Scheduled tasks storage
let scheduledTasks = {
  lastMarketData: null,
  lastAnalysis: null,
  lastSentimentUpdate: null,
};

/**
 * Initialize all scheduled background tasks
 */
export const initScheduler = async () => {
  logger.info('Initializing background scheduler...');
  
  try {
    // Start immediate data fetch on initialization
    await executeMarketDataTask();
    
    // Schedule recurring tasks
    activeTimers.marketDataTimer = setInterval(
      executeMarketDataTask, 
      SCHEDULER_CONFIG.MARKET_DATA_INTERVAL
    );
    
    activeTimers.analysisTimer = setInterval(
      executeAnalysisTask, 
      SCHEDULER_CONFIG.ANALYSIS_INTERVAL
    );
    
    activeTimers.sentimentTimer = setInterval(
      executeSentimentUpdateTask, 
      SCHEDULER_CONFIG.SENTIMENT_UPDATE_INTERVAL
    );
    
    activeTimers.performanceTimer = setInterval(
      executePerformanceReportTask, 
      SCHEDULER_CONFIG.PERFORMANCE_REPORT_INTERVAL
    );
    
    logger.info('Background scheduler initialized successfully');
  } catch (error) {
    logger.error('Failed to initialize scheduler:', error);
    throw error;
  }
};

/**
 * Execute market data fetching task
 */
const executeMarketDataTask = async () => {
  try {
    logger.debug('Executing market data fetch task...');
    const rawData = await fetchMarketData();
    const normalizedData = normalizeMarketData(rawData);
    
    scheduledTasks.lastMarketData = {
      timestamp: Date.now(),
      data: normalizedData,
    };
    
    logger.debug('Market data fetch completed');
  } catch (error) {
    logger.error('Market data fetch failed:', error);
  }
};

/**
 * Execute technical analysis task
 */
const executeAnalysisTask = async () => {
  if (!scheduledTasks.lastMarketData) {
    logger.warn('No market data available for analysis');
    return;
  }
  
  try {
    logger.debug('Executing technical analysis task...');
    const analysisResults = await processTechnicalAnalysis(
      scheduledTasks.lastMarketData.data
    );
    
    scheduledTasks.lastAnalysis = {
      timestamp: Date.now(),
      results: analysisResults,
    };
    
    // Trigger alerts based on analysis
    await triggerAlerts(analysisResults);
    
    logger.debug('Technical analysis completed');
  } catch (error) {
    logger.error('Technical analysis failed:', error);
  }
};

/**
 * Execute sentiment analysis update task
 */
const executeSentimentUpdateTask = async () => {
  try {
    logger.debug('Executing sentiment update task...');
    // This would be implemented with newsScanner service
    scheduledTasks.lastSentimentUpdate = {
      timestamp: Date.now(),
      // Placeholder for actual sentiment data
    };
    logger.debug('Sentiment update completed');
  } catch (error) {
    logger.error('Sentiment update failed:', error);
  }
};

/**
 * Execute performance reporting task
 */
const executePerformanceReportTask = async () => {
  try {
    logger.debug('Executing performance report task...');
    // This would generate daily performance reports
    logger.debug('Performance report generated');
  } catch (error) {
    logger.error('Performance report failed:', error);
  }
};

/**
 * Clean up all scheduled tasks
 */
export const cleanupScheduler = () => {
  logger.info('Cleaning up background scheduler...');
  
  Object.values(activeTimers).forEach(timer => {
    if (timer) clearInterval(timer);
  });
  
  // Clear all stored tasks
  scheduledTasks = {
    lastMarketData: null,
    lastAnalysis: null,
    lastSentimentUpdate: null,
  };
  
  logger.info('Background scheduler cleaned up');
};

/**
 * Get current scheduler status
 */
export const getSchedulerStatus = () => ({
  config: SCHEDULER_CONFIG,
  lastExecution: {
    marketData: scheduledTasks.lastMarketData?.timestamp || null,
    analysis: scheduledTasks.lastAnalysis?.timestamp || null,
    sentiment: scheduledTasks.lastSentimentUpdate?.timestamp || null,
  },
  nextExecution: {
    marketData: scheduledTasks.lastMarketData 
      ? scheduledTasks.lastMarketData.timestamp + SCHEDULER_CONFIG.MARKET_DATA_INTERVAL 
      : null,
    analysis: scheduledTasks.lastAnalysis 
      ? scheduledTasks.lastAnalysis.timestamp + SCHEDULER_CONFIG.ANALYSIS_INTERVAL 
      : null,
    sentiment: scheduledTasks.lastSentimentUpdate 
      ? scheduledTasks.lastSentimentUpdate.timestamp + SCHEDULER_CONFIG.SENTIMENT_UPDATE_INTERVAL 
      : null,
  },
});