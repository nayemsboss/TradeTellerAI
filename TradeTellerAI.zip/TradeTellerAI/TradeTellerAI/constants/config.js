// constants/config.js
/**
 * TradeTellerAI - Core Configuration Constants
 * Centralized configuration for all application parameters
 */

// ----------------------------- APPLICATION CONFIG -----------------------------
export const APP_CONFIG = {
  NAME: 'TradeTellerAI',
  VERSION: '3.2.1',
  BUILD: '2023.12',
  MODE: process.env.NODE_ENV === 'production' ? 'production' : 'development',
  SUPPORTED_BROWSERS: {
    chrome: '>=98',
    firefox: '>=96',
    edge: '>=96',
    safari: '>=15.4'
  },
  DEFAULT_LOCALE: 'en-US',
  SENTRY_DSN: process.env.SENTRY_DSN || '',
  GA_TRACKING_ID: process.env.GA_TRACKING_ID || ''
};

// ----------------------------- TRADING ENGINE CONFIG -----------------------------
export const TRADING_CONFIG = {
  // Core trading parameters
  DEFAULT_SYMBOL: 'EURUSD',
  DEFAULT_TIMEFRAME: 'H1',
  MAX_LOOKBACK_PERIOD: 365, // days
  DATA_REFRESH_INTERVAL: 30000, // ms
  ALLOWED_TIMEFRAMES: ['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D1', 'W1'],

  // Risk management
  DEFAULT_RISK_PERCENT: 1,
  MAX_RISK_PERCENT: 5,
  MIN_POSITION_SIZE: 0.01,
  MAX_LEVERAGE: 30,

  // Trading hours
  MARKET_OPEN_HOURS: {
    forex: '24/5',
    stocks: '09:30-16:00',
    crypto: '24/7'
  },

  // Broker integration
  SUPPORTED_BROKERS: ['OANDA', 'InteractiveBrokers', 'MetaTrader', 'Binance']
};

// ----------------------------- AI MODEL CONFIG -----------------------------
export const AI_CONFIG = {
  // Model versions
  MODEL_VERSIONS: {
    TECHNICAL: 'ttai-ta-v2.1',
    SENTIMENT: 'ttai-sa-v1.4',
    PATTERN: 'ttai-cp-v3.0',
    COMBINED: 'ttai-ai-v4.2'
  },

  // Prediction thresholds
  CONFIDENCE_THRESHOLDS: {
    HIGH: 0.8,
    MEDIUM: 0.6,
    LOW: 0.4
  },

  // Model parameters
  LOOKBACK_WINDOWS: {
    SHORT: 14,
    MEDIUM: 50,
    LONG: 200
  },

  // Training
  TRAINING_INTERVAL: 86400000, // 24 hours in ms
  DATA_POINTS_REQUIRED: 10000
};

// ----------------------------- API CONFIG -----------------------------
export const API_CONFIG = {
  BASE_URL: process.env.API_BASE_URL || 'https://api.tradeteller.ai/v3',
  ENDPOINTS: {
    MARKET_DATA: '/market',
    NEWS_SENTIMENT: '/news/sentiment',
    ACCOUNT_INFO: '/account',
    ORDER_EXECUTION: '/order'
  },
  TIMEOUT: 10000, // ms
  RETRY_ATTEMPTS: 3,
  CACHE_TTL: 60000 // ms
};

// ----------------------------- UI CONFIG -----------------------------
export const UI_CONFIG = {
  THEMES: {
    LIGHT: 'light',
    DARK: 'dark',
    SYSTEM: 'system'
  },
  DEFAULT_THEME: 'dark',
  CHART_CONFIG: {
    DEFAULT_PERIODS: 200,
    MAX_VISIBLE_CANDLES: 500,
    ZOOM_SENSITIVITY: 0.5,
    SCROLL_SENSITIVITY: 0.8
  },
  ALERT_PREFERENCES: {
    SOUND: true,
    NOTIFICATION: true,
    EMAIL: false,
    SMS: false
  }
};

// ----------------------------- PERFORMANCE CONFIG -----------------------------
export const PERFORMANCE_CONFIG = {
  MEMORY_LIMIT: 0.7, // 70% of available memory
  CPU_THROTTLE_THRESHOLD: 0.8,
  DATA_SAMPLING_RATES: {
    REAL_TIME: 1000,
    NORMAL: 5000,
    BACKGROUND: 30000
  },
  LOG_RETENTION: {
    DEBUG: 7, // days
    INFO: 30,
    ERROR: 365
  }
};

// ----------------------------- ERROR HANDLING CONFIG -----------------------------
export const ERROR_CONFIG = {
  REPORTING: {
    ENABLED: true,
    LEVELS: ['error', 'warning'],
    IGNORE: ['NetworkError', 'TimeoutError']
  },
  RECOVERY: {
    MAX_RETRIES: 3,
    RETRY_DELAY: 1000,
    FALLBACKS: {
      MARKET_DATA: 'cached',
      PREDICTIONS: 'simplified'
    }
  }
};

// ----------------------------- FEATURE TOGGLES -----------------------------
export const FEATURE_FLAGS = {
  ADVANCED_CHARTING: true,
  AI_PREDICTIONS: true,
  SOCIAL_SENTIMENT: false, // Beta feature
  BACKTESTING: true,
  PAPER_TRADING: true,
  DARK_POOL_DATA: false // Premium feature
};

// ----------------------------- INTEGRATION CONFIGS -----------------------------
export const INTEGRATION_CONFIG = {
  NEWS_SOURCES: ['Reuters', 'Bloomberg', 'ForexFactory', 'Twitter'],
  CALENDAR_SOURCES: ['FXStreet', 'DailyFX', 'Investing'],
  SOCIAL_MEDIA: {
    TWITTER: {
      API_KEY: process.env.TWITTER_API_KEY || '',
      RATE_LIMIT: 500 // requests per 15min
    },
    REDDIT: {
      API_KEY: process.env.REDDIT_API_KEY || '',
      RATE_LIMIT: 60
    }
  }
};

// ----------------------------- EXPORT ALL CONFIGS -----------------------------
export default {
  APP_CONFIG,
  TRADING_CONFIG,
  AI_CONFIG,
  API_CONFIG,
  UI_CONFIG,
  PERFORMANCE_CONFIG,
  ERROR_CONFIG,
  FEATURE_FLAGS,
  INTEGRATION_CONFIG
};