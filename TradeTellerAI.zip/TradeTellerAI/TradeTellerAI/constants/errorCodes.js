// constants/errorCodes.js
/**
 * TradeTellerAI - Error Codes Configuration
 * Centralized error handling with consistent codes and messages
 */

// ----------------------------- ERROR CATEGORIES -----------------------------
export const ERROR_CATEGORIES = {
  NETWORK: 'NETWORK',
  VALIDATION: 'VALIDATION',
  AUTH: 'AUTH',
  TRADING: 'TRADING',
  AI: 'AI',
  DATABASE: 'DATABASE',
  UI: 'UI',
  UNKNOWN: 'UNKNOWN'
};

// ----------------------------- ERROR CODES -----------------------------
export const ERROR_CODES = {
  // Network errors (1000-1999)
  NETWORK_TIMEOUT: 1001,
  NETWORK_DISCONNECTED: 1002,
  API_RATE_LIMIT: 1003,
  INVALID_RESPONSE: 1004,
  CORS_ERROR: 1005,
  SSL_ERROR: 1006,

  // Validation errors (2000-2999)
  INVALID_INPUT: 2001,
  MISSING_REQUIRED_FIELD: 2002,
  INVALID_SYMBOL: 2003,
  INVALID_TIMEFRAME: 2004,
  INVALID_ORDER_TYPE: 2005,
  INVALID_AMOUNT: 2006,
  INVALID_DATE_RANGE: 2007,

  // Authentication errors (3000-3999)
  UNAUTHORIZED: 3001,
  INVALID_TOKEN: 3002,
  EXPIRED_TOKEN: 3003,
  PERMISSION_DENIED: 3004,
  INVALID_CREDENTIALS: 3005,
  ACCOUNT_LOCKED: 3006,
  IP_RESTRICTED: 3007,

  // Trading errors (4000-4999)
  INSUFFICIENT_FUNDS: 4001,
  POSITION_LIMIT_REACHED: 4002,
  ORDER_REJECTED: 4003,
  MARKET_CLOSED: 4004,
  SLIPPAGE_EXCEEDED: 4005,
  LIQUIDATION: 4006,
  BROKER_ERROR: 4007,
  CONNECTION_LOST: 4008,

  // AI Model errors (5000-5999)
  MODEL_LOAD_FAILED: 5001,
  PREDICTION_FAILED: 5002,
  INSUFFICIENT_DATA: 5003,
  MODEL_TIMEOUT: 5004,
  TRAINING_FAILED: 5005,
  MODEL_VERSION_MISMATCH: 5006,

  // Database errors (6000-6999)
  QUERY_FAILED: 6001,
  RECORD_NOT_FOUND: 6002,
  DUPLICATE_ENTRY: 6003,
  TRANSACTION_FAILED: 6004,
  CONNECTION_POOL_EXHAUSTED: 6005,
  MIGRATION_FAILED: 6006,

  // UI errors (7000-7999)
  RENDER_ERROR: 7001,
  COMPONENT_MOUNT_FAILED: 7002,
  THEME_ERROR: 7003,
  INVALID_ROUTE: 7004,

  // Unknown errors (9000)
  UNEXPECTED_ERROR: 9000
};

// ----------------------------- ERROR MESSAGES -----------------------------
export const ERROR_MESSAGES = {
  // Network errors
  [ERROR_CODES.NETWORK_TIMEOUT]: 'Network request timed out',
  [ERROR_CODES.NETWORK_DISCONNECTED]: 'Network connection lost',
  [ERROR_CODES.API_RATE_LIMIT]: 'API rate limit exceeded',
  [ERROR_CODES.INVALID_RESPONSE]: 'Received invalid response from server',
  [ERROR_CODES.CORS_ERROR]: 'Cross-origin request blocked',
  [ERROR_CODES.SSL_ERROR]: 'SSL connection error',

  // Validation errors
  [ERROR_CODES.INVALID_INPUT]: 'Invalid input provided',
  [ERROR_CODES.MISSING_REQUIRED_FIELD]: 'Required field is missing',
  [ERROR_CODES.INVALID_SYMBOL]: 'Invalid trading symbol',
  [ERROR_CODES.INVALID_TIMEFRAME]: 'Invalid timeframe',
  [ERROR_CODES.INVALID_ORDER_TYPE]: 'Invalid order type',
  [ERROR_CODES.INVALID_AMOUNT]: 'Invalid amount specified',
  [ERROR_CODES.INVALID_DATE_RANGE]: 'Invalid date range',

  // Authentication errors
  [ERROR_CODES.UNAUTHORIZED]: 'Unauthorized access',
  [ERROR_CODES.INVALID_TOKEN]: 'Invalid authentication token',
  [ERROR_CODES.EXPIRED_TOKEN]: 'Authentication token expired',
  [ERROR_CODES.PERMISSION_DENIED]: 'Permission denied',
  [ERROR_CODES.INVALID_CREDENTIALS]: 'Invalid login credentials',
  [ERROR_CODES.ACCOUNT_LOCKED]: 'Account temporarily locked',
  [ERROR_CODES.IP_RESTRICTED]: 'Access restricted from this IP address',

  // Trading errors
  [ERROR_CODES.INSUFFICIENT_FUNDS]: 'Insufficient funds for this trade',
  [ERROR_CODES.POSITION_LIMIT_REACHED]: 'Position limit reached',
  [ERROR_CODES.ORDER_REJECTED]: 'Order rejected by broker',
  [ERROR_CODES.MARKET_CLOSED]: 'Market is currently closed',
  [ERROR_CODES.SLIPPAGE_EXCEEDED]: 'Slippage exceeded maximum threshold',
  [ERROR_CODES.LIQUIDATION]: 'Position liquidated',
  [ERROR_CODES.BROKER_ERROR]: 'Broker connection error',
  [ERROR_CODES.CONNECTION_LOST]: 'Trading connection lost',

  // AI Model errors
  [ERROR_CODES.MODEL_LOAD_FAILED]: 'AI model failed to load',
  [ERROR_CODES.PREDICTION_FAILED]: 'Prediction generation failed',
  [ERROR_CODES.INSUFFICIENT_DATA]: 'Insufficient data for analysis',
  [ERROR_CODES.MODEL_TIMEOUT]: 'Model prediction timed out',
  [ERROR_CODES.TRAINING_FAILED]: 'Model training failed',
  [ERROR_CODES.MODEL_VERSION_MISMATCH]: 'Model version mismatch',

  // Database errors
  [ERROR_CODES.QUERY_FAILED]: 'Database query failed',
  [ERROR_CODES.RECORD_NOT_FOUND]: 'Requested record not found',
  [ERROR_CODES.DUPLICATE_ENTRY]: 'Duplicate entry detected',
  [ERROR_CODES.TRANSACTION_FAILED]: 'Database transaction failed',
  [ERROR_CODES.CONNECTION_POOL_EXHAUSTED]: 'Database connection pool exhausted',
  [ERROR_CODES.MIGRATION_FAILED]: 'Database migration failed',

  // UI errors
  [ERROR_CODES.RENDER_ERROR]: 'UI rendering error',
  [ERROR_CODES.COMPONENT_MOUNT_FAILED]: 'Component failed to mount',
  [ERROR_CODES.THEME_ERROR]: 'Theme configuration error',
  [ERROR_CODES.INVALID_ROUTE]: 'Invalid application route',

  // Unknown errors
  [ERROR_CODES.UNEXPECTED_ERROR]: 'An unexpected error occurred'
};

// ----------------------------- ERROR SEVERITY -----------------------------
export const ERROR_SEVERITY = {
  [ERROR_CODES.NETWORK_TIMEOUT]: 'warning',
  [ERROR_CODES.NETWORK_DISCONNECTED]: 'critical',
  [ERROR_CODES.API_RATE_LIMIT]: 'warning',
  [ERROR_CODES.INVALID_RESPONSE]: 'error',
  [ERROR_CODES.CORS_ERROR]: 'error',
  [ERROR_CODES.SSL_ERROR]: 'critical',

  [ERROR_CODES.INVALID_INPUT]: 'warning',
  [ERROR_CODES.MISSING_REQUIRED_FIELD]: 'warning',
  [ERROR_CODES.INVALID_SYMBOL]: 'warning',
  [ERROR_CODES.INVALID_TIMEFRAME]: 'warning',
  [ERROR_CODES.INVALID_ORDER_TYPE]: 'error',
  [ERROR_CODES.INVALID_AMOUNT]: 'error',
  [ERROR_CODES.INVALID_DATE_RANGE]: 'warning',

  [ERROR_CODES.UNAUTHORIZED]: 'error',
  [ERROR_CODES.INVALID_TOKEN]: 'error',
  [ERROR_CODES.EXPIRED_TOKEN]: 'error',
  [ERROR_CODES.PERMISSION_DENIED]: 'error',
  [ERROR_CODES.INVALID_CREDENTIALS]: 'warning',
  [ERROR_CODES.ACCOUNT_LOCKED]: 'error',
  [ERROR_CODES.IP_RESTRICTED]: 'error',

  [ERROR_CODES.INSUFFICIENT_FUNDS]: 'error',
  [ERROR_CODES.POSITION_LIMIT_REACHED]: 'warning',
  [ERROR_CODES.ORDER_REJECTED]: 'error',
  [ERROR_CODES.MARKET_CLOSED]: 'warning',
  [ERROR_CODES.SLIPPAGE_EXCEEDED]: 'warning',
  [ERROR_CODES.LIQUIDATION]: 'critical',
  [ERROR_CODES.BROKER_ERROR]: 'critical',
  [ERROR_CODES.CONNECTION_LOST]: 'critical',

  [ERROR_CODES.MODEL_LOAD_FAILED]: 'critical',
  [ERROR_CODES.PREDICTION_FAILED]: 'error',
  [ERROR_CODES.INSUFFICIENT_DATA]: 'warning',
  [ERROR_CODES.MODEL_TIMEOUT]: 'warning',
  [ERROR_CODES.TRAINING_FAILED]: 'error',
  [ERROR_CODES.MODEL_VERSION_MISMATCH]: 'error',

  [ERROR_CODES.QUERY_FAILED]: 'error',
  [ERROR_CODES.RECORD_NOT_FOUND]: 'warning',
  [ERROR_CODES.DUPLICATE_ENTRY]: 'warning',
  [ERROR_CODES.TRANSACTION_FAILED]: 'error',
  [ERROR_CODES.CONNECTION_POOL_EXHAUSTED]: 'critical',
  [ERROR_CODES.MIGRATION_FAILED]: 'critical',

  [ERROR_CODES.RENDER_ERROR]: 'error',
  [ERROR_CODES.COMPONENT_MOUNT_FAILED]: 'error',
  [ERROR_CODES.THEME_ERROR]: 'warning',
  [ERROR_CODES.INVALID_ROUTE]: 'warning',

  [ERROR_CODES.UNEXPECTED_ERROR]: 'critical'
};

// ----------------------------- ERROR HANDLING CONFIG -----------------------------
export const ERROR_HANDLING = {
  // Whether to show toast notifications for each error type
  SHOW_TOAST: {
    [ERROR_CATEGORIES.NETWORK]: true,
    [ERROR_CATEGORIES.VALIDATION]: true,
    [ERROR_CATEGORIES.AUTH]: true,
    [ERROR_CATEGORIES.TRADING]: true,
    [ERROR_CATEGORIES.AI]: true,
    [ERROR_CATEGORIES.DATABASE]: false,
    [ERROR_CATEGORIES.UI]: true,
    [ERROR_CATEGORIES.UNKNOWN]: true
  },

  // Whether to log to error tracking system
  LOG_EXTERNALLY: {
    [ERROR_CATEGORIES.NETWORK]: true,
    [ERROR_CATEGORIES.VALIDATION]: false,
    [ERROR_CATEGORIES.AUTH]: true,
    [ERROR_CATEGORIES.TRADING]: true,
    [ERROR_CATEGORIES.AI]: true,
    [ERROR_CATEGORIES.DATABASE]: true,
    [ERROR_CATEGORIES.UI]: true,
    [ERROR_CATEGORIES.UNKNOWN]: true
  },

  // Whether to trigger recovery actions
  AUTO_RECOVER: {
    [ERROR_CODES.NETWORK_TIMEOUT]: true,
    [ERROR_CODES.NETWORK_DISCONNECTED]: true,
    [ERROR_CODES.EXPIRED_TOKEN]: true,
    [ERROR_CODES.CONNECTION_LOST]: true,
    [ERROR_CODES.MODEL_TIMEOUT]: true
  }
};

// ----------------------------- HELPER FUNCTIONS -----------------------------
export const getErrorCategory = (code) => {
  if (code >= 1000 && code < 2000) return ERROR_CATEGORIES.NETWORK;
  if (code >= 2000 && code < 3000) return ERROR_CATEGORIES.VALIDATION;
  if (code >= 3000 && code < 4000) return ERROR_CATEGORIES.AUTH;
  if (code >= 4000 && code < 5000) return ERROR_CATEGORIES.TRADING;
  if (code >= 5000 && code < 6000) return ERROR_CATEGORIES.AI;
  if (code >= 6000 && code < 7000) return ERROR_CATEGORIES.DATABASE;
  if (code >= 7000 && code < 8000) return ERROR_CATEGORIES.UI;
  return ERROR_CATEGORIES.UNKNOWN;
};

export const getErrorMessage = (code) => {
  return ERROR_MESSAGES[code] || ERROR_MESSAGES[ERROR_CODES.UNEXPECTED_ERROR];
};

export const getErrorSeverity = (code) => {
  return ERROR_SEVERITY[code] || 'error';
};

// ----------------------------- EXPORT ALL ERROR CONSTANTS -----------------------------
export default {
  ERROR_CATEGORIES,
  ERROR_CODES,
  ERROR_MESSAGES,
  ERROR_SEVERITY,
  ERROR_HANDLING,
  getErrorCategory,
  getErrorMessage,
  getErrorSeverity
};