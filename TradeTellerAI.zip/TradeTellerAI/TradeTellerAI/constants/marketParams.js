// constants/marketParams.js
/**
 * TradeTellerAI - Market Parameters Configuration
 * Contains all market-specific constants and configurations
 */

// ----------------------------- INSTRUMENT PARAMETERS -----------------------------
export const INSTRUMENT_PARAMS = {
  // Forex majors
  EURUSD: {
    name: 'Euro vs US Dollar',
    type: 'forex',
    pipValue: 0.0001,
    lotSize: 100000,
    minTradeSize: 0.01,
    maxTradeSize: 100,
    marginRate: 0.02, // 2% margin
    spread: 0.0002,
    swapLong: -0.5,
    swapShort: 0.3,
    tradingHours: 'Sun 22:00 - Fri 21:00 GMT',
    volatility: 'medium'
  },
  GBPUSD: {
    name: 'British Pound vs US Dollar',
    type: 'forex',
    pipValue: 0.0001,
    lotSize: 100000,
    minTradeSize: 0.01,
    maxTradeSize: 100,
    marginRate: 0.03,
    spread: 0.0003,
    swapLong: -0.7,
    swapShort: 0.4,
    tradingHours: 'Sun 22:00 - Fri 21:00 GMT',
    volatility: 'high'
  },
  USDJPY: {
    name: 'US Dollar vs Japanese Yen',
    type: 'forex',
    pipValue: 0.01,
    lotSize: 100000,
    minTradeSize: 0.01,
    maxTradeSize: 100,
    marginRate: 0.025,
    spread: 0.03,
    swapLong: 0.2,
    swapShort: -0.8,
    tradingHours: 'Sun 22:00 - Fri 21:00 GMT',
    volatility: 'medium'
  },

  // Indices
  US30: {
    name: 'US 30 Index',
    type: 'index',
    pipValue: 1,
    lotSize: 1,
    minTradeSize: 0.1,
    maxTradeSize: 50,
    marginRate: 0.05,
    spread: 4,
    swapLong: -2,
    swapShort: -1.5,
    tradingHours: 'Mon-Fri 13:30-20:00 GMT',
    volatility: 'high'
  },
  NAS100: {
    name: 'NASDAQ 100 Index',
    type: 'index',
    pipValue: 1,
    lotSize: 1,
    minTradeSize: 0.1,
    maxTradeSize: 50,
    marginRate: 0.05,
    spread: 2.5,
    swapLong: -1.8,
    swapShort: -1.2,
    tradingHours: 'Mon-Fri 13:30-20:00 GMT',
    volatility: 'very-high'
  },

  // Commodities
  XAUUSD: {
    name: 'Gold vs US Dollar',
    type: 'commodity',
    pipValue: 0.01,
    lotSize: 100,
    minTradeSize: 0.01,
    maxTradeSize: 20,
    marginRate: 0.02,
    spread: 0.15,
    swapLong: -1.2,
    swapShort: 0.8,
    tradingHours: 'Sun 22:00 - Fri 21:00 GMT',
    volatility: 'medium'
  },
  XTIUSD: {
    name: 'Crude Oil (WTI)',
    type: 'commodity',
    pipValue: 0.01,
    lotSize: 1000,
    minTradeSize: 0.1,
    maxTradeSize: 50,
    marginRate: 0.03,
    spread: 0.05,
    swapLong: -3.5,
    swapShort: -2.8,
    tradingHours: 'Sun 22:00 - Fri 21:00 GMT',
    volatility: 'high'
  },

  // Cryptocurrencies
  BTCUSD: {
    name: 'Bitcoin vs US Dollar',
    type: 'crypto',
    pipValue: 1,
    lotSize: 1,
    minTradeSize: 0.001,
    maxTradeSize: 5,
    marginRate: 0.1,
    spread: 50,
    swapLong: 0,
    swapShort: 0,
    tradingHours: '24/7',
    volatility: 'extreme'
  },
  ETHUSD: {
    name: 'Ethereum vs US Dollar',
    type: 'crypto',
    pipValue: 0.01,
    lotSize: 1,
    minTradeSize: 0.01,
    maxTradeSize: 10,
    marginRate: 0.1,
    spread: 2.5,
    swapLong: 0,
    swapShort: 0,
    tradingHours: '24/7',
    volatility: 'very-high'
  }
};

// ----------------------------- MARKET SESSION PARAMETERS -----------------------------
export const MARKET_SESSIONS = {
  LONDON: {
    open: 8, // GMT
    close: 16,
    activePairs: ['EURUSD', 'GBPUSD', 'EURGBP', 'XAUUSD'],
    volatilityMultiplier: 1.3
  },
  NEW_YORK: {
    open: 13, // GMT
    close: 20,
    activePairs: ['USDJPY', 'US30', 'NAS100', 'XTIUSD'],
    volatilityMultiplier: 1.5
  },
  TOKYO: {
    open: 0, // GMT
    close: 6,
    activePairs: ['USDJPY', 'AUDJPY', 'NZDJPY'],
    volatilityMultiplier: 1.1
  },
  SYDNEY: {
    open: 22, // GMT (previous day)
    close: 5,
    activePairs: ['AUDUSD', 'NZDUSD', 'AUDNZD'],
    volatilityMultiplier: 1.0
  },
  OVERLAP: {
    LONDON_NEW_YORK: {
      open: 13,
      close: 16,
      volatilityMultiplier: 1.8
    },
    TOKYO_SYDNEY: {
      open: 0,
      close: 2,
      volatilityMultiplier: 1.2
    }
  }
};

// ----------------------------- VOLATILITY PARAMETERS -----------------------------
export const VOLATILITY_PARAMS = {
  LEVELS: {
    extreme: { pct: 0.03, stopLossMultiplier: 3, takeProfitMultiplier: 4 },
    'very-high': { pct: 0.02, stopLossMultiplier: 2.5, takeProfitMultiplier: 3 },
    high: { pct: 0.015, stopLossMultiplier: 2, takeProfitMultiplier: 2.5 },
    medium: { pct: 0.01, stopLossMultiplier: 1.5, takeProfitMultiplier: 2 },
    low: { pct: 0.005, stopLossMultiplier: 1, takeProfitMultiplier: 1.5 }
  },
  TIME_BASED: {
    '00:00-04:00': 0.7, // GMT
    '04:00-08:00': 0.9,
    '08:00-12:00': 1.1,
    '12:00-16:00': 1.4,
    '16:00-20:00': 1.2,
    '20:00-00:00': 0.8
  },
  NEWS_IMPACT: {
    high: 2.0,
    medium: 1.5,
    low: 1.2
  }
};

// ----------------------------- ECONOMIC CALENDAR PARAMETERS -----------------------------
export const ECONOMIC_CALENDAR = {
  IMPACT_LEVELS: {
    high: ['NFP', 'CPI', 'Interest Rate Decision', 'FOMC'],
    medium: ['Retail Sales', 'GDP', 'PMI', 'Unemployment Rate'],
    low: ['Consumer Confidence', 'Building Permits', 'PPI']
  },
  CURRENCY_IMPORTANCE: {
    USD: ['NFP', 'CPI', 'Interest Rate Decision'],
    EUR: ['ECB Rate Decision', 'GDP', 'CPI'],
    JPY: ['BOJ Policy Statement', 'Unemployment Rate'],
    GBP: ['BOE Rate Decision', 'Retail Sales'],
    AUD: ['RBA Rate Decision', 'Trade Balance'],
    CAD: ['BOC Rate Decision', 'Employment Change']
  }
};

// ----------------------------- CORRELATION MATRIX -----------------------------
export const CORRELATION_MATRIX = {
  EURUSD: {
    GBPUSD: 0.7,
    USDJPY: -0.6,
    XAUUSD: -0.4,
    US30: -0.3
  },
  GBPUSD: {
    EURUSD: 0.7,
    USDJPY: -0.5,
    XAUUSD: -0.3,
    US30: -0.2
  },
  USDJPY: {
    EURUSD: -0.6,
    GBPUSD: -0.5,
    US30: 0.8,
    NAS100: 0.7
  },
  XAUUSD: {
    EURUSD: -0.4,
    GBPUSD: -0.3,
    USDJPY: 0.2,
    US30: -0.7
  }
};

// ----------------------------- HOLIDAY SCHEDULES -----------------------------
export const MARKET_HOLIDAYS = {
  FOREX: [
    '2023-01-01', // New Year's Day
    '2023-12-25', // Christmas
    '2023-12-26'  // Boxing Day
  ],
  US: [
    '2023-01-02', // New Year's (observed)
    '2023-01-16', // MLK Day
    '2023-02-20', // Presidents Day
    '2023-04-07', // Good Friday
    '2023-05-29', // Memorial Day
    '2023-07-04', // Independence Day
    '2023-09-04', // Labor Day
    '2023-11-23', // Thanksgiving
    '2023-12-25'  // Christmas
  ],
  UK: [
    '2023-01-02', // New Year's (observed)
    '2023-04-07', // Good Friday
    '2023-04-10', // Easter Monday
    '2023-05-01', // Early May Bank Holiday
    '2023-05-29', // Spring Bank Holiday
    '2023-08-28', // Summer Bank Holiday
    '2023-12-25', // Christmas
    '2023-12-26'  // Boxing Day
  ]
};

// ----------------------------- EXPORT ALL MARKET PARAMS -----------------------------
export default {
  INSTRUMENT_PARAMS,
  MARKET_SESSIONS,
  VOLATILITY_PARAMS,
  ECONOMIC_CALENDAR,
  CORRELATION_MATRIX,
  MARKET_HOLIDAYS
};