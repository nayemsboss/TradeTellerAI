// constants/patternDefinitions.js
/**
 * TradeTellerAI - Candlestick Pattern Definitions
 * Comprehensive definitions for all recognized candlestick patterns
 */

// ----------------------------- PATTERN CATEGORIES -----------------------------
export const PATTERN_CATEGORIES = {
  REVERSAL: 'reversal',
  CONTINUATION: 'continuation',
  NEUTRAL: 'neutral'
};

// ----------------------------- SINGLE CANDLE PATTERNS -----------------------------
export const SINGLE_CANDLE_PATTERNS = {
  DOJI: {
    name: 'Doji',
    category: PATTERN_CATEGORIES.NEUTRAL,
    description: 'Indicates market indecision with nearly equal open and close',
    recognition: {
      bodyRatio: 0.05,        // Body should be ≤5% of total range
      upperShadowRatio: 0.5,  // Upper shadow should be ≥50% of total range
      lowerShadowRatio: 0.5,  // Lower shadow should be ≥50% of total range
      trendRequirement: null  // Works in any trend
    },
    confirmation: {
      nextCandleDirection: null, // No specific confirmation needed
      volumeIncrease: false
    },
    reliability: {
      uptrend: 0.5,
      downtrend: 0.5,
      neutral: 0.6
    }
  },
  HAMMER: {
    name: 'Hammer',
    category: PATTERN_CATEGORIES.REVERSAL,
    description: 'Bullish reversal pattern after a downtrend',
    recognition: {
      bodyRatio: 0.3,         // Body should be ≤30% of total range
      upperShadowRatio: 0.1,  // Upper shadow should be ≤10% of body size
      lowerShadowRatio: 2,    // Lower shadow should be ≥2x body size
      trendRequirement: 'downtrend' // Must occur in downtrend
    },
    confirmation: {
      nextCandleDirection: 'up',
      volumeIncrease: true
    },
    reliability: {
      uptrend: 0.3,
      downtrend: 0.7,
      neutral: 0.4
    }
  },
  INVERTED_HAMMER: {
    name: 'Inverted Hammer',
    category: PATTERN_CATEGORIES.REVERSAL,
    description: 'Potential bullish reversal after downtrend',
    recognition: {
      bodyRatio: 0.3,
      upperShadowRatio: 2,
      lowerShadowRatio: 0.1,
      trendRequirement: 'downtrend'
    },
    confirmation: {
      nextCandleDirection: 'up',
      volumeIncrease: true
    },
    reliability: {
      uptrend: 0.3,
      downtrend: 0.65,
      neutral: 0.4
    }
  },
  SHOOTING_STAR: {
    name: 'Shooting Star',
    category: PATTERN_CATEGORIES.REVERSAL,
    description: 'Bearish reversal pattern after an uptrend',
    recognition: {
      bodyRatio: 0.3,
      upperShadowRatio: 2,
      lowerShadowRatio: 0.1,
      trendRequirement: 'uptrend'
    },
    confirmation: {
      nextCandleDirection: 'down',
      volumeIncrease: true
    },
    reliability: {
      uptrend: 0.7,
      downtrend: 0.3,
      neutral: 0.4
    }
  },
  HANGING_MAN: {
    name: 'Hanging Man',
    category: PATTERN_CATEGORIES.REVERSAL,
    description: 'Bearish reversal pattern after an uptrend',
    recognition: {
      bodyRatio: 0.3,
      upperShadowRatio: 0.1,
      lowerShadowRatio: 2,
      trendRequirement: 'uptrend'
    },
    confirmation: {
      nextCandleDirection: 'down',
      volumeIncrease: true
    },
    reliability: {
      uptrend: 0.7,
      downtrend: 0.3,
      neutral: 0.4
    }
  }
};

// ----------------------------- MULTI-CANDLE PATTERNS -----------------------------
export const MULTI_CANDLE_PATTERNS = {
  ENGULFING: {
    name: 'Engulfing',
    category: PATTERN_CATEGORIES.REVERSAL,
    description: 'Strong reversal signal where the second candle fully engulfs the first',
    candleCount: 2,
    recognition: {
      firstCandle: {
        bodyRatio: 0.8, // Normal body size
        direction: null // Any direction
      },
      secondCandle: {
        bodyRatio: 1.2, // Larger than normal body
        direction: null // Opposite of first
      },
      engulfingRequirement: true, // Must fully engulf
      trendRequirement: true // Must be against prevailing trend
    },
    confirmation: {
      nextCandleDirection: 'same_as_second',
      volumeIncrease: true
    },
    reliability: {
      bullish: 0.75,
      bearish: 0.78,
      neutral: 0.5
    },
    subtypes: {
      BULLISH: {
        firstCandleDirection: 'down',
        secondCandleDirection: 'up'
      },
      BEARISH: {
        firstCandleDirection: 'up',
        secondCandleDirection: 'down'
      }
    }
  },
  HARAMI: {
    name: 'Harami',
    category: PATTERN_CATEGORIES.REVERSAL,
    description: 'Potential reversal or consolidation pattern',
    candleCount: 2,
    recognition: {
      firstCandle: {
        bodyRatio: 0.8,
        direction: null
      },
      secondCandle: {
        bodyRatio: 0.5,
        direction: 'opposite'
      },
      containmentRequirement: true, // Second candle must be contained within first
      trendRequirement: true
    },
    confirmation: {
      nextCandleDirection: 'same_as_second',
      volumeIncrease: false
    },
    reliability: {
      bullish: 0.6,
      bearish: 0.62,
      neutral: 0.45
    }
  },
  MORNING_STAR: {
    name: 'Morning Star',
    category: PATTERN_CATEGORIES.REVERSAL,
    description: 'Bullish reversal pattern consisting of three candles',
    candleCount: 3,
    recognition: {
      firstCandle: {
        bodyRatio: 0.8,
        direction: 'down'
      },
      secondCandle: {
        bodyRatio: 0.2,
        direction: 'neutral' // Doji-like
      },
      thirdCandle: {
        bodyRatio: 0.8,
        direction: 'up'
      },
      gapRequirement: true, // Gaps between candles
      trendRequirement: 'downtrend'
    },
    confirmation: {
      nextCandleDirection: 'up',
      volumeIncrease: true
    },
    reliability: {
      bullish: 0.82,
      bearish: 0.1,
      neutral: 0.3
    }
  },
  EVENING_STAR: {
    name: 'Evening Star',
    category: PATTERN_CATEGORIES.REVERSAL,
    description: 'Bearish reversal pattern consisting of three candles',
    candleCount: 3,
    recognition: {
      firstCandle: {
        bodyRatio: 0.8,
        direction: 'up'
      },
      secondCandle: {
        bodyRatio: 0.2,
        direction: 'neutral'
      },
      thirdCandle: {
        bodyRatio: 0.8,
        direction: 'down'
      },
      gapRequirement: true,
      trendRequirement: 'uptrend'
    },
    confirmation: {
      nextCandleDirection: 'down',
      volumeIncrease: true
    },
    reliability: {
      bullish: 0.1,
      bearish: 0.85,
      neutral: 0.3
    }
  },
  THREE_WHITE_SOLDIERS: {
    name: 'Three White Soldiers',
    category: PATTERN_CATEGORIES.CONTINUATION,
    description: 'Strong bullish continuation pattern',
    candleCount: 3,
    recognition: {
      allCandles: {
        bodyRatio: 0.7,
        direction: 'up'
      },
      consecutiveHigherCloses: true,
      smallShadows: true
    },
    confirmation: {
      nextCandleDirection: 'up',
      volumeIncrease: true
    },
    reliability: {
      bullish: 0.88,
      bearish: 0.05,
      neutral: 0.4
    }
  },
  THREE_BLACK_CROWS: {
    name: 'Three Black Crows',
    category: PATTERN_CATEGORIES.CONTINUATION,
    description: 'Strong bearish continuation pattern',
    candleCount: 3,
    recognition: {
      allCandles: {
        bodyRatio: 0.7,
        direction: 'down'
      },
      consecutiveLowerCloses: true,
      smallShadows: true
    },
    confirmation: {
      nextCandleDirection: 'down',
      volumeIncrease: true
    },
    reliability: {
      bullish: 0.05,
      bearish: 0.86,
      neutral: 0.4
    }
  },
  PIERCING_LINE: {
    name: 'Piercing Line',
    category: PATTERN_CATEGORIES.REVERSAL,
    description: 'Bullish reversal pattern in downtrends',
    candleCount: 2,
    recognition: {
      firstCandle: {
        bodyRatio: 0.8,
        direction: 'down'
      },
      secondCandle: {
        bodyRatio: 0.8,
        direction: 'up'
      },
      penetrationRequirement: 0.5 // Second candle closes at least halfway into first
    },
    confirmation: {
      nextCandleDirection: 'up',
      volumeIncrease: true
    },
    reliability: {
      bullish: 0.72,
      bearish: 0.1,
      neutral: 0.3
    }
  },
  DARK_CLOUD_COVER: {
    name: 'Dark Cloud Cover',
    category: PATTERN_CATEGORIES.REVERSAL,
    description: 'Bearish reversal pattern in uptrends',
    candleCount: 2,
    recognition: {
      firstCandle: {
        bodyRatio: 0.8,
        direction: 'up'
      },
      secondCandle: {
        bodyRatio: 0.8,
        direction: 'down'
      },
      penetrationRequirement: 0.5 // Second candle closes at least halfway into first
    },
    confirmation: {
      nextCandleDirection: 'down',
      volumeIncrease: true
    },
    reliability: {
      bullish: 0.1,
      bearish: 0.75,
      neutral: 0.3
    }
  }
};

// ----------------------------- PATTERN RECOGNITION PARAMETERS -----------------------------
export const PATTERN_RECOGNITION = {
  // General recognition thresholds
  MIN_BODY_RATIO: 0.05,       // Minimum body size to be considered a valid candle
  MAX_DOJI_BODY_RATIO: 0.05,  // Maximum body size for a doji
  SHADOW_RATIO: 0.1,          // Minimum shadow size ratio

  // Trend requirements
  TREND_MIN_CANDLES: 5,       // Minimum candles to establish a trend
  TREND_CONFIRMATION_PCT: 0.6, // Percentage of candles confirming trend

  // Volume confirmation
  VOLUME_THRESHOLD: 1.2,      // 20% increase for confirmation
  MIN_VOLUME: 1000,           // Minimum volume to consider

  // Pattern scoring
  BASE_CONFIDENCE: 0.5,       // Base confidence for any pattern
  CONFIRMATION_BOOST: 0.3,    // Confidence boost from confirmation
  VOLUME_BOOST: 0.2,          // Confidence boost from volume
  TREND_BOOST: 0.25,          // Confidence boost from strong trend

  // Timeframe considerations
  TIMEFRAME_MULTIPLIERS: {
    'M1': 0.7,
    'M5': 0.8,
    'M15': 0.9,
    'M30': 1.0,
    'H1': 1.1,
    'H4': 1.2,
    'D1': 1.3,
    'W1': 1.5
  }
};

// ----------------------------- PATTERN UTILITIES -----------------------------
export const getPatternByName = (name) => {
  // Search single candle patterns
  for (const [key, pattern] of Object.entries(SINGLE_CANDLE_PATTERNS)) {
    if (pattern.name.toLowerCase() === name.toLowerCase()) {
      return { ...pattern, type: 'single' };
    }
  }

  // Search multi-candle patterns
  for (const [key, pattern] of Object.entries(MULTI_CANDLE_PATTERNS)) {
    if (pattern.name.toLowerCase() === name.toLowerCase()) {
      return { ...pattern, type: 'multi' };
    }
  }

  return null;
};

export const getAllPatternNames = () => {
  const singleNames = Object.values(SINGLE_CANDLE_PATTERNS).map(p => p.name);
  const multiNames = Object.values(MULTI_CANDLE_PATTERNS).map(p => p.name);
  return [...singleNames, ...multiNames];
};

// ----------------------------- EXPORT ALL PATTERN DEFINITIONS -----------------------------
export default {
  PATTERN_CATEGORIES,
  SINGLE_CANDLE_PATTERNS,
  MULTI_CANDLE_PATTERNS,
  PATTERN_RECOGNITION,
  getPatternByName,
  getAllPatternNames
};