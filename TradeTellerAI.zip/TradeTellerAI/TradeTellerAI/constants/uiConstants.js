// constants/uiConstants.js
/**
 * TradeTellerAI - UI Constants Configuration
 * Contains all user interface constants, dimensions, and styling configurations
 */

// ----------------------------- LAYOUT DIMENSIONS -----------------------------
export const LAYOUT = {
  // Main application dimensions
  HEADER_HEIGHT: 60,
  FOOTER_HEIGHT: 40,
  SIDEBAR_WIDTH: 280,
  SIDEBAR_COLLAPSED_WIDTH: 80,
  CHART_TOOLBAR_HEIGHT: 48,
  ORDER_PANEL_WIDTH: 320,

  // Dashboard grid
  DASHBOARD_GRID: {
    COLUMNS: 24,
    ROW_HEIGHT: 30,
    MARGIN: [10, 10],
    CONTAINER_PADDING: [10, 10],
    MIN_ROW_HEIGHT: 30,
    MAX_ROW_HEIGHT: 100
  },

  // Mobile breakpoints
  BREAKPOINTS: {
    XS: 480,
    SM: 768,
    MD: 992,
    LG: 1200,
    XL: 1600
  }
};

// ----------------------------- CHART STYLING -----------------------------
export const CHART_STYLES = {
  // Candlestick styles
  CANDLE: {
    UP: {
      COLOR: '#26A69A',
      WICK_COLOR: '#26A69A',
      BORDER_COLOR: '#26A69A',
      BODY_BORDER: 1
    },
    DOWN: {
      COLOR: '#EF5350',
      WICK_COLOR: '#EF5350',
      BORDER_COLOR: '#EF5350',
      BODY_BORDER: 1
    },
    NEUTRAL: {
      COLOR: '#78909C',
      WICK_COLOR: '#78909C',
      BORDER_COLOR: '#78909C',
      BODY_BORDER: 1
    },
    WICK_WIDTH: 1,
    BORDER_WIDTH: 1
  },

  // Volume styles
  VOLUME: {
    UP: {
      COLOR: 'rgba(38, 166, 154, 0.3)',
      LINE_COLOR: '#26A69A'
    },
    DOWN: {
      COLOR: 'rgba(239, 83, 80, 0.3)',
      LINE_COLOR: '#EF5350'
    },
    WIDTH_RATIO: 0.8
  },

  // Technical indicator styles
  INDICATORS: {
    SMA: {
      COLOR: '#2962FF',
      WIDTH: 1.5,
      DASH: []
    },
    EMA: {
      COLOR: '#FF6D00',
      WIDTH: 1.5,
      DASH: [5, 3]
    },
    BOLLINGER: {
      UPPER: {
        COLOR: '#7B1FA2',
        WIDTH: 1,
        DASH: [5, 2]
      },
      LOWER: {
        COLOR: '#7B1FA2',
        WIDTH: 1,
        DASH: [5, 2]
      },
      MIDDLE: {
        COLOR: '#7B1FA2',
        WIDTH: 1.5,
        DASH: []
      }
    },
    RSI: {
      LINE: {
        COLOR: '#0091EA',
        WIDTH: 1.5
      },
      OVERBOUGHT: {
        VALUE: 70,
        COLOR: 'rgba(239, 83, 80, 0.1)'
      },
      OVERSOLD: {
        VALUE: 30,
        COLOR: 'rgba(38, 166, 154, 0.1)'
      }
    },
    MACD: {
      LINE: {
        COLOR: '#26C6DA',
        WIDTH: 1.5
      },
      SIGNAL: {
        COLOR: '#FF4081',
        WIDTH: 1.5
      },
      HISTOGRAM: {
        UP: '#26A69A',
        DOWN: '#EF5350',
        WIDTH: 0.8
      }
    }
  },

  // Crosshair and annotations
  CROSSHAIR: {
    COLOR: '#B0BEC5',
    WIDTH: 0.5,
    DASH: [3, 3]
  },
  ANNOTATIONS: {
    BUY: {
      COLOR: '#26A69A',
      MARKER: 'circle',
      SIZE: 8
    },
    SELL: {
      COLOR: '#EF5350',
      MARKER: 'circle',
      SIZE: 8
    },
    NEWS: {
      HIGH: {
        COLOR: '#FF5252',
        MARKER: 'square',
        SIZE: 6
      },
      MEDIUM: {
        COLOR: '#FFC107',
        MARKER: 'square',
        SIZE: 6
      },
      LOW: {
        COLOR: '#757575',
        MARKER: 'square',
        SIZE: 6
      }
    }
  },

  // Axis and grid
  AXIS: {
    COLOR: '#607D8B',
    WIDTH: 1,
    FONT_SIZE: 11,
    FONT_FAMILY: 'Roboto, sans-serif'
  },
  GRID: {
    COLOR: 'rgba(96, 125, 139, 0.2)',
    WIDTH: 0.5,
    DASH: [2, 2]
  },

  // Background and general
  BACKGROUND: {
    COLOR: '#FFFFFF',
    SECONDARY: '#F5F5F5'
  },
  TEXT: {
    COLOR: '#263238',
    SECONDARY: '#78909C',
    FONT_FAMILY: 'Roboto, sans-serif',
    FONT_SIZE: 12
  }
};

// ----------------------------- DARK THEME OVERRIDES -----------------------------
export const DARK_THEME = {
  ...CHART_STYLES,
  CANDLE: {
    UP: {
      COLOR: '#00C805',
      WICK_COLOR: '#00C805',
      BORDER_COLOR: '#00C805'
    },
    DOWN: {
      COLOR: '#FF3B3B',
      WICK_COLOR: '#FF3B3B',
      BORDER_COLOR: '#FF3B3B'
    },
    NEUTRAL: {
      COLOR: '#78909C',
      WICK_COLOR: '#78909C',
      BORDER_COLOR: '#78909C'
    }
  },
  VOLUME: {
    UP: {
      COLOR: 'rgba(0, 200, 5, 0.3)',
      LINE_COLOR: '#00C805'
    },
    DOWN: {
      COLOR: 'rgba(255, 59, 59, 0.3)',
      LINE_COLOR: '#FF3B3B'
    }
  },
  BACKGROUND: {
    COLOR: '#121826',
    SECONDARY: '#1E2130'
  },
  TEXT: {
    COLOR: '#E0E0E0',
    SECONDARY: '#90A4AE'
  },
  AXIS: {
    COLOR: '#90A4AE'
  },
  GRID: {
    COLOR: 'rgba(144, 164, 174, 0.2)'
  }
};

// ----------------------------- UI COMPONENT STYLES -----------------------------
export const COMPONENT_STYLES = {
  // Buttons
  BUTTON: {
    PRIMARY: {
      BG: '#2962FF',
      TEXT: '#FFFFFF',
      HOVER: '#0039CB',
      ACTIVE: '#0026A0'
    },
    SECONDARY: {
      BG: '#ECEFF1',
      TEXT: '#37474F',
      HOVER: '#CFD8DC',
      ACTIVE: '#B0BEC5'
    },
    DANGER: {
      BG: '#EF5350',
      TEXT: '#FFFFFF',
      HOVER: '#D32F2F',
      ACTIVE: '#B71C1C'
    },
    SUCCESS: {
      BG: '#26A69A',
      TEXT: '#FFFFFF',
      HOVER: '#00897B',
      ACTIVE: '#00695C'
    },
    SIZE: {
      SMALL: {
        PADDING: '4px 8px',
        FONT_SIZE: '12px'
      },
      MEDIUM: {
        PADDING: '6px 12px',
        FONT_SIZE: '14px'
      },
      LARGE: {
        PADDING: '8px 16px',
        FONT_SIZE: '16px'
      }
    }
  },

  // Inputs
  INPUT: {
    BORDER: '1px solid #CFD8DC',
    BORDER_FOCUS: '1px solid #2962FF',
    BORDER_ERROR: '1px solid #EF5350',
    BORDER_RADIUS: '4px',
    PADDING: '8px 12px',
    BG: '#FFFFFF',
    BG_DISABLED: '#ECEFF1',
    TEXT: '#263238',
    PLACEHOLDER: '#90A4AE',
    SHADOW: '0 1px 2px rgba(0,0,0,0.05)',
    SHADOW_FOCUS: '0 0 0 3px rgba(41,98,255,0.1)'
  },

  // Tooltips
  TOOLTIP: {
    BG: '#263238',
    TEXT: '#FFFFFF',
    BORDER_RADIUS: '4px',
    PADDING: '8px 12px',
    FONT_SIZE: '13px',
    ARROW_SIZE: '6px',
    SHADOW: '0 2px 8px rgba(0,0,0,0.15)',
    MAX_WIDTH: '300px'
  },

  // Cards
  CARD: {
    BG: '#FFFFFF',
    BORDER: '1px solid #ECEFF1',
    BORDER_RADIUS: '8px',
    PADDING: '16px',
    SHADOW: '0 1px 3px rgba(0,0,0,0.05)',
    HOVER_SHADOW: '0 4px 12px rgba(0,0,0,0.1)'
  }
};

// ----------------------------- ANIMATION CONSTANTS -----------------------------
export const ANIMATIONS = {
  DURATIONS: {
    FAST: '150ms',
    NORMAL: '300ms',
    SLOW: '500ms'
  },
  EASING: {
    STANDARD: 'cubic-bezier(0.4, 0, 0.2, 1)',
    DECELERATE: 'cubic-bezier(0.0, 0.0, 0.2, 1)',
    ACCELERATE: 'cubic-bezier(0.4, 0.0, 1, 1)'
  },
  TRANSITIONS: {
    FADE: 'opacity 150ms cubic-bezier(0.4, 0, 0.2, 1)',
    SLIDE: 'transform 300ms cubic-bezier(0.4, 0, 0.2, 1)',
    SCALE: 'transform 200ms cubic-bezier(0.4, 0, 0.2, 1)'
  }
};

// ----------------------------- Z-INDEX LAYERS -----------------------------
export const Z_INDEX = {
  MODAL: 1000,
  DROPDOWN: 800,
  TOOLTIP: 600,
  HEADER: 400,
  CHART: 200,
  BASE: 1
};

// ----------------------------- ICON SIZES -----------------------------
export const ICON_SIZES = {
  XS: 12,
  SM: 16,
  MD: 24,
  LG: 32,
  XL: 48
};

// ----------------------------- EXPORT ALL UI CONSTANTS -----------------------------
export default {
  LAYOUT,
  CHART_STYLES,
  DARK_THEME,
  COMPONENT_STYLES,
  ANIMATIONS,
  Z_INDEX,
  ICON_SIZES
};