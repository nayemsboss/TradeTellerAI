// content/domObserver.js
import { logger } from '../../utils/logger';
import { DOMUtils } from './domUtils';

export class DOMObserver {
  constructor() {
    this.observer = null;
    this.config = {
      chartContainerSelectors: [
        '.chart-container',
        '.pane-legend',
        '.chart-markup-table'
      ],
      orderFormSelectors: [
        '.order-form',
        '.trade-dialog',
        '.order-entry'
      ],
      watchlistSelectors: [
        '.watchlist',
        '.symbol-list',
        '.market-quotes'
      ],
      mutationObserverConfig: {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class', 'style', 'data-state']
      }
    };
    this.lastMutationTime = 0;
    this.debounceTimer = null;
    this.importantChanges = new Set([
      'price-update',
      'volume-change',
      'indicator-value',
      'position-update',
      'order-status'
    ]);
  }

  /**
   * Initialize the DOM observer
   * @param {Function} callback - Function to call when relevant changes are detected
   */
  init(callback) {
    if (typeof callback !== 'function') {
      throw new Error('DOMObserver requires a callback function');
    }

    this.callback = callback;
    this.domUtils = new DOMUtils();
    logger.debug('DOMObserver initialized');
  }

  /**
   * Start observing the DOM
   */
  start() {
    if (this.observer) {
      this.stop();
    }

    this.observer = new MutationObserver(this.handleMutations.bind(this));
    
    // Start observing the document body
    this.observer.observe(document.body, this.config.mutationObserverConfig);
    
    // Also observe specific important elements if they exist
    this.config.chartContainerSelectors.forEach(selector => {
      const element = document.querySelector(selector);
      if (element) {
        this.observer.observe(element, this.config.mutationObserverConfig);
      }
    });

    logger.info('DOMObserver started');
  }

  /**
   * Stop observing the DOM
   */
  stop() {
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
      logger.debug('DOMObserver stopped');
    }
  }

  /**
   * Handle mutation records
   * @param {Array} mutations - Array of MutationRecord objects
   */
  handleMutations(mutations) {
    const now = Date.now();
    this.lastMutationTime = now;

    // Debounce rapid mutations
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
    }

    this.debounceTimer = setTimeout(() => {
      const relevantMutations = this.filterRelevantMutations(mutations);
      if (relevantMutations.length > 0) {
        this.callback(relevantMutations);
      }
    }, 100); // 100ms debounce period
  }

  /**
   * Filter mutations to only include relevant changes
   * @param {Array} mutations - Array of MutationRecord objects
   * @returns {Array} Filtered array of relevant mutations
   */
  filterRelevantMutations(mutations) {
    return mutations.filter(mutation => {
      // Check attribute changes
      if (mutation.type === 'attributes') {
        return this.isRelevantAttributeChange(mutation);
      }

      // Check added nodes
      if (mutation.addedNodes && mutation.addedNodes.length > 0) {
        return this.containsRelevantNodes(mutation.addedNodes);
      }

      // Check for chart/order/watchlist elements
      return this.isInRelevantContainer(mutation.target);
    });
  }

  /**
   * Check if an attribute change is relevant
   */
  isRelevantAttributeChange(mutation) {
    const target = mutation.target;
    
    // Check for important class changes
    if (mutation.attributeName === 'class') {
      const classList = target.classList;
      for (const cls of classList) {
        if (this.importantChanges.has(cls)) {
          return true;
        }
      }
    }
    
    // Check for data-state changes in trading elements
    if (mutation.attributeName === 'data-state') {
      return target.closest(this.config.orderFormSelectors.join(', ')) ||
             target.closest(this.config.chartContainerSelectors.join(', '));
    }
    
    return false;
  }

  /**
   * Check if added nodes contain relevant elements
   */
  containsRelevantNodes(nodes) {
    return Array.from(nodes).some(node => {
      // Skip text nodes
      if (node.nodeType !== Node.ELEMENT_NODE) return false;
      
      // Check if node matches any important selectors
      if (this.domUtils.matchesAny(node, this.getImportantSelectors())) {
        return true;
      }
      
      // Check if node contains any important elements
      return this.domUtils.containsAny(node, this.getImportantSelectors());
    });
  }

  /**
   * Check if mutation target is in a relevant container
   */
  isInRelevantContainer(target) {
    return target.closest([
      ...this.config.chartContainerSelectors,
      ...this.config.orderFormSelectors,
      ...this.config.watchlistSelectors
    ].join(', '));
  }

  /**
   * Get all important selectors for this platform
   */
  getImportantSelectors() {
    return [
      ...this.config.chartContainerSelectors,
      ...this.config.orderFormSelectors,
      ...this.config.watchlistSelectors,
      ...[...this.importantChanges].map(change => `.${change}`)
    ];
  }

  /**
   * Get the current state of observed DOM elements
   */
  getCurrentDOMState() {
    const state = {
      timestamp: Date.now(),
      charts: this.getChartState(),
      orderForms: this.getOrderFormState(),
      watchlists: this.getWatchlistState(),
      indicators: this.getIndicatorState()
    };

    return state;
  }

  /**
   * Get current chart DOM state
   */
  getChartState() {
    return this.config.chartContainerSelectors
      .map(selector => ({
        selector,
        elements: Array.from(document.querySelectorAll(selector))
          .map(el => this.domUtils.getElementInfo(el))
      }))
      .filter(group => group.elements.length > 0);
  }

  /**
   * Get current order form DOM state
   */
  getOrderFormState() {
    return this.config.orderFormSelectors
      .map(selector => ({
        selector,
        elements: Array.from(document.querySelectorAll(selector))
          .map(el => this.domUtils.getElementInfo(el))
      }))
      .filter(group => group.elements.length > 0);
  }

  /**
   * Get current watchlist DOM state
   */
  getWatchlistState() {
    return this.config.watchlistSelectors
      .map(selector => ({
        selector,
        elements: Array.from(document.querySelectorAll(selector))
          .map(el => this.domUtils.getElementInfo(el))
      }))
      .filter(group => group.elements.length > 0);
  }

  /**
   * Get current indicator DOM state
   */
  getIndicatorState() {
    const indicators = [];
    
    // Find all indicator elements (implementation varies by platform)
    const indicatorElements = document.querySelectorAll([
      '.indicator-value',
      '.study-legend',
      '[data-indicator]'
    ].join(', '));
    
    indicatorElements.forEach(el => {
      indicators.push({
        name: el.dataset.indicatorName || el.textContent.trim(),
        value: el.dataset.indicatorValue || el.textContent.trim(),
        element: this.domUtils.getElementInfo(el)
      });
    });
    
    return indicators;
  }
}