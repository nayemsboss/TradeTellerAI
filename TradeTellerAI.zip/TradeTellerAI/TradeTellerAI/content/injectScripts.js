// content/injectScripts.js
import { logger } from '../../utils/logger';
import { DOMObserver } from './domObserver';
import { TradeDetector } from './tradeDetector';
import { ChartAnalyzer } from './chartAnalyzer';
import { BrokerUIParser } from './brokerUIParser';

// Establish connection with background script
const port = chrome.runtime.connect({
  name: `tradeTellerContentScript_${detectPlatform()}`
});

// Initialize modules
const domObserver = new DOMObserver();
const tradeDetector = new TradeDetector();
const chartAnalyzer = new ChartAnalyzer();
const brokerUIParser = new BrokerUIParser();

// Content script state
const state = {
  platform: null,
  isAnalysisComplete: false,
  pageData: {},
  config: {}
};

/**
 * Main initialization function
 */
async function init() {
  try {
    // Identify the trading platform
    state.platform = detectPlatform();
    
    // Wait for the page to fully load
    await waitForPageReady();
    
    // Get configuration from background
    state.config = await getConfig();
    
    logger.info(`TradeTellerAI content script initialized on ${state.platform}`);
    
    // Initialize modules
    domObserver.init(onDomChange);
    tradeDetector.init(onTradeDetected);
    
    // Start page analysis
    analyzePage();
    
    // Set up message listener
    chrome.runtime.onMessage.addListener(handleBackgroundMessage);
    
    // Notify background script we're ready
    port.postMessage({ 
      type: 'CONTENT_SCRIPT_READY',
      platform: state.platform
    });
    
  } catch (error) {
    logger.error('Content script initialization failed:', error);
    port.postMessage({
      type: 'CONTENT_SCRIPT_ERROR',
      error: error.message
    });
  }
}

/**
 * Detect which trading platform we're on
 */
function detectPlatform() {
  const hostname = window.location.hostname;
  
  if (hostname.includes('tradingview')) {
    return 'tradingview';
  } else if (hostname.includes('metatrader')) {
    return 'metatrader';
  } else if (hostname.includes('ninjatrader')) {
    return 'ninjatrader';
  } else if (hostname.includes('thinkorswim')) {
    return 'thinkorswim';
  }
  
  return 'unknown';
}

/**
 * Wait for the page to be fully ready
 */
function waitForPageReady() {
  return new Promise((resolve) => {
    if (document.readyState === 'complete') {
      resolve();
    } else {
      window.addEventListener('load', resolve);
    }
  });
}

/**
 * Get configuration from background script
 */
function getConfig() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { type: 'REQUEST_CONFIG' },
      (response) => resolve(response?.config || {})
    );
  });
}

/**
 * Analyze the trading page
 */
async function analyzePage() {
  try {
    logger.debug('Starting page analysis...');
    
    // Extract basic page information
    state.pageData = {
      url: window.location.href,
      title: document.title,
      timestamp: Date.now(),
      platform: state.platform,
      accountInfo: brokerUIParser.extractAccountInfo(),
      chartData: chartAnalyzer.analyzeCurrentChart(),
      uiElements: brokerUIParser.detectUIElements()
    };
    
    // Perform initial DOM analysis
    analyzeDOM();
    
    // Set up mutation observer for dynamic content
    domObserver.start();
    
    // Mark analysis as complete
    state.isAnalysisComplete = true;
    
    logger.info('Page analysis completed');
    
    // Send results to background script
    port.postMessage({
      type: 'PAGE_ANALYSIS_READY',
      data: state.pageData
    });
    
  } catch (error) {
    logger.error('Page analysis failed:', error);
    port.postMessage({
      type: 'PAGE_ANALYSIS_ERROR',
      error: error.message
    });
  }
}

/**
 * Analyze the current DOM state
 */
function analyzeDOM() {
  state.pageData.domAnalysis = {
    chartElements: chartAnalyzer.detectChartElements(),
    orderElements: brokerUIParser.detectOrderElements(),
    watchlistElements: brokerUIParser.detectWatchlists(),
    timeframes: chartAnalyzer.detectAvailableTimeframes(),
    indicators: chartAnalyzer.detectActiveIndicators()
  };
}

/**
 * Handle DOM changes detected by the observer
 */
function onDomChange(mutations) {
  try {
    const relevantChanges = domObserver.filterRelevantMutations(mutations);
    
    if (relevantChanges.length > 0) {
      logger.debug('Relevant DOM changes detected:', relevantChanges.length);
      
      // Update our page data
      state.pageData.domAnalysis = analyzeDOM();
      
      // Check for trade opportunities
      const opportunities = tradeDetector.scanForOpportunities();
      
      if (opportunities.length > 0) {
        port.postMessage({
          type: 'TRADE_OPPORTUNITIES_DETECTED',
          opportunities
        });
      }
      
      // Send DOM event to background
      port.postMessage({
        type: 'DOM_EVENT_DETECTED',
        event: {
          type: 'DOM_UPDATE',
          changes: relevantChanges,
          timestamp: Date.now()
        }
      });
    }
  } catch (error) {
    logger.error('Error handling DOM changes:', error);
  }
}

/**
 * Handle detected trades
 */
function onTradeDetected(tradeData) {
  try {
    logger.info('Trade detected:', tradeData);
    
    // Enhance trade data with current context
    const enhancedTrade = {
      ...tradeData,
      chartState: chartAnalyzer.getCurrentChartState(),
      indicators: chartAnalyzer.getActiveIndicators(),
      accountInfo: brokerUIParser.extractAccountInfo()
    };
    
    port.postMessage({
      type: 'TRADE_EXECUTION_DETECTED',
      tradeData: enhancedTrade
    });
    
  } catch (error) {
    logger.error('Error handling trade detection:', error);
  }
}

/**
 * Handle messages from background script
 */
function handleBackgroundMessage(message, sender, sendResponse) {
  try {
    logger.debug('Received message from background:', message.type);
    
    switch (message.type) {
      case 'REQUEST_DOM_ANALYSIS':
        sendResponse({
          success: true,
          data: state.pageData.domAnalysis
        });
        break;
        
      case 'REQUEST_CHART_DATA':
        sendResponse({
          success: true,
          data: chartAnalyzer.getCurrentChartState()
        });
        break;
        
      case 'INJECT_INDICATOR':
        chartAnalyzer.addIndicator(message.indicator)
          .then(() => sendResponse({ success: true }))
          .catch(error => sendResponse({ 
            success: false, 
            error: error.message 
          }));
        return true; // Keep message channel open
          
      case 'HIGHLIGHT_ELEMENT':
        brokerUIParser.highlightElement(message.elementId)
          .then(() => sendResponse({ success: true }))
          .catch(error => sendResponse({ 
            success: false, 
            error: error.message 
          }));
        return true;
        
      default:
        logger.warn('Unknown message type:', message.type);
        sendResponse({ success: false, error: 'Unknown message type' });
    }
  } catch (error) {
    logger.error('Error handling background message:', error);
    sendResponse({ 
      success: false, 
      error: error.message 
    });
  }
}

/**
 * Clean up event listeners and observers
 */
function cleanup() {
  domObserver.stop();
  tradeDetector.cleanup();
  port.disconnect();
  chrome.runtime.onMessage.removeListener(handleBackgroundMessage);
}

// Start the content script
init();

// Handle page unload
window.addEventListener('beforeunload', cleanup);

// Error handling
window.addEventListener('error', (event) => {
  logger.error('Unhandled error in content script:', event.error);
  port.postMessage({
    type: 'CONTENT_SCRIPT_ERROR',
    error: event.error.message
  });
});