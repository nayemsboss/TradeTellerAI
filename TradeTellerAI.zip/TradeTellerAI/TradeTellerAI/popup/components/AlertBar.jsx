// popup/components/AlertBar.jsx
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Icon } from './Icon';
import { playAlertSound } from '../../utils/audioFeedback';
import { formatTime } from '../../utils/dateUtils';
import { useAlertSubscription } from '../../services/alertSystem';

/**
 * AlertBar - Displays real-time trading alerts with priority levels
 * @param {Object} props - Component props
 * @param {string} props.symbol - Trading symbol to filter alerts
 * @param {number} props.maxAlerts - Maximum alerts to display
 * @param {boolean} props.autoDismiss - Whether to auto-dismiss alerts
 */
export const AlertBar = ({ symbol, maxAlerts = 3, autoDismiss = true }) => {
  const [alerts, setAlerts] = useState([]);
  const [visibleAlerts, setVisibleAlerts] = useState([]);
  const [expanded, setExpanded] = useState(false);
  
  // Subscribe to alert updates
  const newAlert = useAlertSubscription(symbol);
  
  useEffect(() => {
    if (newAlert) {
      // Play sound based on alert priority
      playAlertSound(newAlert.priority);
      
      // Add new alert to the beginning of the array
      setAlerts(prev => [newAlert, ...prev]);
      
      // Add to visible alerts
      setVisibleAlerts(prev => [newAlert, ...prev.slice(0, maxAlerts - 1)]);
      
      // Auto-dismiss after timeout if enabled
      if (autoDismiss) {
        const timer = setTimeout(() => {
          setVisibleAlerts(prev => prev.filter(a => a.id !== newAlert.id));
        }, newAlert.priority === 'high' ? 10000 : 5000);
        
        return () => clearTimeout(timer);
      }
    }
  }, [newAlert, maxAlerts, autoDismiss]);
  
  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'var(--alert-high)';
      case 'medium': return 'var(--alert-medium)';
      case 'low': return 'var(--alert-low)';
      default: return 'var(--alert-default)';
    }
  };
  
  const handleDismiss = (id) => {
    setVisibleAlerts(prev => prev.filter(a => a.id !== id));
  };
  
  const handleExpand = () => {
    setExpanded(!expanded);
    if (!expanded) {
      setVisibleAlerts(alerts.slice(0, maxAlerts * 2));
    } else {
      setVisibleAlerts(alerts.slice(0, maxAlerts));
    }
  };

  return (
    <div className={`alert-bar ${expanded ? 'expanded' : ''}`}>
      <div className="alert-header" onClick={handleExpand}>
        <Icon name="bell" size={18} />
        <h4>Market Alerts</h4>
        <span className="alert-count">{alerts.length}</span>
        <Icon 
          name={expanded ? 'chevron-up' : 'chevron-down'} 
          size={16} 
          className="expand-icon" 
        />
      </div>
      
      <div className="alert-list">
        {visibleAlerts.length > 0 ? (
          visibleAlerts.map(alert => (
            <div 
              key={alert.id}
              className={`alert-item priority-${alert.priority}`}
              style={{ borderLeftColor: getPriorityColor(alert.priority) }}
            >
              <div className="alert-content">
                <div className="alert-meta">
                  <span className="alert-time">{formatTime(alert.timestamp)}</span>
                  <span className="alert-symbol">{alert.symbol}</span>
                  <span className="alert-type">{alert.type}</span>
                </div>
                <p className="alert-message">{alert.message}</p>
                {alert.action && (
                  <div className="alert-action">
                    <span className="action-label">Suggested Action:</span>
                    <span className="action-value">{alert.action}</span>
                  </div>
                )}
              </div>
              <button 
                className="dismiss-button"
                onClick={() => handleDismiss(alert.id)}
                aria-label="Dismiss alert"
              >
                <Icon name="x" size={14} />
              </button>
            </div>
          ))
        ) : (
          <div className="no-alerts">
            <Icon name="bell-off" size={20} />
            <p>No active alerts</p>
          </div>
        )}
      </div>
      
      {alerts.length > maxAlerts && (
        <div className="alert-footer" onClick={handleExpand}>
          {expanded ? (
            <>
              <span>Show less</span>
              <Icon name="chevron-up" size={14} />
            </>
          ) : (
            <>
              <span>Show {alerts.length - maxAlerts} more</span>
              <Icon name="chevron-down" size={14} />
            </>
          )}
        </div>
      )}
    </div>
  );
};

AlertBar.propTypes = {
  symbol: PropTypes.string,
  maxAlerts: PropTypes.number,
  autoDismiss: PropTypes.bool
};

AlertBar.defaultProps = {
  maxAlerts: 3,
  autoDismiss: true
};

// Export styles for use in parent component
export const alertBarStyles = `
  .alert-bar {
    background: var(--alert-bar-bg);
    border-radius: 8px;
    overflow: hidden;
    margin-bottom: 16px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
    
    &.expanded {
      .alert-list {
        max-height: 500px;
      }
    }
  }
  
  .alert-header {
    display: flex;
    align-items: center;
    padding: 12px 16px;
    cursor: pointer;
    user-select: none;
    background: var(--alert-header-bg);
    
    h4 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
      flex-grow: 1;
      margin-left: 8px;
    }
    
    .alert-count {
      background: var(--alert-count-bg);
      color: var(--alert-count-text);
      font-size: 12px;
      font-weight: bold;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-right: 8px;
    }
    
    .expand-icon {
      transition: transform 0.2s ease;
    }
    
    &:hover {
      background: var(--alert-header-hover);
    }
  }
  
  .alert-list {
    max-height: 300px;
    overflow-y: auto;
    transition: max-height 0.3s ease;
  }
  
  .alert-item {
    display: flex;
    padding: 12px 16px;
    border-left: 3px solid;
    background: var(--alert-item-bg);
    transition: all 0.2s ease;
    
    &:not(:last-child) {
      border-bottom: 1px solid var(--alert-divider);
    }
    
    &.priority-high {
      background: var(--alert-item-high-bg);
    }
    
    &.priority-medium {
      background: var(--alert-item-medium-bg);
    }
    
    &:hover {
      background: var(--alert-item-hover);
    }
  }
  
  .alert-content {
    flex-grow: 1;
    min-width: 0;
  }
  
  .alert-meta {
    display: flex;
    gap: 8px;
    margin-bottom: 6px;
    font-size: 12px;
    
    span {
      opacity: 0.8;
    }
    
    .alert-time {
      font-weight: 500;
    }
    
    .alert-symbol {
      font-weight: bold;
    }
    
    .alert-type {
      text-transform: uppercase;
      letter-spacing: 0.5px;
      font-size: 11px;
      padding: 1px 4px;
      border-radius: 3px;
      background: var(--alert-type-bg);
    }
  }
  
  .alert-message {
    margin: 0;
    font-size: 13px;
    line-height: 1.4;
  }
  
  .alert-action {
    margin-top: 8px;
    font-size: 12px;
    display: flex;
    gap: 6px;
    
    .action-label {
      font-weight: 500;
    }
    
    .action-value {
      font-weight: bold;
    }
  }
  
  .dismiss-button {
    background: none;
    border: none;
    cursor: pointer;
    opacity: 0.5;
    margin-left: 8px;
    align-self: flex-start;
    padding: 4px;
    
    &:hover {
      opacity: 1;
    }
  }
  
  .no-alerts {
    padding: 20px;
    text-align: center;
    color: var(--text-secondary);
    
    p {
      margin: 8px 0 0 0;
      font-size: 13px;
    }
  }
  
  .alert-footer {
    padding: 10px 16px;
    text-align: center;
    font-size: 13px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    background: var(--alert-footer-bg);
    border-top: 1px solid var(--alert-divider);
    
    &:hover {
      background: var(--alert-footer-hover);
    }
    
    span {
      font-weight: 500;
    }
  }
`;