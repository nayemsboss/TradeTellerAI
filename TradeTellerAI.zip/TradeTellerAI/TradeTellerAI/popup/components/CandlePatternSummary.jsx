// popup/components/CandlePatternSummary.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { Icon } from './Icon';
import { getPatternDetails } from '../../utils/candleUtils';
import '../../assets/styles/_candle-patterns.scss';

/**
 * CandlePatternSummary - Displays detailed information about a recognized candlestick pattern
 * @param {Object} props - Component props
 * @param {string} props.pattern - Name of the candlestick pattern
 * @param {string} [props.trend] - Current market trend ('bullish' or 'bearish')
 * @param {number} [props.confidence] - Confidence score (0-100)
 * @param {boolean} [props.compact=false] - Whether to show compact version
 */
export const CandlePatternSummary = ({ pattern, trend, confidence, compact = false }) => {
  if (!pattern) return null;

  const patternInfo = getPatternDetails(pattern);
  if (!patternInfo) return null;

  const renderConfidence = () => {
    if (confidence === undefined || confidence === null) return null;
    
    let confidenceClass = '';
    if (confidence >= 80) confidenceClass = 'high';
    else if (confidence >= 50) confidenceClass = 'medium';
    else confidenceClass = 'low';

    return (
      <div className="confidence-indicator">
        <div className="confidence-label">Confidence:</div>
        <div className={`confidence-value ${confidenceClass}`}>
          {confidence}%
          <Icon 
            name={confidence >= 50 ? 'trend-up' : 'trend-down'} 
            size={12} 
            className="confidence-icon" 
          />
        </div>
      </div>
    );
  };

  const renderTrendIndicator = () => {
    if (!trend) return null;
    
    return (
      <div className="trend-indicator">
        <span className="trend-label">Trend:</span>
        <span className={`trend-value ${trend}`}>
          {trend}
          <Icon 
            name={trend === 'bullish' ? 'arrow-up' : 'arrow-down'} 
            size={12} 
            className="trend-icon" 
          />
        </span>
      </div>
    );
  };

  return (
    <div className={`candle-pattern-summary ${compact ? 'compact' : ''}`}>
      <div className="pattern-header">
        <div className="pattern-name-container">
          <h4 className="pattern-name">{patternInfo.name}</h4>
          {patternInfo.type && (
            <span className={`pattern-type ${patternInfo.type}`}>
              {patternInfo.type}
            </span>
          )}
        </div>
        {!compact && patternInfo.image && (
          <div className="pattern-image">
            <img 
              src={patternInfo.image} 
              alt={patternInfo.name} 
              loading="lazy"
            />
          </div>
        )}
      </div>

      {!compact && (
        <div className="pattern-description">
          {patternInfo.description}
        </div>
      )}

      <div className="pattern-details">
        {!compact && (
          <>
            <div className="detail-row">
              <span className="detail-label">Pattern:</span>
              <span className="detail-value">{patternInfo.pattern}</span>
            </div>
            <div className="detail-row">
              <span className="detail-label">Reliability:</span>
              <span className="detail-value">{patternInfo.reliability}/5</span>
            </div>
            <div className="detail-row">
              <span className="detail-label">Timeframe:</span>
              <span className="detail-value">{patternInfo.timeframe || 'All'}</span>
            </div>
          </>
        )}

        <div className="pattern-metrics">
          {renderTrendIndicator()}
          {renderConfidence()}
        </div>
      </div>

      {!compact && patternInfo.interpretation && (
        <div className="pattern-interpretation">
          <h5>Interpretation:</h5>
          <p>{patternInfo.interpretation}</p>
        </div>
      )}

      {!compact && patternInfo.tradingTips && (
        <div className="pattern-tips">
          <h5>Trading Tips:</h5>
          <ul>
            {patternInfo.tradingTips.map((tip, index) => (
              <li key={index}>{tip}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

CandlePatternSummary.propTypes = {
  pattern: PropTypes.string.isRequired,
  trend: PropTypes.oneOf(['bullish', 'bearish']),
  confidence: PropTypes.number,
  compact: PropTypes.bool
};

CandlePatternSummary.defaultProps = {
  compact: false
};

// Export styles for use in parent component
export const candlePatternSummaryStyles = `
  .candle-pattern-summary {
    background: var(--pattern-summary-bg);
    border-radius: 8px;
    padding: 16px;
    border-left: 4px solid var(--pattern-summary-border);
    margin-bottom: 16px;

    &.compact {
      padding: 12px;
      margin-bottom: 8px;

      .pattern-header {
        margin-bottom: 0;
      }
    }
  }

  .pattern-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 12px;
    gap: 16px;
  }

  .pattern-name-container {
    flex-grow: 1;
  }

  .pattern-name {
    margin: 0 0 4px 0;
    font-size: 16px;
    color: var(--pattern-name);
  }

  .pattern-type {
    display: inline-block;
    font-size: 12px;
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: 500;
    text-transform: uppercase;

    &.reversal {
      background: var(--pattern-type-reversal-bg);
      color: var(--pattern-type-reversal-text);
    }

    &.continuation {
      background: var(--pattern-type-continuation-bg);
      color: var(--pattern-type-continuation-text);
    }

    &.indecision {
      background: var(--pattern-type-indecision-bg);
      color: var(--pattern-type-indecision-text);
    }
  }

  .pattern-image {
    width: 80px;
    height: 60px;
    border-radius: 4px;
    overflow: hidden;
    flex-shrink: 0;
    border: 1px solid var(--pattern-image-border);

    img {
      width: 100%;
      height: 100%;
      object-fit: contain;
    }
  }

  .pattern-description {
    font-size: 14px;
    line-height: 1.4;
    margin-bottom: 12px;
    color: var(--pattern-description);
  }

  .pattern-details {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-bottom: 12px;

    @media (max-width: 480px) {
      grid-template-columns: 1fr;
    }
  }

  .detail-row {
    display: flex;
    justify-content: space-between;
    font-size: 13px;
    margin-bottom: 6px;

    &:last-child {
      margin-bottom: 0;
    }
  }

  .detail-label {
    font-weight: 500;
    opacity: 0.8;
  }

  .detail-value {
    font-weight: 600;
  }

  .pattern-metrics {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .trend-indicator, .confidence-indicator {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
  }

  .trend-label, .confidence-label {
    opacity: 0.8;
  }

  .trend-value {
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 4px;

    &.bullish {
      color: var(--trend-bullish);
    }

    &.bearish {
      color: var(--trend-bearish);
    }
  }

  .confidence-value {
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 4px;

    &.high {
      color: var(--confidence-high);
    }

    &.medium {
      color: var(--confidence-medium);
    }

    &.low {
      color: var(--confidence-low);
    }
  }

  .pattern-interpretation {
    margin-top: 12px;
    padding-top: 12px;
    border-top: 1px solid var(--pattern-section-border);

    h5 {
      margin: 0 0 8px 0;
      font-size: 14px;
    }

    p {
      margin: 0;
      font-size: 13px;
      line-height: 1.4;
    }
  }

  .pattern-tips {
    margin-top: 12px;
    padding-top: 12px;
    border-top: 1px solid var(--pattern-section-border);

    h5 {
      margin: 0 0 8px 0;
      font-size: 14px;
    }

    ul {
      margin: 0;
      padding-left: 18px;
    }

    li {
      font-size: 13px;
      line-height: 1.4;
      margin-bottom: 4px;

      &:last-child {
        margin-bottom: 0;
      }
    }
  }
`;