// popup/components/CombinedAnalysis.jsx
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Icon } from './Icon';
import { GaugeMeter } from '../../ui/widgets/GaugeMeter';
import { DecisionMatrix } from '../../ui/widgets/DecisionMatrix';
import { useCombinedAnalysis } from '../../services/performanceAnalyzer';
import { formatTime } from '../../utils/dateUtils';
import { calculateConfidenceScore } from '../../utils/statsCalculator';
import '../../assets/styles/_combined-analysis.scss';

/**
 * CombinedAnalysis - Displays unified AI trading recommendation combining multiple analysis types
 * @param {Object} props - Component props
 * @param {string} props.symbol - Trading symbol to analyze
 * @param {boolean} props.showBreakdown - Whether to show detailed breakdown
 */
export const CombinedAnalysis = ({ symbol, showBreakdown = true }) => {
  const [activeFactor, setActiveFactor] = useState('all');
  const { analysis, loading, error } = useCombinedAnalysis(symbol);
  
  const confidenceScore = analysis ? calculateConfidenceScore(analysis) : 0;
  const lastUpdated = analysis ? formatTime(analysis.timestamp) : '--';

  const renderFactorScore = (factor) => {
    if (!analysis) return null;
    
    const score = analysis.factors[factor].score;
    const direction = analysis.factors[factor].direction;
    const weight = analysis.factors[factor].weight;
    
    return (
      <div 
        className={`factor-score ${factor} ${activeFactor === factor ? 'active' : ''}`}
        onClick={() => setActiveFactor(factor)}
      >
        <div className="factor-header">
          <Icon 
            name={factor === 'technical' ? 'trending-up' : 
                  factor === 'fundamental' ? 'file-text' : 'message-square'} 
            size={16} 
          />
          <span className="factor-name">{factor}</span>
          <span className="factor-weight">{weight}x</span>
        </div>
        <div className="factor-meter">
          <GaugeMeter 
            value={score} 
            direction={direction} 
            size={60} 
            showValue={true}
          />
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="combined-analysis loading">
        <div className="spinner">
          <Icon name="loading" size={24} />
        </div>
        <p>Computing combined analysis...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="combined-analysis error">
        <Icon name="warning" size={20} />
        <p>Failed to load analysis</p>
        <small>{error.message}</small>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="combined-analysis empty">
        <Icon name="sliders" size={24} />
        <p>No analysis available</p>
      </div>
    );
  }

  return (
    <div className="combined-analysis">
      <div className="analysis-header">
        <h3>
          <Icon name="cpu" size={18} />
          AI Fusion Analysis
        </h3>
        <div className="last-updated">
          <Icon name="clock" size={14} />
          <span>Updated: {lastUpdated}</span>
        </div>
      </div>

      <div className="confidence-display">
        <div className="confidence-meter">
          <GaugeMeter 
            value={confidenceScore} 
            direction={analysis.direction} 
            size={120} 
            showValue={true}
            label="Confidence"
          />
        </div>
        <div className="decision-summary">
          <h4 className={`decision ${analysis.direction.toLowerCase()}`}>
            {analysis.direction} {analysis.symbol}
          </h4>
          <p className="recommendation">{analysis.recommendation}</p>
          <div className="timeframe">
            <Icon name="calendar" size={14} />
            <span>Optimal Timeframe: {analysis.timeframe}</span>
          </div>
        </div>
      </div>

      <div className="factor-scores">
        {renderFactorScore('technical')}
        {renderFactorScore('sentiment')}
        {renderFactorScore('fundamental')}
        <div 
          className={`factor-score all ${activeFactor === 'all' ? 'active' : ''}`}
          onClick={() => setActiveFactor('all')}
        >
          <div className="factor-header">
            <Icon name="layers" size={16} />
            <span className="factor-name">combined</span>
          </div>
          <div className="factor-meter">
            <DecisionMatrix 
              technical={analysis.factors.technical.score}
              sentiment={analysis.factors.sentiment.score}
              fundamental={analysis.factors.fundamental.score}
              size={60}
            />
          </div>
        </div>
      </div>

      {showBreakdown && (
        <div className="analysis-breakdown">
          <h4>
            <Icon name="activity" size={16} />
            {activeFactor === 'all' ? 'Combined Factors' : `${activeFactor.charAt(0).toUpperCase() + activeFactor.slice(1)} Analysis`}
          </h4>
          
          {activeFactor === 'all' ? (
            <div className="combined-breakdown">
              <div className="matrix-container">
                <DecisionMatrix 
                  technical={analysis.factors.technical.score}
                  sentiment={analysis.factors.sentiment.score}
                  fundamental={analysis.factors.fundamental.score}
                  size={200}
                  interactive={true}
                />
              </div>
              <div className="factor-details">
                <div className="factor-row">
                  <span className="factor-label">Technical:</span>
                  <span className="factor-value">
                    {analysis.factors.technical.score.toFixed(1)} (
                    {analysis.factors.technical.direction})
                  </span>
                  <div className="factor-rationale">
                    {analysis.factors.technical.summary}
                  </div>
                </div>
                <div className="factor-row">
                  <span className="factor-label">Sentiment:</span>
                  <span className="factor-value">
                    {analysis.factors.sentiment.score.toFixed(1)} (
                    {analysis.factors.sentiment.direction})
                  </span>
                  <div className="factor-rationale">
                    {analysis.factors.sentiment.summary}
                  </div>
                </div>
                <div className="factor-row">
                  <span className="factor-label">Fundamental:</span>
                  <span className="factor-value">
                    {analysis.factors.fundamental.score.toFixed(1)} (
                    {analysis.factors.fundamental.direction})
                  </span>
                  <div className="factor-rationale">
                    {analysis.factors.fundamental.summary}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="factor-breakdown">
              <div className="breakdown-content">
                <h5 className="breakdown-title">
                  Key Indicators ({analysis.factors[activeFactor].indicators.length})
                </h5>
                <ul className="indicator-list">
                  {analysis.factors[activeFactor].indicators.map((indicator, i) => (
                    <li key={i} className="indicator-item">
                      <span className="indicator-name">{indicator.name}</span>
                      <span className={`indicator-value ${indicator.impact}`}>
                        {indicator.value}
                        <Icon 
                          name={indicator.impact === 'positive' ? 'arrow-up' : 'arrow-down'} 
                          size={12} 
                        />
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="breakdown-rationale">
                <h5 className="breakdown-title">AI Rationale</h5>
                <p>{analysis.factors[activeFactor].rationale}</p>
                {analysis.factors[activeFactor].warning && (
                  <div className="breakdown-warning">
                    <Icon name="alert-triangle" size={14} />
                    <span>{analysis.factors[activeFactor].warning}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      <div className="action-buttons">
        <button className="action-button primary">
          <Icon name="zap" size={16} />
          Execute Trade
        </button>
        <button className="action-button secondary">
          <Icon name="save" size={16} />
          Save Analysis
        </button>
        <button className="action-button tertiary">
          <Icon name="refresh-cw" size={16} />
          Recalculate
        </button>
      </div>
    </div>
  );
};

CombinedAnalysis.propTypes = {
  symbol: PropTypes.string.isRequired,
  showBreakdown: PropTypes.bool
};

CombinedAnalysis.defaultProps = {
  showBreakdown: true
};

// Export styles for use in parent component
export const combinedAnalysisStyles = `
  .combined-analysis {
    background: var(--combined-bg);
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 16px;

    &.loading, &.error, &.empty {
      text-align: center;
      padding: 24px 16px;

      p {
        margin: 12px 0 0 0;
      }

      small {
        display: block;
        margin-top: 4px;
        font-size: 11px;
        opacity: 0.7;
      }
    }

    &.empty {
      color: var(--text-secondary);
    }
  }

  .analysis-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;

    h3 {
      margin: 0;
      font-size: 16px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .last-updated {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 12px;
      opacity: 0.7;
    }
  }

  .confidence-display {
    display: flex;
    align-items: center;
    gap: 24px;
    margin-bottom: 20px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--divider-color);

    @media (max-width: 600px) {
      flex-direction: column;
      gap: 16px;
    }
  }

  .confidence-meter {
    flex-shrink: 0;
  }

  .decision-summary {
    flex-grow: 1;

    .decision {
      margin: 0 0 8px 0;
      font-size: 18px;

      &.buy {
        color: var(--signal-buy);
      }

      &.sell {
        color: var(--signal-sell);
      }

      &.neutral {
        color: var(--signal-neutral);
      }
    }

    .recommendation {
      margin: 0 0 8px 0;
      font-size: 14px;
      line-height: 1.4;
    }

    .timeframe {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 13px;
      opacity: 0.8;
    }
  }

  .factor-scores {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    margin-bottom: 20px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--divider-color);

    @media (max-width: 768px) {
      grid-template-columns: repeat(2, 1fr);
    }

    @media (max-width: 480px) {
      grid-template-columns: 1fr;
    }
  }

  .factor-score {
    background: var(--factor-bg);
    border-radius: 6px;
    padding: 12px;
    cursor: pointer;
    transition: all 0.2s ease;
    text-align: center;

    &:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    &.active {
      background: var(--factor-active-bg);
      border: 1px solid var(--factor-active-border);
    }

    &.technical.active {
      border-color: var(--factor-technical);
    }

    &.sentiment.active {
      border-color: var(--factor-sentiment);
    }

    &.fundamental.active {
      border-color: var(--factor-fundamental);
    }

    .factor-header {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      margin-bottom: 8px;
      font-size: 13px;
    }

    .factor-name {
      text-transform: capitalize;
      font-weight: 500;
    }

    .factor-weight {
      background: var(--factor-weight-bg);
      color: var(--factor-weight-text);
      font-size: 11px;
      padding: 1px 4px;
      border-radius: 4px;
    }

    .factor-meter {
      display: flex;
      justify-content: center;
    }
  }

  .analysis-breakdown {
    margin-bottom: 20px;

    h4 {
      margin: 0 0 16px 0;
      font-size: 15px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
  }

  .combined-breakdown {
    display: flex;
    gap: 24px;

    @media (max-width: 768px) {
      flex-direction: column;
    }
  }

  .matrix-container {
    flex-shrink: 0;
  }

  .factor-details {
    flex-grow: 1;
  }

  .factor-row {
    margin-bottom: 16px;

    &:last-child {
      margin-bottom: 0;
    }
  }

  .factor-label {
    display: block;
    font-weight: 500;
    margin-bottom: 4px;
    font-size: 14px;
  }

  .factor-value {
    display: block;
    font-weight: 600;
    margin-bottom: 6px;
    font-size: 13px;
  }

  .factor-rationale {
    font-size: 13px;
    line-height: 1.4;
    opacity: 0.9;
  }

  .factor-breakdown {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px;

    @media (max-width: 768px) {
      grid-template-columns: 1fr;
    }
  }

  .breakdown-content {
    background: var(--breakdown-content-bg);
    border-radius: 6px;
    padding: 16px;
  }

  .breakdown-title {
    margin: 0 0 12px 0;
    font-size: 14px;
  }

  .indicator-list {
    list-style: none;
    padding: 0;
    margin: 0;
  }

  .indicator-item {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    border-bottom: 1px solid var(--indicator-border);
    font-size: 13px;

    &:last-child {
      border-bottom: none;
    }
  }

  .indicator-name {
    opacity: 0.8;
  }

  .indicator-value {
    font-weight: 600;

    &.positive {
      color: var(--indicator-positive);
    }

    &.negative {
      color: var(--indicator-negative);
    }
  }

  .breakdown-rationale {
    background: var(--breakdown-rationale-bg);
    border-radius: 6px;
    padding: 16px;
  }

  .breakdown-warning {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-top: 12px;
    padding: 8px;
    background: var(--breakdown-warning-bg);
    border-radius: 4px;
    color: var(--breakdown-warning-text);
    font-size: 13px;
  }

  .action-buttons {
    display: flex;
    gap: 12px;

    @media (max-width: 480px) {
      flex-direction: column;
    }
  }

  .action-button {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 10px 16px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    border: none;

    &.primary {
      background: var(--action-primary-bg);
      color: var(--action-primary-text);
      flex-grow: 2;

      &:hover {
        background: var(--action-primary-hover);
        transform: translateY(-1px);
      }
    }

    &.secondary {
      background: var(--action-secondary-bg);
      color: var(--action-secondary-text);
      border: 1px solid var(--action-secondary-border);

      &:hover {
        background: var(--action-secondary-hover);
      }
    }

    &.tertiary {
      background: none;
      color: var(--action-tertiary-text);

      &:hover {
        background: var(--action-tertiary-hover);
      }
    }
  }
`;