// popup/components/HistoryPanel.jsx
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Icon } from './Icon';
import { PerformanceChart } from '../../ui/widgets/PerformanceChart';
import { useTradeHistory } from '../../services/userHistory';
import { calculatePerformanceMetrics } from '../../utils/statsCalculator';
import { formatDate, formatCurrency } from '../../utils/dateUtils';
import '../../assets/styles/_history-panel.scss';

/**
 * HistoryPanel - Displays trading history and AI prediction performance analytics
 * @param {Object} props - Component props
 * @param {string} props.userId - User identifier
 * @param {string} [props.timeRange='7d'] - Time range filter (7d, 30d, 90d, all)
 * @param {boolean} [props.showDetails=true] - Whether to show detailed metrics
 */
export const HistoryPanel = ({ userId, timeRange = '7d', showDetails = true }) => {
  const [activeTab, setActiveTab] = useState('trades');
  const [selectedTrade, setSelectedTrade] = useState(null);
  const { trades, predictions, loading, error } = useTradeHistory(userId, timeRange);
  
  const {
    winRate,
    profitFactor,
    avgWin,
    avgLoss,
    expectancy,
    accuracy,
    totalProfit
  } = calculatePerformanceMetrics(trades, predictions);

  const handleTradeClick = (trade) => {
    setSelectedTrade(selectedTrade?.id === trade.id ? null : trade);
  };

  if (loading) {
    return (
      <div className="history-panel loading">
        <div className="spinner">
          <Icon name="loading" size={24} />
        </div>
        <p>Loading trading history...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="history-panel error">
        <Icon name="warning" size={20} />
        <p>Failed to load history</p>
        <small>{error.message}</small>
      </div>
    );
  }

  return (
    <div className="history-panel">
      <div className="panel-header">
        <h3>
          <Icon name="history" size={18} />
          Trading History
        </h3>
        <div className="time-range-filter">
          <select 
            value={timeRange}
            onChange={(e) => window.location.search = `?range=${e.target.value}`}
          >
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
            <option value="all">All Time</option>
          </select>
        </div>
      </div>

      <div className="tabs">
        <button
          className={`tab ${activeTab === 'trades' ? 'active' : ''}`}
          onClick={() => setActiveTab('trades')}
        >
          <Icon name="activity" size={16} />
          Trade History
        </button>
        <button
          className={`tab ${activeTab === 'performance' ? 'active' : ''}`}
          onClick={() => setActiveTab('performance')}
        >
          <Icon name="bar-chart" size={16} />
          Performance
        </button>
        <button
          className={`tab ${activeTab === 'predictions' ? 'active' : ''}`}
          onClick={() => setActiveTab('predictions')}
        >
          <Icon name="zap" size={16} />
          AI Accuracy
        </button>
      </div>

      {activeTab === 'trades' && (
        <div className="trade-history">
          {trades.length > 0 ? (
            <div className="trade-list-container">
              <div className="trade-list-header">
                <span className="header-cell">Date</span>
                <span className="header-cell">Symbol</span>
                <span className="header-cell">Type</span>
                <span className="header-cell">Amount</span>
                <span className="header-cell">Result</span>
              </div>
              <div className="trade-list">
                {trades.map(trade => (
                  <React.Fragment key={trade.id}>
                    <div 
                      className={`trade-item ${trade.result} ${selectedTrade?.id === trade.id ? 'selected' : ''}`}
                      onClick={() => handleTradeClick(trade)}
                    >
                      <span className="trade-cell date">{formatDate(trade.closeTime)}</span>
                      <span className="trade-cell symbol">{trade.symbol}</span>
                      <span className="trade-cell type">
                        <Icon 
                          name={trade.type === 'buy' ? 'arrow-up' : 'arrow-down'} 
                          size={14} 
                          className={`type-icon ${trade.type}`} 
                        />
                        {trade.type.toUpperCase()}
                      </span>
                      <span className="trade-cell amount">{formatCurrency(trade.amount)}</span>
                      <span className="trade-cell result">
                        <span className={`result-pill ${trade.result}`}>
                          {trade.result === 'win' ? '+' : ''}{formatCurrency(trade.profit)}
                          {trade.roe && (
                            <span className="roe">({trade.roe > 0 ? '+' : ''}{trade.roe.toFixed(1)}%)</span>
                          )}
                        </span>
                      </span>
                    </div>
                    {selectedTrade?.id === trade.id && (
                      <div className="trade-details">
                        <div className="detail-row">
                          <span className="detail-label">Entry Price:</span>
                          <span className="detail-value">{trade.entryPrice}</span>
                        </div>
                        <div className="detail-row">
                          <span className="detail-label">Exit Price:</span>
                          <span className="detail-value">{trade.exitPrice}</span>
                        </div>
                        <div className="detail-row">
                          <span className="detail-label">Duration:</span>
                          <span className="detail-value">{trade.duration}</span>
                        </div>
                        <div className="detail-row">
                          <span className="detail-label">AI Prediction:</span>
                          <span className={`detail-value ${trade.predictionMatch ? 'match' : 'no-match'}`}>
                            {trade.prediction || 'N/A'} 
                            {trade.prediction && (
                              <Icon 
                                name={trade.predictionMatch ? 'check' : 'x'} 
                                size={12} 
                                className="match-icon" 
                              />
                            )}
                          </span>
                        </div>
                        {trade.notes && (
                          <div className="detail-row notes">
                            <span className="detail-label">Notes:</span>
                            <span className="detail-value">{trade.notes}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </React.Fragment>
                ))}
              </div>
            </div>
          ) : (
            <div className="no-trades">
              <Icon name="book-open" size={24} />
              <p>No trades recorded in this period</p>
            </div>
          )}
        </div>
      )}

      {activeTab === 'performance' && (
        <div className="performance-tab">
          <div className="performance-metrics">
            <div className="metric-card total-profit">
              <div className="metric-value">{formatCurrency(totalProfit)}</div>
              <div className="metric-label">Total Profit</div>
              <div className="metric-trend">
                {totalProfit >= 0 ? (
                  <Icon name="trend-up" size={16} className="positive" />
                ) : (
                  <Icon name="trend-down" size={16} className="negative" />
                )}
              </div>
            </div>
            
            <div className="metric-card win-rate">
              <div className="metric-value">{winRate}%</div>
              <div className="metric-label">Win Rate</div>
              <PerformanceChart 
                value={winRate} 
                max={100} 
                color="var(--metric-win)" 
                size={60} 
              />
            </div>
            
            <div className="metric-card profit-factor">
              <div className="metric-value">{profitFactor.toFixed(2)}</div>
              <div className="metric-label">Profit Factor</div>
              <div className="metric-comparison">
                {profitFactor >= 2 ? 'Excellent' : profitFactor >= 1.5 ? 'Good' : 'Needs Work'}
              </div>
            </div>
            
            {showDetails && (
              <>
                <div className="metric-card">
                  <div className="metric-value">{avgWin}</div>
                  <div className="metric-label">Avg. Win</div>
                </div>
                
                <div className="metric-card">
                  <div className="metric-value">{avgLoss}</div>
                  <div className="metric-label">Avg. Loss</div>
                </div>
                
                <div className="metric-card">
                  <div className="metric-value">{expectancy}</div>
                  <div className="metric-label">Expectancy</div>
                </div>
              </>
            )}
          </div>
          
          <div className="performance-chart">
            <h4>Profit/Loss Over Time</h4>
            {/* Chart implementation would go here */}
            <div className="chart-placeholder">
              <Icon name="bar-chart" size={40} />
              <p>Performance chart visualization</p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'predictions' && (
        <div className="predictions-tab">
          <div className="accuracy-metrics">
            <div className="accuracy-card">
              <div className="accuracy-value">{accuracy}%</div>
              <div className="accuracy-label">AI Prediction Accuracy</div>
              <PerformanceChart 
                value={accuracy} 
                max={100} 
                color="var(--metric-ai)" 
                size={80} 
              />
            </div>
            
            <div className="prediction-breakdown">
              <h4>Prediction Performance</h4>
              <div className="breakdown-grid">
                <div className="breakdown-item">
                  <span className="breakdown-label">Correct Calls:</span>
                  <span className="breakdown-value positive">
                    {predictions.filter(p => p.wasCorrect).length}
                  </span>
                </div>
                <div className="breakdown-item">
                  <span className="breakdown-label">Incorrect Calls:</span>
                  <span className="breakdown-value negative">
                    {predictions.filter(p => !p.wasCorrect).length}
                  </span>
                </div>
                <div className="breakdown-item">
                  <span className="breakdown-label">Buy Accuracy:</span>
                  <span className="breakdown-value">
                    {(
                      predictions.filter(p => p.direction === 'BUY' && p.wasCorrect).length /
                      Math.max(1, predictions.filter(p => p.direction === 'BUY').length) * 100
                    ).toFixed(1)}%
                  </span>
                </div>
                <div className="breakdown-item">
                  <span className="breakdown-label">Sell Accuracy:</span>
                  <span className="breakdown-value">
                    {(
                      predictions.filter(p => p.direction === 'SELL' && p.wasCorrect).length /
                      Math.max(1, predictions.filter(p => p.direction === 'SELL').length) * 100
                    ).toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="prediction-improvement">
            <h4>AI Learning Suggestions</h4>
            <div className="suggestion-list">
              <div className="suggestion-item">
                <Icon name="zap" size={16} className="suggestion-icon" />
                <span>
                  {winRate > accuracy ? 
                    "Your manual trades outperform AI predictions. Consider reviewing your strategy." : 
                    "AI predictions outperform your manual trades. Consider following more AI signals."}
                </span>
              </div>
              <div className="suggestion-item">
                <Icon name="clock" size={16} className="suggestion-icon" />
                <span>
                  {predictions.filter(p => p.timeFrame === 'SHORT').length > 
                  predictions.filter(p => p.timeFrame === 'LONG').length ?
                    "Most predictions are for short-term trades. Try longer time frames for better accuracy." :
                    "Most predictions are for long-term trades. Short-term predictions may be more precise."}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

HistoryPanel.propTypes = {
  userId: PropTypes.string.isRequired,
  timeRange: PropTypes.oneOf(['7d', '30d', '90d', 'all']),
  showDetails: PropTypes.bool
};

HistoryPanel.defaultProps = {
  timeRange: '7d',
  showDetails: true
};

// Export styles for use in parent component
export const historyPanelStyles = `
  .history-panel {
    background: var(--history-bg);
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 16px;

    &.loading, &.error {
      text-align: center;
      padding: 24px 16px;

      p {
        margin: 12px 0 0 0;
      }

      small {
        display: block;
        margin-top: 4px;
        font-size: 11px;
        opacity: 0.7;
      }
    }
  }

  .panel-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;

    h3 {
      margin: 0;
      font-size: 16px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .time-range-filter select {
      background: var(--select-bg);
      color: var(--select-text);
      border: 1px solid var(--select-border);
      border-radius: 4px;
      padding: 4px 8px;
      font-size: 13px;
    }
  }

  .tabs {
    display: flex;
    border-bottom: 1px solid var(--tab-border);
    margin-bottom: 16px;

    .tab {
      background: none;
      border: none;
      padding: 8px 12px;
      margin-right: 4px;
      font-size: 13px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      color: var(--tab-text);
      border-bottom: 2px solid transparent;
      transition: all 0.2s ease;

      &:hover {
        color: var(--tab-text-active);
      }

      &.active {
        color: var(--tab-text-active);
        border-bottom-color: var(--tab-active-border);
        font-weight: 500;
      }
    }
  }

  .trade-history {
    .trade-list-container {
      border: 1px solid var(--trade-list-border);
      border-radius: 6px;
      overflow: hidden;
    }

    .trade-list-header {
      display: grid;
      grid-template-columns: 100px 80px 80px 1fr 120px;
      padding: 8px 12px;
      background: var(--trade-list-header-bg);
      font-size: 12px;
      font-weight: 500;
      color: var(--trade-list-header-text);

      .header-cell {
        padding: 4px;
      }
    }

    .trade-list {
      max-height: 400px;
      overflow-y: auto;
    }

    .trade-item {
      display: grid;
      grid-template-columns: 100px 80px 80px 1fr 120px;
      padding: 10px 12px;
      font-size: 13px;
      cursor: pointer;
      transition: background 0.2s ease;
      border-bottom: 1px solid var(--trade-item-border);

      &:hover {
        background: var(--trade-item-hover);
      }

      &.selected {
        background: var(--trade-item-selected);
      }

      &.win {
        background: var(--trade-item-win-bg);
      }

      &.loss {
        background: var(--trade-item-loss-bg);
      }

      .trade-cell {
        padding: 4px;
        display: flex;
        align-items: center;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;

        &.date {
          font-weight: 500;
        }

        &.symbol {
          font-weight: 600;
        }

        &.type {
          .type-icon {
            margin-right: 4px;

            &.buy {
              color: var(--signal-buy);
            }

            &.sell {
              color: var(--signal-sell);
            }
          }
        }

        &.result {
          justify-content: flex-end;

          .result-pill {
            padding: 4px 8px;
            border-radius: 12px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;

            &.win {
              background: var(--result-win-bg);
              color: var(--result-win-text);
            }

            &.loss {
              background: var(--result-loss-bg);
              color: var(--result-loss-text);
            }

            .roe {
              font-size: 11px;
              opacity: 0.9;
            }
          }
        }
      }
    }

    .trade-details {
      padding: 12px;
      background: var(--trade-details-bg);
      border-top: 1px solid var(--trade-details-border);
      font-size: 13px;

      .detail-row {
        display: flex;
        margin-bottom: 8px;

        &:last-child {
          margin-bottom: 0;
        }

        &.notes {
          flex-direction: column;
          gap: 4px;
        }
      }

      .detail-label {
        font-weight: 500;
        min-width: 120px;
        opacity: 0.8;
      }

      .detail-value {
        flex-grow: 1;

        &.match {
          color: var(--prediction-match);
          display: flex;
          align-items: center;
          gap: 4px;
        }

        &.no-match {
          color: var(--prediction-no-match);
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .match-icon {
          flex-shrink: 0;
        }
      }
    }

    .no-trades {
      text-align: center;
      padding: 24px;
      color: var(--text-secondary);

      p {
        margin: 8px 0 0 0;
      }
    }
  }

  .performance-tab {
    .performance-metrics {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 12px;
      margin-bottom: 16px;
    }

    .metric-card {
      background: var(--metric-card-bg);
      border-radius: 6px;
      padding: 12px;
      text-align: center;
      position: relative;
      overflow: hidden;

      &.total-profit {
        background: var(--metric-total-bg);
        color: var(--metric-total-text);
      }

      &.win-rate {
        background: var(--metric-win-bg);
        color: var(--metric-win-text);
      }

      &.profit-factor {
        background: var(--metric-factor-bg);
        color: var(--metric-factor-text);
      }

      .metric-value {
        font-size: 18px;
        font-weight: 700;
        margin-bottom: 4px;
      }

      .metric-label {
        font-size: 12px;
        opacity: 0.9;
      }

      .metric-trend {
        position: absolute;
        top: 8px;
        right: 8px;

        .positive {
          color: var(--metric-up);
        }

        .negative {
          color: var(--metric-down);
        }
      }

      .metric-comparison {
        font-size: 11px;
        margin-top: 4px;
        font-style: italic;
      }
    }

    .performance-chart {
      background: var(--chart-bg);
      border-radius: 6px;
      padding: 16px;
      margin-top: 16px;

      h4 {
        margin: 0 0 12px 0;
        font-size: 14px;
      }

      .chart-placeholder {
        height: 200px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        color: var(--text-secondary);
        border: 1px dashed var(--chart-placeholder-border);

        p {
          margin: 8px 0 0 0;
          font-size: 13px;
        }
      }
    }
  }

  .predictions-tab {
    .accuracy-metrics {
      display: flex;
      gap: 16px;
      margin-bottom: 16px;

      @media (max-width: 768px) {
        flex-direction: column;
      }
    }

    .accuracy-card {
      flex: 1;
      background: var(--accuracy-card-bg);
      border-radius: 6px;
      padding: 16px;
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;

      .accuracy-value {
        font-size: 24px;
        font-weight: 700;
        margin-bottom: 4px;
      }

      .accuracy-label {
        font-size: 13px;
        margin-bottom: 12px;
        opacity: 0.9;
      }
    }

    .prediction-breakdown {
      flex: 2;
      background: var(--breakdown-bg);
      border-radius: 6px;
      padding: 16px;

      h4 {
        margin: 0 0 12px 0;
        font-size: 14px;
      }

      .breakdown-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;

        @media (max-width: 480px) {
          grid-template-columns: 1fr;
        }
      }

      .breakdown-item {
        display: flex;
        justify-content: space-between;
        font-size: 13px;
        padding: 8px 0;
        border-bottom: 1px solid var(--breakdown-item-border);

        &:last-child {
          border-bottom: none;
        }

        .breakdown-label {
          opacity: 0.8;
        }

        .breakdown-value {
          font-weight: 600;

          &.positive {
            color: var(--metric-up);
          }

          &.negative {
            color: var(--metric-down);
          }
        }
      }
    }

    .prediction-improvement {
      background: var(--suggestion-bg);
      border-radius: 6px;
      padding: 16px;

      h4 {
        margin: 0 0 12px 0;
        font-size: 14px;
      }

      .suggestion-list {
        display: flex;
        flex-direction: column;
        gap: 12px;
      }

      .suggestion-item {
        display: flex;
        gap: 8px;
        font-size: 13px;
        line-height: 1.4;

        .suggestion-icon {
          flex-shrink: 0;
          color: var(--suggestion-icon);
          margin-top: 2px;
        }
      }
    }
  }
`;