// popup/components/LookbackInfo.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { Icon } from './Icon';
import { formatDuration } from '../../utils/dateUtils';
import { getVolatilityLevel } from '../../utils/tradingMath';

/**
 * LookbackInfo - Displays dynamic lookback window information based on market analysis
 * @param {Object} props - Component props
 * @param {Object} props.analysis - Market analysis data
 * @param {boolean} props.showDetails - Whether to show detailed explanation
 */
export const LookbackInfo = ({ analysis, showDetails = false }) => {
  if (!analysis || !analysis.lookbackWindow) {
    return (
      <div className="lookback-info empty">
        <Icon name="clock" size={20} />
        <span>No lookback data available</span>
      </div>
    );
  }

  const {
    lookbackWindow,
    volatility,
    trendStrength,
    newsImpact,
    marketCondition
  } = analysis;

  const volatilityLevel = getVolatilityLevel(volatility);
  const trendIcon = trendStrength > 0 ? 'trend-up' : 'trend-down';
  const newsIcon = newsImpact > 0.7 ? 'news-alert' : 'news-normal';

  return (
    <div className="lookback-info">
      <div className="lookback-header">
        <Icon name="history" size={18} />
        <h4>AI Analysis Window</h4>
        <span className="lookback-window">
          {formatDuration(lookbackWindow)}
        </span>
      </div>

      {showDetails && (
        <div className="lookback-details">
          <div className="detail-row">
            <span className="detail-label">
              <Icon name="activity" size={14} />
              Market Condition:
            </span>
            <span className={`detail-value condition-${marketCondition.toLowerCase()}`}>
              {marketCondition}
            </span>
          </div>

          <div className="detail-row">
            <span className="detail-label">
              <Icon name={volatilityLevel.icon} size={14} />
              Volatility:
            </span>
            <span className="detail-value">
              {volatilityLevel.label} ({volatility.toFixed(2)})
            </span>
          </div>

          <div className="detail-row">
            <span className="detail-label">
              <Icon name={trendIcon} size={14} />
              Trend Strength:
            </span>
            <span className="detail-value">
              {Math.abs(trendStrength).toFixed(2)} {trendStrength > 0 ? '↑' : '↓'}
            </span>
          </div>

          <div className="detail-row">
            <span className="detail-label">
              <Icon name={newsIcon} size={14} />
              News Impact:
            </span>
            <span className="detail-value">
              {newsImpact > 0.7 ? 'High' : newsImpact > 0.4 ? 'Medium' : 'Low'}
            </span>
          </div>
        </div>
      )}

      <div className="lookback-explanation">
        <p>
          The AI dynamically adjusted its analysis window based on current 
          market {volatilityLevel.label.toLowerCase()} volatility and {marketCondition.toLowerCase()} conditions.
        </p>
      </div>
    </div>
  );
};

LookbackInfo.propTypes = {
  analysis: PropTypes.shape({
    lookbackWindow: PropTypes.number,
    volatility: PropTypes.number,
    trendStrength: PropTypes.number,
    newsImpact: PropTypes.number,
    marketCondition: PropTypes.string
  }),
  showDetails: PropTypes.bool
};

LookbackInfo.defaultProps = {
  showDetails: true
};

// Export styles for use in parent component
export const lookbackInfoStyles = `
  .lookback-info {
    background: var(--lookback-bg);
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 16px;
    border-left: 3px solid var(--lookback-border);

    &.empty {
      text-align: center;
      padding: 12px;
      opacity: 0.7;

      span {
        margin-left: 8px;
        vertical-align: middle;
      }
    }
  }

  .lookback-header {
    display: flex;
    align-items: center;
    margin-bottom: 12px;
    gap: 8px;

    h4 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
      flex-grow: 1;
    }

    .lookback-window {
      background: var(--lookback-value-bg);
      color: var(--lookback-value-text);
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 13px;
      font-weight: bold;
    }
  }

  .lookback-details {
    display: grid;
    grid-template-columns: 1fr;
    gap: 10px;
    margin-bottom: 12px;
    font-size: 13px;

    .detail-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .detail-label {
      display: flex;
      align-items: center;
      gap: 6px;
      opacity: 0.8;
    }

    .detail-value {
      font-weight: 500;

      &.condition-high {
        color: var(--volatility-high);
      }
      &.condition-medium {
        color: var(--volatility-medium);
      }
      &.condition-low {
        color: var(--volatility-low);
      }
    }
  }

  .lookback-explanation {
    p {
      margin: 0;
      font-size: 13px;
      line-height: 1.4;
      opacity: 0.9;
    }
  }
`;