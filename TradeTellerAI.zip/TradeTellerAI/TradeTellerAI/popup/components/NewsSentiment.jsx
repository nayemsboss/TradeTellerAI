// popup/components/NewsSentiment.jsx
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Icon } from './Icon';
import { SentimentMeter } from '../../ui/widgets/SentimentMeter';
import { useNewsSentiment } from '../../services/newsScanner';
import { formatTimeAgo } from '../../utils/dateUtils';
import { getSentimentColor } from '../../utils/tradingMath';
import '../../assets/styles/_sentiment-colors.scss';

/**
 * NewsSentiment - Displays real-time news sentiment analysis with impact scoring
 * @param {Object} props - Component props
 * @param {string} props.symbol - Trading symbol to analyze
 * @param {number} props.maxItems - Maximum news items to display
 * @param {boolean} props.showDetails - Whether to show detailed sentiment breakdown
 */
export const NewsSentiment = ({ symbol, maxItems = 5, showDetails = true }) => {
  const [expanded, setExpanded] = useState(false);
  const { sentiment, articles, loading, error } = useNewsSentiment(symbol);
  
  const displayedArticles = expanded ? articles : articles.slice(0, maxItems);
  const hasMoreArticles = articles.length > maxItems;

  const renderImpactBadge = (impact) => {
    let impactClass = '';
    if (impact >= 7) impactClass = 'high';
    else if (impact >= 4) impactClass = 'medium';
    else impactClass = 'low';

    return (
      <span className={`impact-badge ${impactClass}`}>
        {impact}/10
      </span>
    );
  };

  if (loading) {
    return (
      <div className="sentiment-container loading">
        <div className="spinner">
          <Icon name="loading" size={24} />
        </div>
        <p>Analyzing news sentiment...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="sentiment-container error">
        <Icon name="warning" size={20} />
        <p>Failed to load sentiment data</p>
        <small>{error.message}</small>
      </div>
    );
  }

  return (
    <div className="sentiment-container">
      <div className="sentiment-header">
        <Icon name="news" size={18} />
        <h4>News Sentiment Analysis</h4>
        {sentiment && (
          <div className="overall-sentiment">
            <SentimentMeter 
              value={sentiment.score} 
              direction={sentiment.trend} 
            />
            <span className="sentiment-score">
              {sentiment.score > 0 ? '+' : ''}{sentiment.score.toFixed(1)}
            </span>
          </div>
        )}
      </div>

      {sentiment && showDetails && (
        <div className="sentiment-breakdown">
          <div className="breakdown-item">
            <span className="breakdown-label">Recent Trend:</span>
            <span className={`breakdown-value trend-${sentiment.trend}`}>
              {sentiment.trend}
              <Icon 
                name={sentiment.trend === 'bullish' ? 'trend-up' : 'trend-down'} 
                size={14} 
              />
            </span>
          </div>
          <div className="breakdown-item">
            <span className="breakdown-label">Confidence:</span>
            <span className="breakdown-value">
              {(sentiment.confidence * 100).toFixed(0)}%
            </span>
          </div>
          <div className="breakdown-item">
            <span className="breakdown-label">Sources:</span>
            <span className="breakdown-value">
              {sentiment.sources.join(', ')}
            </span>
          </div>
        </div>
      )}

      <div className="news-feed">
        <h5 className="news-feed-title">Latest Market News</h5>
        {displayedArticles.length > 0 ? (
          <ul className="news-list">
            {displayedArticles.map((article) => (
              <li 
                key={article.id} 
                className="news-item"
                style={{ borderLeftColor: getSentimentColor(article.sentiment) }}
              >
                <div className="news-content">
                  <div className="news-meta">
                    <span className="news-source">{article.source}</span>
                    <span className="news-time">{formatTimeAgo(article.time)}</span>
                    {renderImpactBadge(article.impact)}
                  </div>
                  <h6 className="news-headline">
                    <a 
                      href={article.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                    >
                      {article.headline}
                    </a>
                  </h6>
                  <div className="news-sentiment">
                    <span className="sentiment-label">Sentiment:</span>
                    <span 
                      className={`sentiment-value ${article.sentiment.toLowerCase()}`}
                    >
                      {article.sentiment}
                    </span>
                    {article.keywords.length > 0 && (
                      <div className="news-keywords">
                        {article.keywords.map(keyword => (
                          <span key={keyword} className="keyword">
                            {keyword}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                {article.image && (
                  <div className="news-image">
                    <img 
                      src={article.image} 
                      alt={article.headline} 
                      loading="lazy"
                    />
                  </div>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <div className="no-articles">
            <Icon name="news-off" size={20} />
            <p>No recent news found</p>
          </div>
        )}

        {hasMoreArticles && (
          <button 
            className="toggle-expand"
            onClick={() => setExpanded(!expanded)}
          >
            {expanded ? (
              <>
                <span>Show less</span>
                <Icon name="chevron-up" size={14} />
              </>
            ) : (
              <>
                <span>Show {articles.length - maxItems} more</span>
                <Icon name="chevron-down" size={14} />
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
};

NewsSentiment.propTypes = {
  symbol: PropTypes.string.isRequired,
  maxItems: PropTypes.number,
  showDetails: PropTypes.bool
};

NewsSentiment.defaultProps = {
  maxItems: 5,
  showDetails: true
};

// Export styles for use in parent component
export const newsSentimentStyles = `
  .sentiment-container {
    background: var(--sentiment-bg);
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 16px;

    &.loading, &.error {
      text-align: center;
      padding: 24px 16px;

      p {
        margin: 12px 0 0 0;
      }

      small {
        display: block;
        margin-top: 4px;
        font-size: 11px;
        opacity: 0.7;
      }
    }
  }

  .sentiment-header {
    display: flex;
    align-items: center;
    margin-bottom: 16px;
    gap: 8px;

    h4 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
      flex-grow: 1;
    }

    .overall-sentiment {
      display: flex;
      align-items: center;
      gap: 8px;

      .sentiment-score {
        font-weight: bold;
        font-size: 16px;
        min-width: 40px;
        text-align: right;
      }
    }
  }

  .sentiment-breakdown {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 12px;
    margin-bottom: 16px;
    font-size: 13px;

    .breakdown-item {
      background: var(--breakdown-bg);
      padding: 8px;
      border-radius: 4px;

      .breakdown-label {
        display: block;
        margin-bottom: 4px;
        opacity: 0.8;
        font-size: 12px;
      }

      .breakdown-value {
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 4px;

        &.trend-bullish {
          color: var(--sentiment-bullish);
        }

        &.trend-bearish {
          color: var(--sentiment-bearish);
        }
      }
    }
  }

  .news-feed {
    .news-feed-title {
      margin: 0 0 12px 0;
      font-size: 14px;
      font-weight: 500;
      color: var(--text-secondary);
    }

    .news-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .news-item {
      display: flex;
      padding: 12px 0;
      border-left: 3px solid;
      padding-left: 12px;
      margin-bottom: 12px;
      gap: 12px;

      &:last-child {
        margin-bottom: 0;
      }
    }

    .news-content {
      flex: 1;
      min-width: 0;
    }

    .news-meta {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 6px;
      font-size: 12px;
      flex-wrap: wrap;

      .news-source {
        font-weight: 600;
      }

      .news-time {
        opacity: 0.7;
      }

      .impact-badge {
        font-size: 11px;
        padding: 2px 6px;
        border-radius: 10px;
        font-weight: bold;

        &.high {
          background: var(--impact-high-bg);
          color: var(--impact-high-text);
        }

        &.medium {
          background: var(--impact-medium-bg);
          color: var(--impact-medium-text);
        }

        &.low {
          background: var(--impact-low-bg);
          color: var(--impact-low-text);
        }
      }
    }

    .news-headline {
      margin: 0 0 8px 0;
      font-size: 14px;
      line-height: 1.4;

      a {
        color: var(--text-primary);
        text-decoration: none;

        &:hover {
          text-decoration: underline;
        }
      }
    }

    .news-sentiment {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;

      .sentiment-label {
        opacity: 0.7;
      }

      .sentiment-value {
        font-weight: 600;
        text-transform: capitalize;

        &.bullish {
          color: var(--sentiment-bullish);
        }

        &.bearish {
          color: var(--sentiment-bearish);
        }

        &.neutral {
          color: var(--sentiment-neutral);
        }
      }
    }

    .news-keywords {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 8px;

      .keyword {
        background: var(--keyword-bg);
        color: var(--keyword-text);
        font-size: 11px;
        padding: 2px 6px;
        border-radius: 4px;
      }
    }

    .news-image {
      width: 80px;
      height: 60px;
      border-radius: 4px;
      overflow: hidden;
      flex-shrink: 0;

      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }

    .no-articles {
      text-align: center;
      padding: 20px;
      color: var(--text-secondary);

      p {
        margin: 8px 0 0 0;
        font-size: 13px;
      }
    }

    .toggle-expand {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      width: 100%;
      padding: 8px;
      background: none;
      border: none;
      border-top: 1px solid var(--divider-color);
      color: var(--text-secondary);
      font-size: 13px;
      cursor: pointer;
      margin-top: 8px;

      &:hover {
        color: var(--text-primary);
      }
    }
  }
`;