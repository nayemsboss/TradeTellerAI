// popup/components/PredictionBox.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ConfidenceMeter } from '../../ui/widgets/ConfidenceMeter';
import { usePredictionData } from '../../services/apiFetcher';
import { formatTime } from '../../utils/dateUtils';
import { calculateRiskReward } from '../../utils/tradingMath';
import { Icon } from './Icon';
import '../../assets/styles/_signal-colors.scss';

/**
 * PredictionBox - Displays AI-generated trading signals with confidence levels
 * @param {Object} props - Component props
 * @param {string} props.symbol - Trading symbol to display predictions for
 * @param {boolean} props.compact - Whether to show compact version
 */
export const PredictionBox = ({ symbol, compact = false }) => {
  const { prediction, loading, error } = usePredictionData(symbol);
  
  if (loading) {
    return (
      <div className="prediction-box loading">
        <div className="spinner">
          <Icon name="loading" size={24} />
        </div>
        <p>Analyzing market data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="prediction-box error">
        <Icon name="warning" size={24} />
        <p>Failed to load predictions</p>
        <small>{error.message}</small>
      </div>
    );
  }

  if (!prediction) {
    return (
      <div className="prediction-box empty">
        <Icon name="chart" size={24} />
        <p>No prediction available</p>
      </div>
    );
  }

  const {
    direction,
    confidence,
    timeFrame,
    validUntil,
    entryRange,
    targetPrices,
    stopLoss,
    riskRewardRatio,
    rationale
  } = prediction;

  const riskReward = calculateRiskReward(entryRange, targetPrices, stopLoss);

  return (
    <div className={`prediction-box ${direction.toLowerCase()} ${compact ? 'compact' : ''}`}>
      <div className="prediction-header">
        <h3>
          <Icon name={direction === 'BUY' ? 'arrow-up' : 'arrow-down'} size={20} />
          {symbol} {direction} Signal
        </h3>
        <span className="time-frame">{timeFrame}</span>
      </div>

      <div className="confidence-section">
        <ConfidenceMeter value={confidence} />
        <span className="confidence-value">{Math.round(confidence * 100)}%</span>
      </div>

      {!compact && (
        <>
          <div className="price-levels">
            <div className="level">
              <span className="label">Entry Zone:</span>
              <span className="value">{entryRange.join(' - ')}</span>
            </div>
            <div className="level">
              <span className="label">Targets:</span>
              <span className="value">
                {targetPrices.map((t, i) => `TP${i + 1}: ${t}`).join(', ')}
              </span>
            </div>
            <div className="level">
              <span className="label">Stop Loss:</span>
              <span className="value">{stopLoss}</span>
            </div>
          </div>

          <div className="metrics">
            <div className="metric">
              <span className="label">Risk/Reward</span>
              <span className="value">{riskReward.ratio.toFixed(2)}:1</span>
            </div>
            <div className="metric">
              <span className="label">Valid Until</span>
              <span className="value">{formatTime(validUntil)}</span>
            </div>
          </div>

          <div className="rationale">
            <h4>AI Rationale:</h4>
            <p>{rationale}</p>
          </div>
        </>
      )}
    </div>
  );
};

PredictionBox.propTypes = {
  symbol: PropTypes.string.isRequired,
  compact: PropTypes.bool
};

PredictionBox.defaultProps = {
  compact: false
};

// Export styles for use in parent component
export const predictionBoxStyles = `
  .prediction-box {
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 16px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    background: var(--card-bg);
    color: var(--text-primary);
    
    &.buy {
      border-left: 4px solid var(--signal-buy);
      .confidence-value {
        color: var(--signal-buy);
      }
    }
    
    &.sell {
      border-left: 4px solid var(--signal-sell);
      .confidence-value {
        color: var(--signal-sell);
      }
    }
    
    &.compact {
      padding: 12px;
      
      .prediction-header {
        margin-bottom: 8px;
      }
      
      h3 {
        font-size: 14px;
      }
    }
  }
  
  .prediction-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    
    h3 {
      margin: 0;
      font-size: 16px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .time-frame {
      font-size: 12px;
      opacity: 0.8;
    }
  }
  
  .confidence-section {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 16px;
    
    .confidence-value {
      font-weight: bold;
      font-size: 18px;
    }
  }
  
  .price-levels {
    display: grid;
    grid-template-columns: 1fr;
    gap: 8px;
    margin-bottom: 16px;
    
    .level {
      display: flex;
      justify-content: space-between;
      
      .label {
        font-weight: 500;
        opacity: 0.8;
      }
      
      .value {
        font-weight: 600;
      }
    }
  }
  
  .metrics {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-bottom: 16px;
    
    .metric {
      background: var(--metric-bg);
      padding: 8px;
      border-radius: 4px;
      text-align: center;
      
      .label {
        display: block;
        font-size: 12px;
        margin-bottom: 4px;
        opacity: 0.8;
      }
      
      .value {
        font-weight: bold;
        font-size: 14px;
      }
    }
  }
  
  .rationale {
    h4 {
      margin: 0 0 8px 0;
      font-size: 14px;
    }
    
    p {
      margin: 0;
      font-size: 13px;
      line-height: 1.4;
      opacity: 0.9;
    }
  }
  
  .loading, .error, .empty {
    text-align: center;
    padding: 24px 16px;
    
    p {
      margin: 12px 0 0 0;
    }
    
    small {
      display: block;
      margin-top: 4px;
      font-size: 11px;
      opacity: 0.7;
    }
  }
`;