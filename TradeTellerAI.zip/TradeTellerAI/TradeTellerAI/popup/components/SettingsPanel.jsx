// popup/components/SettingsPanel.jsx
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Icon } from './Icon';
import { ToggleSwitch } from '../../ui/widgets/ToggleSwitch';
import { RangeSlider } from '../../ui/widgets/RangeSlider';
import { useUserSettings, saveUserSettings } from '../../services/userHistory';
import { defaultSettings } from '../../constants/config';
import '../../assets/styles/_settings-panel.scss';

/**
 * SettingsPanel - Configuration panel for user preferences and AI parameters
 * @param {Object} props - Component props
 * @param {function} props.onClose - Callback when panel is closed
 * @param {boolean} props.isActive - Whether panel is currently visible
 */
export const SettingsPanel = ({ onClose, isActive }) => {
  const [settings, setSettings] = useState(defaultSettings);
  const [activeTab, setActiveTab] = useState('general');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState(null);
  
  // Load user settings when component mounts
  useEffect(() => {
    const loadSettings = async () => {
      const userSettings = await useUserSettings();
      setSettings({ ...defaultSettings, ...userSettings });
    };
    loadSettings();
  }, []);

  const handleSettingChange = (key, value) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleNestedSettingChange = (parentKey, childKey, value) => {
    setSettings(prev => ({
      ...prev,
      [parentKey]: {
        ...prev[parentKey],
        [childKey]: value
      }
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await saveUserSettings(settings);
      setSaveStatus({ type: 'success', message: 'Settings saved successfully!' });
      setTimeout(() => setSaveStatus(null), 3000);
    } catch (error) {
      setSaveStatus({ type: 'error', message: 'Failed to save settings' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    if (confirm('Reset all settings to default values?')) {
      setSettings(defaultSettings);
    }
  };

  if (!isActive) return null;

  return (
    <div className="settings-panel">
      <div className="settings-header">
        <h3>
          <Icon name="settings" size={18} />
          TradeTellerAI Settings
        </h3>
        <button className="close-button" onClick={onClose}>
          <Icon name="x" size={18} />
        </button>
      </div>

      <div className="settings-tabs">
        <button
          className={`tab ${activeTab === 'general' ? 'active' : ''}`}
          onClick={() => setActiveTab('general')}
        >
          <Icon name="user" size={14} />
          General
        </button>
        <button
          className={`tab ${activeTab === 'alerts' ? 'active' : ''}`}
          onClick={() => setActiveTab('alerts')}
        >
          <Icon name="bell" size={14} />
          Alerts
        </button>
        <button
          className={`tab ${activeTab === 'analysis' ? 'active' : ''}`}
          onClick={() => setActiveTab('analysis')}
        >
          <Icon name="bar-chart" size={14} />
          Analysis
        </button>
        <button
          className={`tab ${activeTab === 'advanced' ? 'active' : ''}`}
          onClick={() => setActiveTab('advanced')}
        >
          <Icon name="sliders" size={14} />
          Advanced
        </button>
      </div>

      <div className="settings-content">
        {activeTab === 'general' && (
          <div className="settings-section">
            <div className="setting-item">
              <div className="setting-label">
                <Icon name="moon" size={14} />
                <span>Dark Mode</span>
              </div>
              <ToggleSwitch
                isOn={settings.darkMode}
                handleToggle={() => handleSettingChange('darkMode', !settings.darkMode)}
              />
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="volume-2" size={14} />
                <span>Alert Sounds</span>
              </div>
              <ToggleSwitch
                isOn={settings.alertSounds}
                handleToggle={() => handleSettingChange('alertSounds', !settings.alertSounds)}
              />
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="clock" size={14} />
                <span>Default Timeframe</span>
              </div>
              <select
                value={settings.defaultTimeframe}
                onChange={(e) => handleSettingChange('defaultTimeframe', e.target.value)}
              >
                <option value="1m">1 Minute</option>
                <option value="5m">5 Minutes</option>
                <option value="15m">15 Minutes</option>
                <option value="1h">1 Hour</option>
                <option value="4h">4 Hours</option>
                <option value="1d">1 Day</option>
              </select>
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="eye" size={14} />
                <span>Chart Style</span>
              </div>
              <select
                value={settings.chartStyle}
                onChange={(e) => handleSettingChange('chartStyle', e.target.value)}
              >
                <option value="candlestick">Candlestick</option>
                <option value="heikin-ashi">Heikin Ashi</option>
                <option value="line">Line</option>
                <option value="area">Area</option>
              </select>
            </div>
          </div>
        )}

        {activeTab === 'alerts' && (
          <div className="settings-section">
            <div className="setting-item">
              <div className="setting-label">
                <Icon name="zap" size={14} />
                <span>High Priority Alerts</span>
              </div>
              <ToggleSwitch
                isOn={settings.alerts.highPriority}
                handleToggle={() => handleNestedSettingChange('alerts', 'highPriority', !settings.alerts.highPriority)}
              />
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="activity" size={14} />
                <span>Medium Priority Alerts</span>
              </div>
              <ToggleSwitch
                isOn={settings.alerts.mediumPriority}
                handleToggle={() => handleNestedSettingChange('alerts', 'mediumPriority', !settings.alerts.mediumPriority)}
              />
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="alert-circle" size={14} />
                <span>Low Priority Alerts</span>
              </div>
              <ToggleSwitch
                isOn={settings.alerts.lowPriority}
                handleToggle={() => handleNestedSettingChange('alerts', 'lowPriority', !settings.alerts.lowPriority)}
              />
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="watch" size={14} />
                <span>Alert Duration</span>
                <span className="value-display">{settings.alerts.duration}s</span>
              </div>
              <RangeSlider
                min={2}
                max={30}
                step={1}
                value={settings.alerts.duration}
                onChange={(value) => handleNestedSettingChange('alerts', 'duration', value)}
              />
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="maximize-2" size={14} />
                <span>Popup Alerts</span>
              </div>
              <ToggleSwitch
                isOn={settings.alerts.popup}
                handleToggle={() => handleNestedSettingChange('alerts', 'popup', !settings.alerts.popup)}
              />
            </div>
          </div>
        )}

        {activeTab === 'analysis' && (
          <div className="settings-section">
            <div className="setting-item">
              <div className="setting-label">
                <Icon name="cpu" size={14} />
                <span>AI Analysis Mode</span>
              </div>
              <select
                value={settings.analysis.mode}
                onChange={(e) => handleNestedSettingChange('analysis', 'mode', e.target.value)}
              >
                <option value="balanced">Balanced</option>
                <option value="aggressive">Aggressive</option>
                <option value="conservative">Conservative</option>
                <option value="custom">Custom</option>
              </select>
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="bar-chart" size={14} />
                <span>Technical Weight</span>
                <span className="value-display">{settings.analysis.weights.technical}%</span>
              </div>
              <RangeSlider
                min={0}
                max={100}
                step={5}
                value={settings.analysis.weights.technical}
                onChange={(value) => handleNestedSettingChange('analysis.weights', 'technical', value)}
              />
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="message-square" size={14} />
                <span>Sentiment Weight</span>
                <span className="value-display">{settings.analysis.weights.sentiment}%</span>
              </div>
              <RangeSlider
                min={0}
                max={100}
                step={5}
                value={settings.analysis.weights.sentiment}
                onChange={(value) => handleNestedSettingChange('analysis.weights', 'sentiment', value)}
              />
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="file-text" size={14} />
                <span>Fundamental Weight</span>
                <span className="value-display">{settings.analysis.weights.fundamental}%</span>
              </div>
              <RangeSlider
                min={0}
                max={100}
                step={5}
                value={settings.analysis.weights.fundamental}
                onChange={(value) => handleNestedSettingChange('analysis.weights', 'fundamental', value)}
              />
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="eye" size={14} />
                <span>Show Detailed Analysis</span>
              </div>
              <ToggleSwitch
                isOn={settings.analysis.showDetails}
                handleToggle={() => handleNestedSettingChange('analysis', 'showDetails', !settings.analysis.showDetails)}
              />
            </div>
          </div>
        )}

        {activeTab === 'advanced' && (
          <div className="settings-section">
            <div className="setting-item">
              <div className="setting-label">
                <Icon name="code" size={14} />
                <span>Developer Mode</span>
              </div>
              <ToggleSwitch
                isOn={settings.advanced.developerMode}
                handleToggle={() => handleNestedSettingChange('advanced', 'developerMode', !settings.advanced.developerMode)}
              />
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="database" size={14} />
                <span>Data Collection</span>
              </div>
              <ToggleSwitch
                isOn={settings.advanced.dataCollection}
                handleToggle={() => handleNestedSettingChange('advanced', 'dataCollection', !settings.advanced.dataCollection)}
              />
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="cpu" size={14} />
                <span>AI Model Precision</span>
              </div>
              <select
                value={settings.advanced.modelPrecision}
                onChange={(e) => handleNestedSettingChange('advanced', 'modelPrecision', e.target.value)}
              >
                <option value="low">Low (Faster)</option>
                <option value="medium">Medium</option>
                <option value="high">High (Slower)</option>
              </select>
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="refresh-cw" size={14} />
                <span>Update Frequency</span>
              </div>
              <select
                value={settings.advanced.updateFrequency}
                onChange={(e) => handleNestedSettingChange('advanced', 'updateFrequency', e.target.value)}
              >
                <option value="realtime">Real-time</option>
                <option value="5s">5 Seconds</option>
                <option value="15s">15 Seconds</option>
                <option value="30s">30 Seconds</option>
                <option value="1m">1 Minute</option>
              </select>
            </div>

            <div className="setting-item">
              <div className="setting-label">
                <Icon name="hard-drive" size={14} />
                <span>Local Cache Size</span>
                <span className="value-display">{settings.advanced.cacheSize}MB</span>
              </div>
              <RangeSlider
                min={10}
                max={500}
                step={10}
                value={settings.advanced.cacheSize}
                onChange={(value) => handleNestedSettingChange('advanced', 'cacheSize', value)}
              />
            </div>
          </div>
        )}
      </div>

      <div className="settings-footer">
        {saveStatus && (
          <div className={`save-status ${saveStatus.type}`}>
            <Icon name={saveStatus.type === 'success' ? 'check' : 'x'} size={14} />
            <span>{saveStatus.message}</span>
          </div>
        )}
        <div className="action-buttons">
          <button className="reset-button" onClick={handleReset}>
            <Icon name="rotate-ccw" size={14} />
            Reset Defaults
          </button>
          <button 
            className="save-button" 
            onClick={handleSave}
            disabled={isSaving}
          >
            {isSaving ? (
              <>
                <Icon name="loader" size={14} className="spin" />
                Saving...
              </>
            ) : (
              <>
                <Icon name="save" size={14} />
                Save Settings
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

SettingsPanel.propTypes = {
  onClose: PropTypes.func.isRequired,
  isActive: PropTypes.bool.isRequired
};

// Export styles for use in parent component
export const settingsPanelStyles = `
  .settings-panel {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    width: 360px;
    max-width: 100%;
    background: var(--settings-bg);
    box-shadow: -2px 0 10px rgba(0, 0, 0, 0.1);
    z-index: 1000;
    display: flex;
    flex-direction: column;
    transform: translateX(100%);
    transition: transform 0.3s ease;
    overflow-y: auto;

    &.active {
      transform: translateX(0);
    }
  }

  .settings-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px;
    border-bottom: 1px solid var(--settings-header-border);
    position: sticky;
    top: 0;
    background: var(--settings-bg);
    z-index: 10;

    h3 {
      margin: 0;
      font-size: 16px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .close-button {
      background: none;
      border: none;
      cursor: pointer;
      padding: 4px;
      border-radius: 4px;
      color: var(--settings-close);

      &:hover {
        background: var(--settings-close-hover);
      }
    }
  }

  .settings-tabs {
    display: flex;
    border-bottom: 1px solid var(--settings-tab-border);
    padding: 0 16px;
    position: sticky;
    top: 57px;
    background: var(--settings-bg);
    z-index: 9;

    .tab {
      background: none;
      border: none;
      padding: 12px 16px;
      font-size: 13px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      color: var(--settings-tab-text);
      border-bottom: 2px solid transparent;
      transition: all 0.2s ease;
      margin-bottom: -1px;

      &:hover {
        color: var(--settings-tab-text-hover);
      }

      &.active {
        color: var(--settings-tab-text-active);
        border-bottom-color: var(--settings-tab-active-border);
        font-weight: 500;
      }
    }
  }

  .settings-content {
    flex-grow: 1;
    padding: 16px;
    overflow-y: auto;
  }

  .settings-section {
    display: flex;
    flex-direction: column;
    gap: 20px;
  }

  .setting-item {
    display: flex;
    flex-direction: column;
    gap: 8px;

    .setting-label {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
      font-weight: 500;

      .value-display {
        margin-left: auto;
        font-weight: 600;
        font-size: 13px;
        color: var(--settings-value);
      }
    }

    select {
      background: var(--settings-select-bg);
      color: var(--settings-select-text);
      border: 1px solid var(--settings-select-border);
      border-radius: 4px;
      padding: 8px 12px;
      font-size: 13px;
      width: 100%;
      cursor: pointer;

      &:focus {
        outline: none;
        border-color: var(--settings-select-focus);
      }
    }
  }

  .settings-footer {
    padding: 16px;
    border-top: 1px solid var(--settings-footer-border);
    margin-top: auto;
    position: sticky;
    bottom: 0;
    background: var(--settings-bg);
  }

  .save-status {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 8px 12px;
    border-radius: 4px;
    margin-bottom: 12px;
    font-size: 13px;

    &.success {
      background: var(--settings-status-success-bg);
      color: var(--settings-status-success-text);
    }

    &.error {
      background: var(--settings-status-error-bg);
      color: var(--settings-status-error-text);
    }
  }

  .action-buttons {
    display: flex;
    gap: 12px;
  }

  .reset-button, .save-button {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 10px 16px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    border: none;
  }

  .reset-button {
    background: var(--settings-reset-bg);
    color: var(--settings-reset-text);
    border: 1px solid var(--settings-reset-border);

    &:hover {
      background: var(--settings-reset-hover);
    }
  }

  .save-button {
    flex-grow: 1;
    background: var(--settings-save-bg);
    color: var(--settings-save-text);

    &:hover:not(:disabled) {
      background: var(--settings-save-hover);
    }

    &:disabled {
      opacity: 0.7;
      cursor: not-allowed;
    }

    .spin {
      animation: spin 1s linear infinite;
    }
  }

  @keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }
`;