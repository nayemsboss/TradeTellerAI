// popup/popup.js
import { PredictionBox, predictionBoxStyles } from './components/PredictionBox.js';
import { LookbackInfo, lookbackInfoStyles } from './components/LookbackInfo.js';
import { AlertBar, alertBarStyles } from './components/AlertBar.js';
import { NewsSentiment, newsSentimentStyles } from './components/NewsSentiment.js';
import { HistoryPanel, historyPanelStyles } from './components/HistoryPanel.js';
import { CombinedAnalysis, combinedAnalysisStyles } from './components/CombinedAnalysis.js';
import { SettingsPanel, settingsPanelStyles } from './components/SettingsPanel.js';
import { CandlePatternSummary, candlePatternSummaryStyles } from './components/CandlePatternSummary.js';
import { Icon, iconStyles } from './components/Icon.js';
import { fetchMarketData } from '../services/apiFetcher.js';
import { analyzeTrend } from '../services/performanceAnalyzer.js';
import { formatCurrency, formatTime } from '../utils/dateUtils.js';
import { calculateRiskReward } from '../utils/tradingMath.js';

// Inject global styles
const styleElement = document.createElement('style');
styleElement.textContent = `
  ${iconStyles}
  ${predictionBoxStyles}
  ${lookbackInfoStyles}
  ${alertBarStyles}
  ${newsSentimentStyles}
  ${historyPanelStyles}
  ${combinedAnalysisStyles}
  ${settingsPanelStyles}
  ${candlePatternSummaryStyles}
`;
document.head.appendChild(styleElement);

// DOM Elements
const elements = {
  symbolSelect: document.getElementById('symbol-select'),
  timeframeButtons: document.querySelectorAll('.timeframe-btn'),
  refreshButton: document.getElementById('refresh-button'),
  settingsButton: document.getElementById('settings-button'),
  quickBuyButton: document.getElementById('quick-buy'),
  quickSellButton: document.getElementById('quick-sell'),
  dashboardButton: document.getElementById('view-dashboard'),
  predictionBox: document.getElementById('prediction-box'),
  sentimentBox: document.getElementById('sentiment-box'),
  analysisBox: document.getElementById('analysis-box'),
  candleBox: document.getElementById('candle-box'),
  settingsPanel: document.getElementById('settings-panel')
};

// State Management
let appState = {
  currentSymbol: 'EUR/USD',
  currentTimeframe: '5m',
  marketData: null,
  analysis: null,
  settings: {
    darkMode: false,
    alertSounds: true,
    defaultTimeframe: '5m',
    chartStyle: 'candlestick',
    alerts: {
      highPriority: true,
      mediumPriority: true,
      lowPriority: false,
      duration: 10,
      popup: true
    },
    analysis: {
      mode: 'balanced',
      weights: {
        technical: 50,
        sentiment: 30,
        fundamental: 20
      },
      showDetails: true
    },
    advanced: {
      developerMode: false,
      dataCollection: true,
      modelPrecision: 'medium',
      updateFrequency: '15s',
      cacheSize: 100
    }
  }
};

// Initialize the popup
async function initPopup() {
  loadSettings();
  setupEventListeners();
  await loadMarketData();
  renderComponents();
}

// Load market data
async function loadMarketData() {
  try {
    const [marketData, analysis] = await Promise.all([
      fetchMarketData(appState.currentSymbol, appState.currentTimeframe),
      analyzeTrend(appState.currentSymbol)
    ]);
    
    appState.marketData = marketData;
    appState.analysis = analysis;
    
    // Update last refreshed time
    const lastRefreshed = document.createElement('div');
    lastRefreshed.className = 'last-refreshed';
    lastRefreshed.textContent = `Last updated: ${formatTime(new Date())}`;
    elements.refreshButton.appendChild(lastRefreshed);
    
  } catch (error) {
    console.error('Error loading market data:', error);
    showError('Failed to load market data. Please try again.');
  }
}

// Render all components
function renderComponents() {
  if (!appState.marketData || !appState.analysis) return;
  
  // Clear previous content
  elements.predictionBox.innerHTML = '';
  elements.sentimentBox.innerHTML = '';
  elements.analysisBox.innerHTML = '';
  elements.candleBox.innerHTML = '';
  
  // Render Prediction Box
  const predictionBox = new PredictionBox({
    symbol: appState.currentSymbol,
    prediction: appState.analysis.prediction,
    loading: false
  });
  elements.predictionBox.appendChild(predictionBox);
  
  // Render Lookback Info
  const lookbackInfo = new LookbackInfo({
    analysis: appState.analysis.lookbackAnalysis,
    showDetails: true
  });
  elements.predictionBox.appendChild(lookbackInfo);
  
  // Render News Sentiment
  const newsSentiment = new NewsSentiment({
    symbol: appState.currentSymbol,
    sentiment: appState.analysis.sentiment,
    articles: appState.marketData.news
  });
  elements.sentimentBox.appendChild(newsSentiment);
  
  // Render Combined Analysis
  const combinedAnalysis = new CombinedAnalysis({
    symbol: appState.currentSymbol,
    analysis: appState.analysis.combinedAnalysis,
    showBreakdown: true
  });
  elements.analysisBox.appendChild(combinedAnalysis);
  
  // Render Candle Patterns
  if (appState.analysis.candlePatterns && appState.analysis.candlePatterns.length > 0) {
    appState.analysis.candlePatterns.forEach(pattern => {
      const candlePattern = new CandlePatternSummary({
        pattern: pattern.name,
        trend: pattern.trend,
        confidence: pattern.confidence
      });
      elements.candleBox.appendChild(candlePattern);
    });
  } else {
    elements.candleBox.innerHTML = '<div class="no-patterns">No significant candle patterns detected</div>';
  }
  
  // Update active timeframe button
  updateActiveTimeframe();
}

// Setup event listeners
function setupEventListeners() {
  // Symbol selection
  elements.symbolSelect.addEventListener('change', async (e) => {
    appState.currentSymbol = e.target.value;
    await loadMarketData();
    renderComponents();
  });
  
  // Timeframe selection
  elements.timeframeButtons.forEach(button => {
    button.addEventListener('click', async (e) => {
      appState.currentTimeframe = e.target.dataset.timeframe;
      await loadMarketData();
      renderComponents();
    });
  });
  
  // Refresh button
  elements.refreshButton.addEventListener('click', async () => {
    await loadMarketData();
    renderComponents();
  });
  
  // Settings button
  elements.settingsButton.addEventListener('click', toggleSettingsPanel);
  
  // Quick action buttons
  elements.quickBuyButton.addEventListener('click', () => executeTrade('buy'));
  elements.quickSellButton.addEventListener('click', () => executeTrade('sell'));
  elements.dashboardButton.addEventListener('click', openDashboard);
  
  // Handle settings changes
  document.addEventListener('settingsChanged', (e) => {
    appState.settings = e.detail;
    applySettings();
  });
}

// Toggle settings panel
function toggleSettingsPanel() {
  if (elements.settingsPanel.classList.contains('settings-panel-hidden')) {
    elements.settingsPanel.classList.remove('settings-panel-hidden');
    elements.settingsPanel.classList.add('settings-panel-visible');
    
    // Render settings panel
    const settingsPanel = new SettingsPanel({
      settings: appState.settings,
      onClose: toggleSettingsPanel
    });
    elements.settingsPanel.innerHTML = '';
    elements.settingsPanel.appendChild(settingsPanel);
  } else {
    elements.settingsPanel.classList.remove('settings-panel-visible');
    elements.settingsPanel.classList.add('settings-panel-hidden');
  }
}

// Update active timeframe button
function updateActiveTimeframe() {
  elements.timeframeButtons.forEach(button => {
    if (button.dataset.timeframe === appState.currentTimeframe) {
      button.classList.add('active');
    } else {
      button.classList.remove('active');
    }
  });
}

// Execute trade
function executeTrade(direction) {
  const tradeDetails = {
    symbol: appState.currentSymbol,
    direction,
    price: direction === 'buy' 
      ? appState.marketData.currentPrice.bid 
      : appState.marketData.currentPrice.ask,
    time: new Date(),
    timeframe: appState.currentTimeframe
  };
  
  // In a real extension, this would connect to your trading API
  console.log(`Executing ${direction} trade:`, tradeDetails);
  
  // Show confirmation
  const confirmation = document.createElement('div');
  confirmation.className = `trade-confirmation ${direction}`;
  confirmation.innerHTML = `
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
      <polyline points="22 4 12 14.01 9 11.01"></polyline>
    </svg>
    <span>${direction.toUpperCase()} order placed for ${appState.currentSymbol}</span>
  `;
  
  document.body.appendChild(confirmation);
  setTimeout(() => confirmation.remove(), 3000);
}

// Open full dashboard
function openDashboard() {
  chrome.tabs.create({ url: chrome.runtime.getURL('ui/dashboard.html') });
}

// Load settings from storage
function loadSettings() {
  chrome.storage.local.get(['tradeTellerSettings'], (result) => {
    if (result.tradeTellerSettings) {
      appState.settings = {
        ...appState.settings,
        ...result.tradeTellerSettings
      };
      applySettings();
    }
  });
}

// Apply settings to the UI
function applySettings() {
  // Apply dark mode
  if (appState.settings.darkMode) {
    document.body.classList.add('dark-mode');
  } else {
    document.body.classList.remove('dark-mode');
  }
  
  // Save settings
  chrome.storage.local.set({ tradeTellerSettings: appState.settings });
  
  // Dispatch event for components to update
  document.dispatchEvent(new CustomEvent('appSettingsChanged', {
    detail: appState.settings
  }));
}

// Show error message
function showError(message) {
  const errorElement = document.createElement('div');
  errorElement.className = 'error-message';
  errorElement.innerHTML = `
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="10"></circle>
      <line x1="12" y1="8" x2="12" y2="12"></line>
      <line x1="12" y1="16" x2="12.01" y2="16"></line>
    </svg>
    <span>${message}</span>
  `;
  
  document.body.prepend(errorElement);
  setTimeout(() => errorElement.remove(), 5000);
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', initPopup);

// Handle messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'NEW_ALERT') {
    // Handle new alerts
    document.dispatchEvent(new CustomEvent('newAlert', {
      detail: message.alert
    }));
  } else if (message.type === 'MARKET_UPDATE') {
    // Handle market updates
    appState.marketData = message.data;
    renderComponents();
  }
});