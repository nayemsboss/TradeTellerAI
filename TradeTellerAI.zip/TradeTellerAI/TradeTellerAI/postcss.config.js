module.exports = {
  plugins: {
    // 1. Tailwind CSS integration
    'tailwindcss/nesting': {}, // Enable nested CSS (Sass-like syntax)
    'tailwindcss': {}, // Tailwind CSS processor
    
    // 2. Autoprefixer with Chrome extension targets
    'autoprefixer': {
      overrideBrowserslist: [
        'last 2 Chrome versions',
        'last 2 ChromeAndroid versions',
        'last 2 Edge versions'
      ],
      flexbox: 'no-2009' // Optimize for modern flexbox
    },
    
    // 3. Production optimizations
    ...(process.env.NODE_ENV === 'production'
      ? {
          'postcss-combine-media-query': {}, // Merge duplicate media queries
          'postcss-sort-media-queries': { // Sort media queries mobile-first
            sort: 'mobile-first'
          },
          'postcss-combine-duplicated-selectors': { // Merge duplicate selectors
            removeDuplicatedProperties: true
          },
          'cssnano': { // Minify CSS
            preset: ['default', {
              discardComments: { removeAll: true },
              normalizeWhitespace: true,
              colormin: { exclude: true } // Preserve exact color values
            }]
          }
        }
      : {})
  }
};