// services/alertSystem.js
import { config } from '../constants/config';
import { logger } from '../utils/logger';
import { playAlertSound } from '../utils/audioFeedback';
import { calculateRiskLevel } from '../services/riskManager';

/**
 * Alert System for TradeTellerAI
 * Handles all types of trading alerts including:
 * - Price level alerts
 * - Technical indicator alerts
 * - News sentiment alerts
 * - AI prediction alerts
 */

// Alert severity levels
export const ALERT_LEVELS = {
  INFO: 'info',
  WARNING: 'warning',
  CRITICAL: 'critical',
  SUCCESS: 'success'
};

// Alert types
export const ALERT_TYPES = {
  PRICE: 'price',
  TECHNICAL: 'technical',
  NEWS: 'news',
  AI: 'ai',
  RISK: 'risk'
};

// Alert storage in IndexedDB
const alertDB = {
  name: 'TradeTellerAlerts',
  version: 1,
  stores: {
    active: 'activeAlerts',
    history: 'alertHistory'
  }
};

/**
 * Initialize the alert system
 */
export const initAlertSystem = async () => {
  try {
    // Check if alerts are enabled in config
    if (!config.alerts.enabled) {
      logger.warn('Alert system is disabled in configuration');
      return false;
    }

    // Setup IndexedDB for alert storage
    await _setupAlertDB();
    logger.info('Alert system initialized successfully');
    return true;
  } catch (error) {
    logger.error('Failed to initialize alert system:', error);
    return false;
  }
};

/**
 * Create a new trading alert
 * @param {Object} alertData - Alert configuration
 * @param {string} alertData.type - Type of alert (ALERT_TYPES)
 * @param {string} alertData.level - Severity level (ALERT_LEVELS)
 * @param {string} alertData.message - Alert message
 * @param {Object} alertData.metadata - Additional alert data
 * @param {boolean} [persist=true] - Whether to persist the alert
 */
export const createAlert = async (alertData, persist = true) => {
  const { type, level, message, metadata } = alertData;
  
  if (!type || !ALERT_TYPES[type.toUpperCase()]) {
    logger.error(`Invalid alert type: ${type}`);
    return false;
  }

  if (!level || !ALERT_LEVELS[level.toUpperCase()]) {
    logger.error(`Invalid alert level: ${level}`);
    return false;
  }

  const alert = {
    id: generateAlertId(),
    timestamp: new Date().toISOString(),
    type: type.toLowerCase(),
    level: level.toLowerCase(),
    message,
    metadata: metadata || {},
    isActive: true,
    acknowledged: false
  };

  try {
    // Play corresponding sound
    await playAlertSound(level);

    // Persist to DB if required
    if (persist) {
      await _storeAlert(alert);
    }

    // Dispatch event for UI components
    _dispatchAlertEvent(alert);

    logger.log(`Alert created: ${alert.id}`, alert);
    return alert.id;
  } catch (error) {
    logger.error('Failed to create alert:', error);
    return false;
  }
};

/**
 * Process AI prediction alerts
 * @param {Object} prediction - AI prediction result
 * @param {Object} marketData - Current market data
 */
export const processAIPredictionAlert = async (prediction, marketData) => {
  if (!prediction || !marketData) {
    logger.error('Invalid prediction or market data for alert');
    return false;
  }

  const { confidence, direction, timeFrame } = prediction;
  const { symbol, price } = marketData;

  // Determine alert level based on confidence
  let alertLevel = ALERT_LEVELS.INFO;
  if (confidence >= 80) alertLevel = ALERT_LEVELS.CRITICAL;
  else if (confidence >= 60) alertLevel = ALERT_LEVELS.WARNING;

  // Calculate risk level
  const riskLevel = await calculateRiskLevel(marketData);

  const alertData = {
    type: ALERT_TYPES.AI,
    level: alertLevel,
    message: `AI Prediction: ${direction.toUpperCase()} signal for ${symbol} ` +
             `with ${confidence}% confidence (${timeFrame})`,
    metadata: {
      symbol,
      currentPrice: price,
      prediction,
      riskLevel
    }
  };

  return createAlert(alertData);
};

/**
 * Process technical indicator alerts
 * @param {Object} indicatorData - Technical indicator values
 * @param {Object} marketData - Current market data
 */
export const processTechnicalAlert = async (indicatorData, marketData) => {
  // Implementation for technical indicator alerts
  // (RSI, MACD, etc. crossing thresholds)
};

/**
 * Process news sentiment alerts
 * @param {Object} sentimentData - News sentiment analysis
 * @param {Object} marketData - Current market data
 */
export const processNewsSentimentAlert = async (sentimentData, marketData) => {
  // Implementation for news sentiment alerts
};

// Private helper functions
const _setupAlertDB = async () => {
  // Implementation for IndexedDB setup
};

const _storeAlert = async (alert) => {
  // Implementation for storing alerts in IndexedDB
};

const _dispatchAlertEvent = (alert) => {
  const event = new CustomEvent('tradeTellerAlert', {
    detail: alert
  });
  window.dispatchEvent(event);
};

const generateAlertId = () => {
  return `alert_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
};

// Initialize the alert system when imported
initAlertSystem().catch(error => {
  logger.error('Alert system initialization error:', error);
});