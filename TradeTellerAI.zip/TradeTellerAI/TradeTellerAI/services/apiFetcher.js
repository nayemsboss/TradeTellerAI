// services/apiFetcher.js
import { config } from '../constants/config';
import { logger } from '../utils/logger';
import { normalizeMarketData } from '../services/dataNormalizer';

/**
 * Fetches real-time market data from supported APIs
 * @param {string} symbol - Trading pair symbol (e.g., 'EUR/USD')
 * @param {string} [provider='default'] - API provider to use
 * @returns {Promise<Object>} Normalized market data
 */
export const fetchMarketData = async (symbol, provider = 'default') => {
  try {
    const apiConfig = getApiConfig(provider);
    const endpoint = buildEndpoint(apiConfig, symbol);
    
    const response = await fetchWithTimeout(endpoint, {
      method: 'GET',
      headers: getHeaders(apiConfig),
      timeout: config.API_TIMEOUT
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }

    const rawData = await response.json();
    const normalizedData = normalizeMarketData(rawData, provider);
    
    logger.log(`Fetched data for ${symbol} from ${provider}`, 'API');
    return normalizedData;

  } catch (error) {
    logger.error(`API Fetch failed for ${symbol}: ${error.message}`, 'API');
    throw error;
  }
};

/**
 * Fetches historical candle data
 * @param {string} symbol - Trading pair
 * @param {string} timeframe - Timeframe (e.g., '1h', '4h', '1d')
 * @param {number} [limit=500] - Number of candles to fetch
 * @returns {Promise<Array>} Array of candle data
 */
export const fetchHistoricalData = async (symbol, timeframe, limit = 500) => {
  try {
    const endpoint = `${config.HISTORICAL_API}?symbol=${symbol}&timeframe=${timeframe}&limit=${limit}`;
    const response = await fetchWithTimeout(endpoint, {
      timeout: config.HISTORICAL_TIMEOUT
    });

    const data = await response.json();
    return data.candles || [];

  } catch (error) {
    logger.error(`Historical data fetch failed: ${error.message}`, 'API');
    return [];
  }
};

/**
 * Fetches news and sentiment data
 * @param {string} [query='forex'] - News search query
 * @param {number} [hours=24] - Lookback hours
 * @returns {Promise<Array>} Array of news items with sentiment
 */
export const fetchNewsSentiment = async (query = 'forex', hours = 24) => {
  try {
    const endpoint = `${config.NEWS_API}?query=${encodeURIComponent(query)}&hours=${hours}`;
    const response = await fetch(endpoint);
    return await response.json();
  } catch (error) {
    logger.error(`News fetch failed: ${error.message}`, 'API');
    return [];
  }
};

// Helper functions
const fetchWithTimeout = async (url, options = {}) => {
  const { timeout = 5000, ...fetchOptions } = options;
  
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);

  try {
    const response = await fetch(url, {
      ...fetchOptions,
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    return response;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
};

const getApiConfig = (provider) => {
  return config.API_PROVIDERS[provider] || config.API_PROVIDERS.default;
};

const buildEndpoint = (apiConfig, symbol) => {
  return apiConfig.endpoint.replace('{symbol}', symbol);
};

const getHeaders = (apiConfig) => {
  const headers = { 'Content-Type': 'application/json' };
  if (apiConfig.apiKey) {
    headers[apiConfig.authHeader] = apiConfig.apiKey;
  }
  return headers;
};

export default {
  fetchMarketData,
  fetchHistoricalData,
  fetchNewsSentiment
};