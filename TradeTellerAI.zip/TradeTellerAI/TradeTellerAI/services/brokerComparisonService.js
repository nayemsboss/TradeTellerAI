// services/brokerComparisonService.js
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { EventEmitter } from 'events';
import { fetchBrokerData } from './apiFetcher';
import { calculateScore, normalizeBrokerData } from '../utils/brokerUtils';

/**
 * Advanced Broker Comparison and Analysis Service
 */
export class BrokerComparisonService extends EventEmitter {
  constructor() {
    super();
    this.brokers = new Map(); // Stores all broker data
    this.userPreferences = {};
    this.marketConditions = {};
    this.scoringWeights = config.BROKER_SCORING_WEIGHTS;
    this.init();
  }

  /**
   * Initialize service and load broker data
   */
  async init() {
    try {
      await this.loadBrokerData();
      logger.log('Broker comparison service initialized', 'BrokerComparison');
      this.emit('initialized');
    } catch (error) {
      logger.error(`Failed to initialize broker service: ${error.message}`, 'BrokerComparison');
      this.emit('error', error);
    }
  }

  /**
   * Load and normalize broker data from API
   */
  async loadBrokerData() {
    try {
      const rawData = await fetchBrokerData();
      const normalizedData = normalizeBrokerData(rawData);
      
      normalizedData.forEach(broker => {
        this.brokers.set(broker.id, broker);
      });
      
      logger.log(`Loaded data for ${normalizedData.length} brokers`, 'BrokerComparison');
    } catch (error) {
      throw new Error(`Broker data loading failed: ${error.message}`);
    }
  }

  /**
   * Update user preferences for broker scoring
   * @param {UserPreferences} preferences 
   */
  updateUserPreferences(preferences) {
    this.userPreferences = {
      ...this.userPreferences,
      ...preferences
    };
    
    // Adjust scoring weights based on preferences
    this.adjustScoringWeights(preferences);
    
    logger.log('User preferences updated', 'BrokerComparison');
    this.emit('preferencesUpdated', this.userPreferences);
  }

  /**
   * Update market conditions for dynamic scoring
   * @param {MarketConditions} conditions 
   */
  updateMarketConditions(conditions) {
    this.marketConditions = {
      ...this.marketConditions,
      ...conditions
    };
    
    logger.log('Market conditions updated', 'BrokerComparison');
    this.emit('marketConditionsUpdated', this.marketConditions);
  }

  /**
   * Adjust scoring weights based on user preferences
   * @param {UserPreferences} preferences 
   */
  adjustScoringWeights(preferences) {
    // Increase weights for preferred attributes
    if (preferences.tradingStyle === 'scalping') {
      this.scoringWeights = {
        ...this.scoringWeights,
        spreads: this.scoringWeights.spreads * 1.5,
        executionSpeed: this.scoringWeights.executionSpeed * 1.3,
        commissions: this.scoringWeights.commissions * 1.2
      };
    } else if (preferences.tradingStyle === 'swing') {
      this.scoringWeights = {
        ...this.scoringWeights,
        overnightFees: this.scoringWeights.overnightFees * 0.7,
        spreads: this.scoringWeights.spreads * 0.8,
        platformStability: this.scoringWeights.platformStability * 1.4
      };
    }

    // Adjust for risk tolerance
    if (preferences.riskTolerance === 'low') {
      this.scoringWeights.safety = this.scoringWeights.safety * 1.5;
    }

    // Normalize weights to sum to 1
    this.normalizeWeights();
  }

  /**
   * Normalize scoring weights to sum to 1
   */
  normalizeWeights() {
    const totalWeight = Object.values(this.scoringWeights).reduce((sum, w) => sum + w, 0);
    for (const key in this.scoringWeights) {
      this.scoringWeights[key] = this.scoringWeights[key] / totalWeight;
    }
  }

  /**
   * Compare brokers based on current criteria
   * @param {ComparisonCriteria} [criteria] 
   * @returns {BrokerComparisonResult}
   */
  compareBrokers(criteria = {}) {
    try {
      const brokersArray = Array.from(this.brokers.values());
      
      // Apply filters first
      const filteredBrokers = this.applyFilters(brokersArray, criteria.filters);
      
      // Score brokers
      const scoredBrokers = filteredBrokers.map(broker => ({
        ...broker,
        score: this.calculateBrokerScore(broker, criteria)
      }));
      
      // Sort by score
      const sortedBrokers = scoredBrokers.sort((a, b) => b.score - a.score);
      
      // Prepare result
      const result = {
        brokers: sortedBrokers,
        topBrokers: sortedBrokers.slice(0, 5),
        timestamp: new Date().toISOString(),
        criteriaUsed: {
          ...this.userPreferences,
          ...criteria,
          marketConditions: this.marketConditions
        }
      };
      
      this.emit('comparisonComplete', result);
      return result;
    } catch (error) {
      logger.error(`Broker comparison failed: ${error.message}`, 'BrokerComparison');
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Apply filters to broker list
   * @param {Broker[]} brokers 
   * @param {BrokerFilters} [filters] 
   * @returns {Broker[]}
   */
  applyFilters(brokers, filters = {}) {
    return brokers.filter(broker => {
      // Regulation filter
      if (filters.regulations && filters.regulations.length > 0) {
        const hasRequiredRegulation = filters.regulations.some(reg => 
          broker.regulations.includes(reg)
        );
        if (!hasRequiredRegulation) return false;
      }
      
      // Asset filter
      if (filters.assets && filters.assets.length > 0) {
        const hasAllAssets = filters.assets.every(asset => 
          broker.assets.includes(asset)
        );
        if (!hasAllAssets) return false;
      }
      
      // Platform filter
      if (filters.platforms && filters.platforms.length > 0) {
        const hasRequiredPlatform = filters.platforms.some(platform => 
          broker.platforms.includes(platform)
        );
        if (!hasRequiredPlatform) return false;
      }
      
      // Account type filter
      if (filters.accountTypes && filters.accountTypes.length > 0) {
        const hasRequiredAccountType = filters.accountTypes.some(type => 
          broker.accountTypes.includes(type)
        );
        if (!hasRequiredAccountType) return false;
      }
      
      // Minimum deposit filter
      if (filters.minDeposit !== undefined) {
        if (broker.minDeposit > filters.minDeposit) return false;
      }
      
      return true;
    });
  }

  /**
   * Calculate comprehensive score for a broker
   * @param {Broker} broker 
   * @param {ComparisonCriteria} criteria 
   * @returns {number}
   */
  calculateBrokerScore(broker, criteria) {
    // Base score from broker attributes
    let score = calculateScore(broker, this.scoringWeights);
    
    // Adjust for market conditions
    score = this.adjustScoreForMarketConditions(score, broker);
    
    // Apply user preference boosts
    score = this.applyPreferenceBoosts(score, broker, criteria);
    
    // Apply dynamic adjustments
    score = this.applyDynamicAdjustments(score, broker);
    
    return Math.min(100, Math.max(0, score));
  }

  /**
   * Adjust score based on current market conditions
   * @param {number} score 
   * @param {Broker} broker 
   * @returns {number}
   */
  adjustScoreForMarketConditions(score, broker) {
    // During high volatility, favor brokers with better execution
    if (this.marketConditions.volatility === 'high') {
      score += broker.metrics.executionSpeed * 0.5;
      score += broker.metrics.slippage * -0.3;
    }
    
    // During low liquidity, favor brokers with deeper liquidity pools
    if (this.marketConditions.liquidity === 'low') {
      score += broker.metrics.liquidity * 0.4;
    }
    
    return score;
  }

  /**
   * Apply boosts based on user preferences
   * @param {number} score 
   * @param {Broker} broker 
   * @param {ComparisonCriteria} criteria 
   * @returns {number}
   */
  applyPreferenceBoosts(score, broker, criteria) {
    // Trading style boosts
    if (this.userPreferences.tradingStyle === 'scalping') {
      score += broker.metrics.executionSpeed * 0.7;
      score += broker.metrics.spreads * -1.2; // Lower spreads better
    }
    
    // Preferred assets boost
    if (criteria.preferredAssets) {
      const assetOverlap = broker.assets.filter(asset => 
        criteria.preferredAssets.includes(asset)
      ).length;
      score += assetOverlap * 0.5;
    }
    
    // Platform preference boost
    if (this.userPreferences.preferredPlatforms) {
      const platformMatch = this.userPreferences.preferredPlatforms.some(platform => 
        broker.platforms.includes(platform)
      );
      if (platformMatch) score += 5;
    }
    
    return score;
  }

  /**
   * Apply dynamic adjustments based on real-time data
   * @param {number} score 
   * @param {Broker} broker 
   * @returns {number}
   */
  applyDynamicAdjustments(score, broker) {
    // Recent API downtime penalty
    if (broker.metrics.recentDowntime > 0) {
      score -= broker.metrics.recentDowntime * 2;
    }
    
    // Recent price improvement boost
    if (broker.metrics.priceImprovement > 0) {
      score += broker.metrics.priceImprovement * 1.5;
    }
    
    // Client satisfaction adjustment
    if (broker.metrics.clientSatisfaction < 50) {
      score -= (50 - broker.metrics.clientSatisfaction) * 0.2;
    }
    
    return score;
  }

  /**
   * Get detailed comparison for 2 brokers
   * @param {string} broker1Id 
   * @param {string} broker2Id 
   * @returns {DetailedComparison}
   */
  getDetailedComparison(broker1Id, broker2Id) {
    const broker1 = this.brokers.get(broker1Id);
    const broker2 = this.brokers.get(broker2Id);
    
    if (!broker1 || !broker2) {
      throw new Error('One or both brokers not found');
    }
    
    const comparison = {
      brokers: [broker1, broker2],
      advantages: {},
      disadvantages: {},
      scoreDifference: Math.abs(broker1.score - broker2.score),
      metricsComparison: this.compareMetrics(broker1, broker2),
      lastUpdated: new Date().toISOString()
    };
    
    // Find advantages for each broker
    comparison.advantages[broker1.id] = this.findAdvantages(broker1, broker2);
    comparison.advantages[broker2.id] = this.findAdvantages(broker2, broker1);
    
    // Find disadvantages for each broker
    comparison.disadvantages[broker1.id] = this.findDisadvantages(broker1, broker2);
    comparison.disadvantages[broker2.id] = this.findDisadvantages(broker2, broker1);
    
    this.emit('detailedComparison', comparison);
    return comparison;
  }

  /**
   * Compare metrics between two brokers
   * @param {Broker} broker1 
   * @param {Broker} broker2 
   * @returns {MetricComparison[]}
   */
  compareMetrics(broker1, broker2) {
    const metrics = [
      'spreads', 'executionSpeed', 'commissions', 
      'overnightFees', 'slippage', 'liquidity'
    ];
    
    return metrics.map(metric => ({
      metric,
      broker1Value: broker1.metrics[metric],
      broker2Value: broker2.metrics[metric],
      difference: broker1.metrics[metric] - broker2.metrics[metric],
      betterBroker: this.determineBetterBroker(metric, broker1, broker2)
    }));
  }

  /**
   * Determine which broker is better for a specific metric
   * @param {string} metric 
   * @param {Broker} broker1 
   * @param {Broker} broker2 
   * @returns {string|null} - Broker ID or null if equal
   */
  determineBetterBroker(metric, broker1, broker2) {
    // Lower is better for these metrics
    const lowerIsBetter = ['spreads', 'commissions', 'overnightFees', 'slippage'];
    
    if (lowerIsBetter.includes(metric)) {
      if (broker1.metrics[metric] < broker2.metrics[metric]) return broker1.id;
      if (broker1.metrics[metric] > broker2.metrics[metric]) return broker2.id;
    } else {
      // Higher is better for other metrics
      if (broker1.metrics[metric] > broker2.metrics[metric]) return broker1.id;
      if (broker1.metrics[metric] < broker2.metrics[metric]) return broker2.id;
    }
    
    return null;
  }

  /**
   * Find advantages of broker1 over broker2
   * @param {Broker} broker1 
   * @param {Broker} broker2 
   * @returns {BrokerAdvantage[]}
   */
  findAdvantages(broker1, broker2) {
    const advantages = [];
    const metrics = Object.keys(broker1.metrics);
    
    for (const metric of metrics) {
      const betterBroker = this.determineBetterBroker(metric, broker1, broker2);
      if (betterBroker === broker1.id) {
        advantages.push({
          metric,
          value: broker1.metrics[metric],
          competitorValue: broker2.metrics[metric],
          difference: broker1.metrics[metric] - broker2.metrics[metric],
          importance: this.scoringWeights[metric] || 0.5
        });
      }
    }
    
    // Sort by importance
    return advantages.sort((a, b) => b.importance - a.importance);
  }

  /**
   * Find disadvantages of broker1 compared to broker2
   * @param {Broker} broker1 
   * @param {Broker} broker2 
   * @returns {BrokerDisadvantage[]}
   */
  findDisadvantages(broker1, broker2) {
    const disadvantages = [];
    const metrics = Object.keys(broker1.metrics);
    
    for (const metric of metrics) {
      const betterBroker = this.determineBetterBroker(metric, broker1, broker2);
      if (betterBroker === broker2.id) {
        disadvantages.push({
          metric,
          value: broker1.metrics[metric],
          competitorValue: broker2.metrics[metric],
          difference: broker1.metrics[metric] - broker2.metrics[metric],
          importance: this.scoringWeights[metric] || 0.5
        });
      }
    }
    
    // Sort by importance
    return disadvantages.sort((a, b) => b.importance - a.importance);
  }

  /**
   * Get best broker for specific trading needs
   * @param {TradingNeeds} needs 
   * @returns {BrokerRecommendation}
   */
  getBestBrokerForNeeds(needs) {
    const allBrokers = Array.from(this.brokers.values());
    
    // Create temporary scoring weights based on needs
    const tempWeights = {
      ...this.scoringWeights,
      spreads: needs.lowSpreads ? this.scoringWeights.spreads * 1.5 : this.scoringWeights.spreads,
      executionSpeed: needs.fastExecution ? this.scoringWeights.executionSpeed * 1.8 : this.scoringWeights.executionSpeed,
      commissions: needs.lowCommissions ? this.scoringWeights.commissions * 1.3 : this.scoringWeights.commissions,
      platformStability: needs.stablePlatform ? this.scoringWeights.platformStability * 1.4 : this.scoringWeights.platformStability,
      safety: needs.highSafety ? this.scoringWeights.safety * 2.0 : this.scoringWeights.safety
    };
    
    // Normalize temporary weights
    const totalWeight = Object.values(tempWeights).reduce((sum, w) => sum + w, 0);
    for (const key in tempWeights) {
      tempWeights[key] = tempWeights[key] / totalWeight;
    }
    
    // Score brokers with temporary weights
    const scoredBrokers = allBrokers.map(broker => ({
      ...broker,
      score: calculateScore(broker, tempWeights)
    })).sort((a, b) => b.score - a.score);
    
    const recommendation = {
      topBrokers: scoredBrokers.slice(0, 3),
      needs,
      weightsUsed: tempWeights,
      timestamp: new Date().toISOString()
    };
    
    this.emit('recommendationGenerated', recommendation);
    return recommendation;
  }

  /**
   * Get broker by ID
   * @param {string} brokerId 
   * @returns {Broker|null}
   */
  getBroker(brokerId) {
    return this.brokers.get(brokerId) || null;
  }

  /**
   * Get all brokers
   * @returns {Broker[]}
   */
  getAllBrokers() {
    return Array.from(this.brokers.values());
  }
}

// Singleton instance
export const brokerComparisonService = new BrokerComparisonService();

// ===== Type Definitions =====

/**
 * @typedef {Object} Broker
 * @property {string} id
 * @property {string} name
 * @property {string[]} regulations
 * @property {string[]} platforms
 * @property {string[]} accountTypes
 * @property {string[]} assets
 * @property {number} minDeposit
 * @property {BrokerMetrics} metrics
 * @property {number} [score]
 * @property {string} [logoUrl]
 * @property {string} [website]
 */

/**
 * @typedef {Object} BrokerMetrics
 * @property {number} spreads - Average spread in pips
 * @property {number} executionSpeed - In milliseconds
 * @property {number} commissions - Per trade or per lot
 * @property {number} overnightFees - Swap rates
 * @property {number} slippage - Percentage
 * @property {number} liquidity - Relative score
 * @property {number} platformStability - Uptime percentage
 * @property {number} safety - Regulation score
 * @property {number} recentDowntime - Minutes in last month
 * @property {number} priceImprovement - Percentage of time
 * @property {number} clientSatisfaction - Percentage
 */

/**
 * @typedef {Object} UserPreferences
 * @property {'scalping'|'day'|'swing'|'position'} [tradingStyle]
 * @property {'low'|'medium'|'high'} [riskTolerance]
 * @property {string[]} [preferredPlatforms]
 * @property {string[]} [preferredAssets]
 */

/**
 * @typedef {Object} MarketConditions
 * @property {'low'|'medium'|'high'} [volatility]
 * @property {'low'|'medium'|'high'} [liquidity]
 * @property {'normal'|'news'|'off-hours'} [marketState]
 */

/**
 * @typedef {Object} ComparisonCriteria
 * @property {BrokerFilters} [filters]
 * @property {string[]} [preferredAssets]
 */

/**
 * @typedef {Object} BrokerFilters
 * @property {string[]} [regulations]
 * @property {string[]} [assets]
 * @property {string[]} [platforms]
 * @property {string[]} [accountTypes]
 * @property {number} [minDeposit]
 */

/**
 * @typedef {Object} BrokerComparisonResult
 * @property {Broker[]} brokers - Sorted by score
 * @property {Broker[]} topBrokers - Top 5 brokers
 * @property {string} timestamp
 * @property {Object} criteriaUsed
 */

/**
 * @typedef {Object} DetailedComparison
 * @property {Broker[]} brokers - The two brokers being compared
 * @property {Object.<string, BrokerAdvantage[]>} advantages
 * @property {Object.<string, BrokerDisadvantage[]>} disadvantages
 * @property {number} scoreDifference
 * @property {MetricComparison[]} metricsComparison
 * @property {string} lastUpdated
 */

/**
 * @typedef {Object} BrokerAdvantage
 * @property {string} metric
 * @property {number} value
 * @property {number} competitorValue
 * @property {number} difference
 * @property {number} importance
 */

/**
 * @typedef {Object} BrokerDisadvantage
 * @property {string} metric
 * @property {number} value
 * @property {number} competitorValue
 * @property {number} difference
 * @property {number} importance
 */

/**
 * @typedef {Object} MetricComparison
 * @property {string} metric
 * @property {number} broker1Value
 * @property {number} broker2Value
 * @property {number} difference
 * @property {string|null} betterBroker - ID of better broker or null if equal
 */

/**
 * @typedef {Object} TradingNeeds
 * @property {boolean} [lowSpreads]
 * @property {boolean} [fastExecution]
 * @property {boolean} [lowCommissions]
 * @property {boolean} [stablePlatform]
 * @property {boolean} [highSafety]
 * @property {boolean} [highLiquidity]
 */

/**
 * @typedef {Object} BrokerRecommendation
 * @property {Broker[]} topBrokers - Top 3 recommended brokers
 * @property {TradingNeeds} needs - Needs that were considered
 * @property {Object} weightsUsed - Scoring weights used
 * @property {string} timestamp
 */