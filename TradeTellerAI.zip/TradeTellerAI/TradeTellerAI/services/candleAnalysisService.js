// services/candleAnalysisService.js
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { EventEmitter } from 'events';
import { patternDefinitions } from '../constants/patternDefinitions';
import { calculateBodySize, calculateWickSizes, isDoji } from '../utils/candleUtils';

/**
 * Advanced Candlestick Pattern Analysis Service
 */
export class CandleAnalysisService extends EventEmitter {
  constructor() {
    super();
    this.patternLibrary = {};
    this.currentPatterns = new Map();
    this.historicalPatterns = [];
    this.initializePatternLibrary();
  }

  /**
   * Initialize pattern recognition library
   */
  initializePatternLibrary() {
    // Load predefined patterns
    this.patternLibrary = patternDefinitions;

    // Add dynamic pattern detection methods
    this.addDynamicPatterns();

    logger.log(`Initialized with ${Object.keys(this.patternLibrary).length} candlestick patterns`, 'CandleAnalysis');
  }

  /**
   * Add dynamic/complex pattern detectors
   */
  addDynamicPatterns() {
    // Fibonacci-based patterns
    this.patternLibrary.fibonacciRetracement = {
      name: 'Fibonacci Retracement',
      complexity: 'high',
      timeframe: 'all',
      detect: (candles, context) => this.detectFibonacciPattern(candles, context)
    };

    // Volume-spike patterns
    this.patternLibrary.volumeSpike = {
      name: 'Volume Spike',
      complexity: 'medium',
      timeframe: 'all',
      detect: (candles, context) => this.detectVolumeSpike(candles, context)
    };

    // Multi-timeframe confirmation patterns
    this.patternLibrary.multiTimeframeConfirmation = {
      name: 'Multi-Timeframe Confirmation',
      complexity: 'high',
      timeframe: 'all',
      detect: (candles, context) => this.detectMultiTimeframeConfirmation(candles, context)
    };
  }

  /**
   * Analyze candle(s) for patterns
   * @param {Candle[]} candles - Array of candle data
   * @param {Object} context - Market context data
   * @returns {PatternAnalysisResult}
   */
  analyzeCandles(candles, context = {}) {
    if (!candles || candles.length === 0) {
      logger.warn('No candles provided for analysis', 'CandleAnalysis');
      return null;
    }

    try {
      const detectionResults = this.detectPatterns(candles, context);
      const probabilityAssessment = this.assessPatternProbabilities(detectionResults, context);
      const tradeSignals = this.generateTradeSignals(probabilityAssessment);

      // Store current patterns
      this.currentPatterns.set(context.symbol || 'default', detectionResults);

      // Emit analysis complete event
      this.emit('analysisComplete', {
        symbol: context.symbol,
        timeframe: context.timeframe,
        results: detectionResults,
        signals: tradeSignals
      });

      return {
        patterns: detectionResults,
        probabilities: probabilityAssessment,
        signals: tradeSignals,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error(`Candle analysis failed: ${error.message}`, 'CandleAnalysis');
      this.emit('analysisFailed', error);
      throw error;
    }
  }

  /**
   * Detect all applicable patterns
   * @param {Candle[]} candles 
   * @param {Object} context 
   * @returns {PatternDetectionResult[]}
   */
  detectPatterns(candles, context) {
    const results = [];
    const lastCandle = candles[candles.length - 1];
    const previousCandles = candles.slice(0, -1);

    // Detect single candle patterns
    if (candles.length >= 1) {
      for (const [patternId, patternDef] of Object.entries(this.patternLibrary)) {
        if (patternDef.requiredCandles === 1) {
          const detection = patternDef.detect([lastCandle], context);
          if (detection.detected) {
            results.push({
              patternId,
              name: patternDef.name,
              type: 'single',
              candleIndex: candles.length - 1,
              direction: detection.direction,
              confidence: detection.confidence,
              complexity: patternDef.complexity,
              timeframe: patternDef.timeframe
            });
          }
        }
      }
    }

    // Detect multi-candle patterns
    if (candles.length >= 2) {
      for (const [patternId, patternDef] of Object.entries(this.patternLibrary)) {
        if (patternDef.requiredCandles > 1 && candles.length >= patternDef.requiredCandles) {
          const relevantCandles = candles.slice(-patternDef.requiredCandles);
          const detection = patternDef.detect(relevantCandles, context);
          if (detection.detected) {
            results.push({
              patternId,
              name: patternDef.name,
              type: 'multi',
              candleIndexes: Array.from({length: patternDef.requiredCandles}, (_, i) => candles.length - patternDef.requiredCandles + i),
              direction: detection.direction,
              confidence: detection.confidence,
              complexity: patternDef.complexity,
              timeframe: patternDef.timeframe
            });
          }
        }
      }
    }

    // Detect dynamic patterns (require full context)
    for (const [patternId, patternDef] of Object.entries(this.patternLibrary)) {
      if (patternDef.complexity === 'high') {
        const detection = patternDef.detect(candles, context);
        if (detection.detected) {
          results.push({
            patternId,
            name: patternDef.name,
            type: 'contextual',
            candleIndexes: detection.candleIndexes || [],
            direction: detection.direction,
            confidence: detection.confidence,
            complexity: 'high',
            timeframe: 'all'
          });
        }
      }
    }

    return results;
  }

  /**
   * Assess probabilities for detected patterns
   * @param {PatternDetectionResult[]} detections 
   * @param {Object} context 
   * @returns {ProbabilityAssessment[]}
   */
  assessPatternProbabilities(detections, context) {
    if (!detections || detections.length === 0) return [];

    return detections.map(detection => {
      const baseProbability = this.calculateBaseProbability(detection);
      const contextFactor = this.calculateContextFactor(detection, context);
      const timeframeFactor = this.calculateTimeframeFactor(detection, context.timeframe);
      const volumeFactor = this.calculateVolumeFactor(detection, context.volume);

      const finalProbability = Math.min(0.99, Math.max(0.01,
        baseProbability * contextFactor * timeframeFactor * volumeFactor
      ));

      return {
        patternId: detection.patternId,
        name: detection.name,
        baseProbability,
        finalProbability,
        factors: {
          context: contextFactor,
          timeframe: timeframeFactor,
          volume: volumeFactor
        }
      };
    });
  }

  /**
   * Generate trade signals from pattern probabilities
   * @param {ProbabilityAssessment[]} probabilities 
   * @returns {TradeSignal[]}
   */
  generateTradeSignals(probabilities) {
    if (!probabilities || probabilities.length === 0) return [];

    const signals = [];
    const bullishPatterns = probabilities.filter(p => 
      this.patternLibrary[p.patternId].defaultDirection === 'bullish'
    );
    const bearishPatterns = probabilities.filter(p => 
      this.patternLibrary[p.patternId].defaultDirection === 'bearish'
    );

    // Generate bullish signals
    if (bullishPatterns.length > 0) {
      const strongestBullish = bullishPatterns.reduce((strongest, current) => 
        current.finalProbability > strongest.finalProbability ? current : strongest
      );

      signals.push({
        direction: 'bullish',
        patternId: strongestBullish.patternId,
        patternName: strongestBullish.name,
        confidence: strongestBullish.finalProbability,
        suggestedAction: this.getSuggestedAction(strongestBullish, 'bullish'),
        conflictingPatterns: bearishPatterns.map(p => p.patternId)
      });
    }

    // Generate bearish signals
    if (bearishPatterns.length > 0) {
      const strongestBearish = bearishPatterns.reduce((strongest, current) => 
        current.finalProbability > strongest.finalProbability ? current : strongest
      );

      signals.push({
        direction: 'bearish',
        patternId: strongestBearish.patternId,
        patternName: strongestBearish.name,
        confidence: strongestBearish.finalProbability,
        suggestedAction: this.getSuggestedAction(strongestBearish, 'bearish'),
        conflictingPatterns: bullishPatterns.map(p => p.patternId)
      });
    }

    return signals;
  }

  /**
   * Detect Fibonacci retracement patterns
   * @param {Candle[]} candles 
   * @param {Object} context 
   * @returns {PatternDetection}
   */
  detectFibonacciPattern(candles, context) {
    if (candles.length < 10) return { detected: false };

    // Simplified Fibonacci detection logic
    const recentHigh = Math.max(...candles.slice(-10).map(c => c.high));
    const recentLow = Math.min(...candles.slice(-10).map(c => c.low));
    const currentPrice = candles[candles.length - 1].close;
    const moveSize = recentHigh - recentLow;

    const levels = {
      '0.236': recentHigh - moveSize * 0.236,
      '0.382': recentHigh - moveSize * 0.382,
      '0.5': recentHigh - moveSize * 0.5,
      '0.618': recentHigh - moveSize * 0.618,
      '0.786': recentHigh - moveSize * 0.786
    };

    let detectedLevel = null;
    for (const [level, price] of Object.entries(levels)) {
      if (Math.abs(currentPrice - price) < moveSize * 0.02) {
        detectedLevel = level;
        break;
      }
    }

    if (!detectedLevel) return { detected: false };

    // Determine direction based on context
    const direction = context.trend === 'downtrend' ? 'bullish' : 'bearish';
    const confidence = 0.7 - (parseFloat(detectedLevel) * 0.1); // Deeper retracements = more confidence

    return {
      detected: true,
      direction,
      confidence: Math.max(0.3, Math.min(0.9, confidence)),
      candleIndexes: candles.length - 1,
      fibonacciLevel: detectedLevel
    };
  }

  /**
   * Detect volume spike patterns
   * @param {Candle[]} candles 
   * @param {Object} context 
   * @returns {PatternDetection}
   */
  detectVolumeSpike(candles, context) {
    if (candles.length < 5 || !context.volume) return { detected: false };

    const recentVolumes = candles.slice(-5).map(c => c.volume || 0);
    const avgVolume = recentVolumes.reduce((sum, vol) => sum + vol, 0) / recentVolumes.length;
    const currentVolume = context.volume;

    if (currentVolume > avgVolume * 2.5) {
      const lastCandle = candles[candles.length - 1];
      const isBullish = lastCandle.close > lastCandle.open;
      
      return {
        detected: true,
        direction: isBullish ? 'bullish' : 'bearish',
        confidence: Math.min(0.8, (currentVolume / avgVolume) / 5),
        candleIndexes: candles.length - 1,
        volumeRatio: currentVolume / avgVolume
      };
    }

    return { detected: false };
  }

  /**
   * Detect multi-timeframe confirmation patterns
   * @param {Candle[]} candles 
   * @param {Object} context 
   * @returns {PatternDetection}
   */
  detectMultiTimeframeConfirmation(candles, context) {
    if (!context.multiTimeframeData) return { detected: false };

    // Check if higher timeframes confirm the current pattern
    const higherTimeframeConfirmation = Object.entries(context.multiTimeframeData)
      .filter(([tf, _]) => this.isHigherTimeframe(tf, context.timeframe))
      .map(([_, data]) => data.patterns)
      .flat()
      .filter(pattern => 
        pattern.direction === this.getDominantDirection(candles) &&
        pattern.confidence > 0.6
      );

    if (higherTimeframeConfirmation.length > 0) {
      return {
        detected: true,
        direction: this.getDominantDirection(candles),
        confidence: Math.min(0.9, 0.5 + (higherTimeframeConfirmation.length * 0.1)),
        candleIndexes: candles.length - 1,
        confirmingTimeframes: higherTimeframeConfirmation.map(p => p.timeframe)
      };
    }

    return { detected: false };
  }

  /**
   * Calculate base probability for a pattern
   * @param {PatternDetectionResult} detection 
   * @returns {number}
   */
  calculateBaseProbability(detection) {
    // Base probability based on historical accuracy of this pattern
    const historicalAccuracy = this.getPatternHistoricalAccuracy(detection.patternId);
    const complexityFactor = detection.complexity === 'high' ? 0.9 : 1.0;
    
    return Math.min(0.95, Math.max(0.05, 
      detection.confidence * historicalAccuracy * complexityFactor
    ));
  }

  /**
   * Calculate context factor for probability adjustment
   * @param {PatternDetectionResult} detection 
   * @param {Object} context 
   * @returns {number}
   */
  calculateContextFactor(detection, context) {
    let factor = 1.0;
    
    // Trend alignment
    if (context.trend) {
      const trendAlignment = (
        (detection.direction === 'bullish' && context.trend === 'uptrend') ||
        (detection.direction === 'bearish' && context.trend === 'downtrend')
      ) ? 1.2 : 0.8;
      factor *= trendAlignment;
    }
    
    // Volatility adjustment
    if (context.volatility) {
      const volatilityFactor = context.volatility === 'high' ? 
        (detection.complexity === 'high' ? 1.1 : 0.9) : 1.0;
      factor *= volatilityFactor;
    }
    
    // News sentiment
    if (context.sentiment) {
      const sentimentFactor = (
        (detection.direction === 'bullish' && context.sentiment > 0) ||
        (detection.direction === 'bearish' && context.sentiment < 0)
      ) ? 1.15 : 0.85;
      factor *= sentimentFactor;
    }
    
    return Math.max(0.5, Math.min(1.5, factor));
  }

  /**
   * Calculate timeframe factor for probability adjustment
   * @param {PatternDetectionResult} detection 
   * @param {string} currentTimeframe 
   * @returns {number}
   */
  calculateTimeframeFactor(detection, currentTimeframe) {
    if (detection.timeframe === 'all') return 1.0;
    
    const timeframeStrength = {
      '1m': 0.7,
      '5m': 0.8,
      '15m': 0.9,
      '1h': 1.0,
      '4h': 1.1,
      '1d': 1.2,
      '1w': 1.3
    };
    
    const patternStrength = timeframeStrength[detection.timeframe] || 1.0;
    const currentStrength = timeframeStrength[currentTimeframe] || 1.0;
    
    return patternStrength * currentStrength;
  }

  /**
   * Calculate volume factor for probability adjustment
   * @param {PatternDetectionResult} detection 
   * @param {number} volume 
   * @returns {number}
   */
  calculateVolumeFactor(detection, volume) {
    if (!volume) return 1.0;
    
    // Higher volume increases confidence for most patterns
    const baseVolume = 100000; // Market-dependent baseline
    const volumeRatio = volume / baseVolume;
    
    return Math.min(1.5, Math.max(0.7, 0.8 + (volumeRatio / 2)));
  }

  /**
   * Get historical accuracy for a pattern
   * @param {string} patternId 
   * @returns {number}
   */
  getPatternHistoricalAccuracy(patternId) {
    // In a real implementation, this would query historical performance data
    const defaultAccuracies = {
      'engulfing': 0.65,
      'hammer': 0.7,
      'hangingMan': 0.68,
      'doji': 0.55,
      'morningStar': 0.72,
      'eveningStar': 0.71,
      'piercingLine': 0.63,
      'darkCloudCover': 0.64,
      'fibonacciRetracement': 0.75,
      'volumeSpike': 0.6,
      'multiTimeframeConfirmation': 0.8
    };
    
    return defaultAccuracies[patternId] || 0.6;
  }

  /**
   * Get suggested trading action for a pattern
   * @param {ProbabilityAssessment} assessment 
   * @param {string} direction 
   * @returns {string}
   */
  getSuggestedAction(assessment, direction) {
    if (assessment.finalProbability > 0.8) {
      return `Strong ${direction} signal - Consider entering position`;
    }
    if (assessment.finalProbability > 0.65) {
      return `Moderate ${direction} signal - Look for confirmation`;
    }
    return `Weak ${direction} signal - Wait for stronger confirmation`;
  }

  /**
   * Get dominant direction from candle series
   * @param {Candle[]} candles 
   * @returns {'bullish'|'bearish'|'neutral'}
   */
  getDominantDirection(candles) {
    if (candles.length === 0) return 'neutral';
    
    const bullishCount = candles.filter(c => c.close > c.open).length;
    const bearishCount = candles.filter(c => c.close < c.open).length;
    
    if (bullishCount > bearishCount * 1.5) return 'bullish';
    if (bearishCount > bullishCount * 1.5) return 'bearish';
    return 'neutral';
  }

  /**
   * Check if timeframe is higher than current
   * @param {string} timeframe 
   * @param {string} currentTimeframe 
   * @returns {boolean}
   */
  isHigherTimeframe(timeframe, currentTimeframe) {
    const timeframeOrder = ['1m', '5m', '15m', '1h', '4h', '1d', '1w'];
    return timeframeOrder.indexOf(timeframe) > timeframeOrder.indexOf(currentTimeframe);
  }

  /**
   * Track pattern performance over time
   * @param {string} patternId 
   * @param {boolean} wasSuccessful 
   */
  trackPatternPerformance(patternId, wasSuccessful) {
    // In a real implementation, this would update historical accuracy stats
    logger.log(`Tracked pattern ${patternId} performance: ${wasSuccessful}`, 'CandleAnalysis');
  }

  /**
   * Get current patterns for a symbol
   * @param {string} symbol 
   * @returns {PatternDetectionResult[]}
   */
  getCurrentPatterns(symbol) {
    return this.currentPatterns.get(symbol) || [];
  }

  /**
   * Get all historical patterns
   * @returns {HistoricalPattern[]}
   */
  getAllHistoricalPatterns() {
    return this.historicalPatterns;
  }
}

// Singleton instance
export const candleAnalysisService = new CandleAnalysisService();

// ===== Type Definitions =====

/**
 * @typedef {Object} Candle
 * @property {number} open
 * @property {number} high
 * @property {number} low
 * @property {number} close
 * @property {number} [volume]
 * @property {string} [timestamp]
 */

/**
 * @typedef {Object} PatternDetection
 * @property {boolean} detected
 * @property {'bullish'|'bearish'} [direction]
 * @property {number} [confidence] - Between 0 and 1
 * @property {number|number[]} [candleIndexes]
 * @property {any} [metadata] - Pattern-specific data
 */

/**
 * @typedef {Object} PatternDetectionResult
 * @property {string} patternId
 * @property {string} name
 * @property {'single'|'multi'|'contextual'} type
 * @property {number|number[]} candleIndexes
 * @property {'bullish'|'bearish'} direction
 * @property {number} confidence
 * @property {'low'|'medium'|'high'} complexity
 * @property {string} timeframe
 */

/**
 * @typedef {Object} ProbabilityAssessment
 * @property {string} patternId
 * @property {string} name
 * @property {number} baseProbability
 * @property {number} finalProbability
 * @property {Object} factors
 * @property {number} factors.context
 * @property {number} factors.timeframe
 * @property {number} factors.volume
 */

/**
 * @typedef {Object} TradeSignal
 * @property {'bullish'|'bearish'} direction
 * @property {string} patternId
 * @property {string} patternName
 * @property {number} confidence - Between 0 and 1
 * @property {string} suggestedAction
 * @property {string[]} conflictingPatterns
 */

/**
 * @typedef {Object} PatternAnalysisResult
 * @property {PatternDetectionResult[]} patterns
 * @property {ProbabilityAssessment[]} probabilities
 * @property {TradeSignal[]} signals
 * @property {string} timestamp
 */

/**
 * @typedef {Object} HistoricalPattern
 * @property {string} patternId
 * @property {string} symbol
 * @property {string} timeframe
 * @property {string} timestamp
 * @property {boolean} wasSuccessful
 * @property {number} profitImpact
 */