// services/dataNormalizer.js
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { calculateRSI } from '../utils/tradingMath';

/**
 * Normalizes market data from different providers to a common format
 * @param {Object} rawData - Raw API response data
 * @param {string} provider - API provider name
 * @returns {Object} Normalized market data
 */
export const normalizeMarketData = (rawData, provider) => {
  try {
    const normalizer = providerNormalizers[provider] || defaultNormalizer;
    const normalized = normalizer(rawData);
    
    // Add calculated technical indicators
    normalized.technical = {
      rsi: calculateRSI(normalized.history),
      // Other indicators will be added by the AI processor
    };
    
    return normalized;
  } catch (error) {
    logger.error(`Normalization failed for ${provider}: ${error.message}`, 'Normalizer');
    throw new Error(`Data normalization error: ${error.message}`);
  }
};

/**
 * Default normalizer for unknown API formats
 */
const defaultNormalizer = (data) => {
  return {
    symbol: data.symbol || 'N/A',
    price: parseFloat(data.price) || 0,
    bid: parseFloat(data.bid) || 0,
    ask: parseFloat(data.ask) || 0,
    high: parseFloat(data.high) || 0,
    low: parseFloat(data.low) || 0,
    volume: parseFloat(data.volume) || 0,
    timestamp: data.timestamp || new Date().toISOString(),
    history: data.history || [],
    spread: parseFloat(data.spread) || 0,
    change: parseFloat(data.change) || 0,
    changePercent: parseFloat(data.changePercent) || 0
  };
};

/**
 * Normalizer for TradingView API format
 */
const tradingViewNormalizer = (data) => {
  const mainSeries = data.series[0] || {};
  return {
    symbol: mainSeries.symbol || 'N/A',
    price: parseFloat(mainSeries.price) || 0,
    bid: parseFloat(mainSeries.bid) || 0,
    ask: parseFloat(mainSeries.ask) || 0,
    high: parseFloat(mainSeries.high) || 0,
    low: parseFloat(mainSeries.low) || 0,
    volume: parseFloat(mainSeries.volume) || 0,
    timestamp: mainSeries.timestamp || new Date().toISOString(),
    history: mainSeries.history || [],
    spread: Math.abs((parseFloat(mainSeries.ask) - parseFloat(mainSeries.bid)) || 0),
    change: parseFloat(mainSeries.change) || 0,
    changePercent: parseFloat(mainSeries.changePercent) || 0
  };
};

/**
 * Normalizer for OANDA API format
 */
const oandaNormalizer = (data) => {
  const candle = data.candles[0] || {};
  return {
    symbol: data.instrument,
    price: parseFloat(candle.mid?.c) || 0,
    bid: parseFloat(candle.bid?.c) || 0,
    ask: parseFloat(candle.ask?.c) || 0,
    high: parseFloat(candle.mid?.h) || 0,
    low: parseFloat(candle.mid?.l) || 0,
    volume: parseFloat(candle.volume) || 0,
    timestamp: candle.time || new Date().toISOString(),
    history: data.candles.map(c => ({
      open: parseFloat(c.mid?.o),
      high: parseFloat(c.mid?.h),
      low: parseFloat(c.mid?.l),
      close: parseFloat(c.mid?.c),
      volume: parseFloat(c.volume),
      time: c.time
    })),
    spread: Math.abs((parseFloat(candle.ask?.c) - parseFloat(candle.bid?.c)) || 0),
    change: parseFloat(data.change) || 0,
    changePercent: parseFloat(data.changePercent) || 0
  };
};

/**
 * Normalizer for Alpha Vantage API format
 */
const alphaVantageNormalizer = (data) => {
  const lastRefreshed = data['Meta Data']['3. Last Refreshed'];
  const timeSeries = data['Time Series (5min)'][lastRefreshed];
  
  return {
    symbol: data['Meta Data']['2. Symbol'],
    price: parseFloat(timeSeries['4. close']) || 0,
    bid: parseFloat(timeSeries['4. close']) * 0.999 || 0,
    ask: parseFloat(timeSeries['4. close']) * 1.001 || 0,
    high: parseFloat(timeSeries['2. high']) || 0,
    low: parseFloat(timeSeries['3. low']) || 0,
    volume: parseFloat(timeSeries['5. volume']) || 0,
    timestamp: lastRefreshed,
    history: Object.entries(data['Time Series (5min)']).map(([time, values]) => ({
      time,
      open: parseFloat(values['1. open']),
      high: parseFloat(values['2. high']),
      low: parseFloat(values['3. low']),
      close: parseFloat(values['4. close']),
      volume: parseFloat(values['5. volume'])
    })),
    spread: (parseFloat(timeSeries['4. close']) * 0.002) || 0,
    change: 0, // Will be calculated later
    changePercent: 0 // Will be calculated later
  };
};

/**
 * Normalizer for news data
 */
export const normalizeNewsData = (rawNews) => {
  return rawNews.map(item => ({
    id: item.id || Math.random().toString(36).substring(7),
    title: item.title,
    source: item.source?.name || 'Unknown',
    url: item.url,
    publishedAt: item.publishedAt || new Date().toISOString(),
    content: item.content || item.description,
    sentiment: item.sentiment || 0, // -1 to 1 scale
    impact: item.impact || 'medium', // low, medium, high
    tags: item.tags || []
  }));
};

// Provider-specific normalizers
const providerNormalizers = {
  'tradingview': tradingViewNormalizer,
  'oanda': oandaNormalizer,
  'alphavantage': alphaVantageNormalizer,
  'default': defaultNormalizer
};

export { normalizeMarketData, normalizeNewsData };
