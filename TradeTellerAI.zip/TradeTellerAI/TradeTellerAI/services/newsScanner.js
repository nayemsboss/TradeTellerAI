// services/newsScanner.js
import { fetchNewsSentiment } from './apiFetcher';
import { normalizeNewsData } from './dataNormalizer';
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { analyzeSentiment } from '../ai/sentimentAnalysis';

/**
 * Scans and analyzes news for market impact
 */
export class NewsScanner {
  constructor() {
    this.cache = new Map();
    this.activeSymbols = new Set();
    this.sentimentThresholds = config.SENTIMENT_THRESHOLDS;
  }

  /**
   * Initialize scanner for specific symbols
   * @param {string[]} symbols - Array of trading symbols to monitor
   */
  async initialize(symbols) {
    this.activeSymbols = new Set(symbols);
    await this.refreshAll();
    logger.log(`NewsScanner initialized for ${symbols.join(', ')}`, 'News');
  }

  /**
   * Refresh news for all active symbols
   */
  async refreshAll() {
    const promises = Array.from(this.activeSymbols).map(symbol => 
      this.scanNews(symbol)
    );
    await Promise.all(promises);
  }

  /**
   * Scan news for a specific symbol
   * @param {string} symbol - Trading symbol
   * @param {boolean} [forceRefresh=false] - Skip cache
   * @returns {Promise<NewsItem[]>}
   */
  async scanNews(symbol, forceRefresh = false) {
    try {
      if (!forceRefresh && this.cache.has(symbol)) {
        const cached = this.cache.get(symbol);
        if (Date.now() - cached.timestamp < config.NEWS_CACHE_TTL) {
          return cached.data;
        }
      }

      const rawNews = await fetchNewsSentiment(
        this.buildQuery(symbol),
        config.NEWS_LOOKBACK_HOURS
      );

      const normalized = normalizeNewsData(rawNews);
      const analyzed = await this.analyzeNews(normalized);

      this.cache.set(symbol, {
        data: analyzed,
        timestamp: Date.now()
      });

      logger.log(`Scanned ${analyzed.length} news items for ${symbol}`, 'News');
      return analyzed;
    } catch (error) {
      logger.error(`News scan failed for ${symbol}: ${error.message}`, 'News');
      throw error;
    }
  }

  /**
   * Analyze news items with sentiment scoring
   * @param {NewsItem[]} newsItems 
   * @returns {Promise<AnalyzedNewsItem[]>}
   */
  async analyzeNews(newsItems) {
    const results = [];
    
    for (const item of newsItems) {
      try {
        // Use existing sentiment if available, otherwise analyze
        const sentiment = item.sentiment !== undefined ? 
          item.sentiment : 
          await analyzeSentiment(item.content || item.title);

        results.push({
          ...item,
          sentiment,
          impact: this.determineImpact(item, sentiment),
          urgency: this.determineUrgency(item)
        });
      } catch (error) {
        logger.error(`Failed to analyze news item: ${error.message}`, 'News');
      }
    }

    return results.sort((a, b) => 
      new Date(b.publishedAt) - new Date(a.publishedAt)
    );
  }

  /**
   * Build search query for a symbol
   * @param {string} symbol 
   * @returns {string}
   */
  buildQuery(symbol) {
    // Extract base currency from pairs like EUR/USD
    const [base, quote] = symbol.includes('/') ? 
      symbol.split('/') : 
      [symbol, ''];

    return `${base} ${quote} forex OR currency OR trading`;
  }

  /**
   * Determine news impact level
   * @param {NewsItem} item 
   * @param {number} sentiment 
   * @returns {'low'|'medium'|'high'}
   */
  determineImpact(item, sentiment) {
    const sourceWeight = config.NEWS_SOURCE_WEIGHTS[item.source] || 1;
    const absSentiment = Math.abs(sentiment);
    
    if (absSentiment > this.sentimentThresholds.high && sourceWeight > 1.5) {
      return 'high';
    }
    if (absSentiment > this.sentimentThresholds.medium || sourceWeight > 1) {
      return 'medium';
    }
    return 'low';
  }

  /**
   * Determine news urgency
   * @param {NewsItem} item 
   * @returns {'low'|'medium'|'high'|'critical'}
   */
  determineUrgency(item) {
    const ageHours = (Date.now() - new Date(item.publishedAt)) / (1000 * 60 * 60);
    
    if (ageHours < 1) return 'critical';
    if (ageHours < 4) return 'high';
    if (ageHours < 12) return 'medium';
    return 'low';
  }

  /**
   * Get latest news for a symbol
   * @param {string} symbol 
   * @param {number} [limit=5] 
   * @returns {NewsItem[]}
   */
  getLatestNews(symbol, limit = 5) {
    if (!this.cache.has(symbol)) return [];
    return this.cache.get(symbol).data.slice(0, limit);
  }

  /**
   * Get news with minimum impact level
   * @param {string} symbol 
   * @param {'medium'|'high'} minImpact 
   * @returns {NewsItem[]}
   */
  getImpactfulNews(symbol, minImpact = 'medium') {
    if (!this.cache.has(symbol)) return [];
    return this.cache.get(symbol).data.filter(item => 
      this.impactToValue(item.impact) >= this.impactToValue(minImpact)
    );
  }

  /**
   * Convert impact level to numeric value
   * @param {'low'|'medium'|'high'} impact 
   * @returns {number}
   */
  impactToValue(impact) {
    return { low: 1, medium: 2, high: 3 }[impact] || 0;
  }
}

// Type definitions
/**
 * @typedef {Object} NewsItem
 * @property {string} id
 * @property {string} title
 * @property {string} source
 * @property {string} url
 * @property {string} publishedAt
 * @property {string} content
 * @property {number} [sentiment] - Between -1 (negative) and 1 (positive)
 * @property {'low'|'medium'|'high'} [impact]
 * @property {string[]} [tags]
 */

/**
 * @typedef {Object} AnalyzedNewsItem
 * @property {string} id
 * @property {string} title
 * @property {string} source
 * @property {string} url
 * @property {string} publishedAt
 * @property {string} content
 * @property {number} sentiment
 * @property {'low'|'medium'|'high'} impact
 * @property {'low'|'medium'|'high'|'critical'} urgency
 * @property {string[]} [tags]
 */

export const newsScanner = new NewsScanner();