// services/performanceAnalyzer.js
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { 
  calculateWinRate, 
  calculateRiskReward, 
  calculateSharpeRatio,
  calculateDrawdown,
  calculateExpectancy,
  calculateKellyCriterion
} from '../utils/tradingMath';
import { EventEmitter } from 'events';

/**
 * Advanced Trading Performance Analyzer
 */
export class PerformanceAnalyzer extends EventEmitter {
  constructor() {
    super();
    this.metrics = {
      overall: {},
      timeBased: {},
      assetBased: {},
      strategyBased: {},
      psychological: {}
    };
    this.tradeClusters = new Map();
  }

  /**
   * Analyze complete trade history
   * @param {Trade[]} trades 
   * @returns {PerformanceReport}
   */
  analyze(trades) {
    if (!trades || trades.length === 0) {
      logger.warn('No trades provided for analysis', 'PerformanceAnalyzer');
      return null;
    }

    try {
      // Clear previous analysis
      this.resetMetrics();

      // Basic metrics
      this.calculateBasicMetrics(trades);

      // Time-based analysis
      this.analyzeTimeDimensions(trades);

      // Asset-based analysis
      this.analyzeAssetDimensions(trades);

      // Strategy analysis
      this.analyzeStrategyPerformance(trades);

      // Psychological markers
      this.analyzePsychologicalFactors(trades);

      // Advanced clustering
      this.clusterTrades(trades);

      // Emit completion event
      this.emit('analysisComplete', this.metrics);

      return this.getReport();
    } catch (error) {
      logger.error(`Performance analysis failed: ${error.message}`, 'PerformanceAnalyzer');
      this.emit('analysisFailed', error);
      throw error;
    }
  }

  /**
   * Calculate basic performance metrics
   * @param {Trade[]} trades 
   */
  calculateBasicMetrics(trades) {
    const profitableTrades = trades.filter(t => t.profit > 0);
    const losingTrades = trades.filter(t => t.profit <= 0);
    const winRate = calculateWinRate(profitableTrades.length, trades.length);

    this.metrics.overall = {
      totalTrades: trades.length,
      profitableTrades: profitableTrades.length,
      losingTrades: losingTrades.length,
      winRate,
      lossRate: 1 - winRate,
      totalProfit: trades.reduce((sum, t) => sum + t.profit, 0),
      avgProfit: this.calculateAverage(profitableTrades.map(t => t.profit)),
      avgLoss: this.calculateAverage(losingTrades.map(t => Math.abs(t.profit))),
      largestWin: Math.max(...profitableTrades.map(t => t.profit), 0),
      largestLoss: Math.min(...losingTrades.map(t => t.profit), 0),
      profitFactor: this.calculateProfitFactor(profitableTrades, losingTrades),
      expectancy: calculateExpectancy(
        winRate,
        this.calculateAverage(profitableTrades.map(t => t.profit)),
        this.calculateAverage(losingTrades.map(t => Math.abs(t.profit)))
      ),
      kellyCriterion: calculateKellyCriterion(
        winRate,
        this.calculateAverage(profitableTrades.map(t => t.profit)) /
        this.calculateAverage(losingTrades.map(t => Math.abs(t.profit)))
      )
    };

    // Calculate series metrics
    this.metrics.overall.consecutiveWins = this.findMaxConsecutive(trades, true);
    this.metrics.overall.consecutiveLosses = this.findMaxConsecutive(trades, false);
  }

  /**
   * Analyze time-based performance dimensions
   * @param {Trade[]} trades 
   */
  analyzeTimeDimensions(trades) {
    // Daily performance
    const dailyPerformance = this.groupByTimePeriod(trades, 'day');
    const dailyReturns = Object.values(dailyPerformance).map(day => 
      day.reduce((sum, t) => sum + t.profit, 0)
    );

    // Monthly performance
    const monthlyPerformance = this.groupByTimePeriod(trades, 'month');

    this.metrics.timeBased = {
      dailyPerformance,
      monthlyPerformance,
      bestDay: this.findBestPeriod(dailyPerformance),
      worstDay: this.findWorstPeriod(dailyPerformance),
      bestMonth: this.findBestPeriod(monthlyPerformance),
      worstMonth: this.findWorstPeriod(monthlyPerformance),
      sharpeRatio: calculateSharpeRatio(dailyReturns),
      sortinoRatio: this.calculateSortinoRatio(dailyReturns),
      drawdown: calculateDrawdown(dailyReturns),
      timeOfDayAnalysis: this.analyzeTimeOfDay(trades),
      dayOfWeekAnalysis: this.analyzeDayOfWeek(trades)
    };
  }

  /**
   * Analyze asset/security-based performance
   * @param {Trade[]} trades 
   */
  analyzeAssetDimensions(trades) {
    const symbols = [...new Set(trades.map(t => t.symbol))];
    
    this.metrics.assetBased = {
      bySymbol: symbols.reduce((acc, symbol) => {
        const symbolTrades = trades.filter(t => t.symbol === symbol);
        const profitable = symbolTrades.filter(t => t.profit > 0);
        
        acc[symbol] = {
          totalTrades: symbolTrades.length,
          winRate: calculateWinRate(profitable.length, symbolTrades.length),
          avgProfit: this.calculateAverage(profitable.map(t => t.profit)),
          avgLoss: this.calculateAverage(
            symbolTrades.filter(t => t.profit <= 0).map(t => Math.abs(t.profit))
          ),
          profitFactor: this.calculateProfitFactor(profitable, 
            symbolTrades.filter(t => t.profit <= 0)),
          riskReward: calculateRiskReward(
            this.calculateAverage(symbolTrades.map(t => t.takeProfit)),
            this.calculateAverage(symbolTrades.map(t => t.stopLoss))
          )
        };
        return acc;
      }, {}),
      correlationAnalysis: this.analyzeAssetCorrelations(trades),
      volatilityAnalysis: this.analyzeVolatilityImpact(trades)
    };
  }

  /**
   * Analyze strategy performance
   * @param {Trade[]} trades 
   */
  analyzeStrategyPerformance(trades) {
    const strategies = [...new Set(trades.map(t => t.strategy))];
    
    this.metrics.strategyBased = {
      byStrategy: strategies.reduce((acc, strategy) => {
        const stratTrades = trades.filter(t => t.strategy === strategy);
        const profitable = stratTrades.filter(t => t.profit > 0);
        
        acc[strategy] = {
          totalTrades: stratTrades.length,
          winRate: calculateWinRate(profitable.length, stratTrades.length),
          consistency: this.calculateConsistency(stratTrades),
          avgDuration: this.calculateAverage(stratTrades.map(t => t.duration)),
          profitPerMinute: this.calculateProfitPerMinute(stratTrades),
          successByTimeframe: this.analyzeStrategyTimeframes(stratTrades)
        };
        return acc;
      }, {}),
      bestPerformingStrategy: this.findBestStrategy(trades),
      worstPerformingStrategy: this.findWorstStrategy(trades)
    };
  }

  /**
   * Analyze psychological trading patterns
   * @param {Trade[]} trades 
   */
  analyzePsychologicalFactors(trades) {
    this.metrics.psychological = {
      revengeTrading: this.detectRevengeTrading(trades),
      overconfidence: this.detectOverconfidence(trades),
      riskAppetiteChanges: this.analyzeRiskAppetite(trades),
      performanceAfterLoss: this.analyzePostLossPerformance(trades),
      weekendEffect: this.analyzeWeekendEffect(trades)
    };
  }

  /**
   * Cluster trades by similar characteristics
   * @param {Trade[]} trades 
   */
  clusterTrades(trades) {
    this.tradeClusters.set('highWinRate', this.findHighWinRateTrades(trades));
    this.tradeClusters.set('highRRR', this.findHighRiskRewardTrades(trades));
    this.tradeClusters.set('quickWins', this.findQuickWinTrades(trades));
    this.tradeClusters.set('longLosers', this.findLongLosingTrades(trades));
    this.tradeClusters.set('newsImpact', this.findNewsImpactTrades(trades));
  }

  /**
   * Get complete performance report
   * @returns {PerformanceReport}
   */
  getReport() {
    return {
      metrics: this.metrics,
      clusters: Object.fromEntries(this.tradeClusters),
      summary: this.generateSummary(),
      recommendations: this.generateRecommendations()
    };
  }

  /**
   * Reset all metrics
   */
  resetMetrics() {
    this.metrics = {
      overall: {},
      timeBased: {},
      assetBased: {},
      strategyBased: {},
      psychological: {}
    };
    this.tradeClusters.clear();
  }

  // ===== Analysis Helper Methods =====

  /**
   * Group trades by time period
   * @param {Trade[]} trades 
   * @param {'day'|'week'|'month'} period 
   * @returns {Object.<string, Trade[]>}
   */
  groupByTimePeriod(trades, period = 'day') {
    return trades.reduce((acc, trade) => {
      const date = new Date(trade.exitTime);
      let key;
      
      switch (period) {
        case 'day':
          key = date.toISOString().split('T')[0];
          break;
        case 'week':
          const weekNum = this.getWeekNumber(date);
          key = `${date.getFullYear()}-W${weekNum}`;
          break;
        case 'month':
          key = `${date.getFullYear()}-${date.getMonth() + 1}`;
          break;
        default:
          key = date.toISOString().split('T')[0];
      }
      
      if (!acc[key]) acc[key] = [];
      acc[key].push(trade);
      return acc;
    }, {});
  }

  /**
   * Find best performing period
   * @param {Object.<string, Trade[]>} periodData 
   * @returns {PeriodPerformance}
   */
  findBestPeriod(periodData) {
    return this.findExtremePeriod(periodData, 'best');
  }

  /**
   * Find worst performing period
   * @param {Object.<string, Trade[]>} periodData 
   * @returns {PeriodPerformance}
   */
  findWorstPeriod(periodData) {
    return this.findExtremePeriod(periodData, 'worst');
  }

  /**
   * Find extreme period (best/worst)
   * @param {Object.<string, Trade[]>} periodData 
   * @param {'best'|'worst'} type 
   * @returns {PeriodPerformance}
   */
  findExtremePeriod(periodData, type = 'best') {
    let extremeValue = type === 'best' ? -Infinity : Infinity;
    let extremePeriod = null;
    
    for (const [period, trades] of Object.entries(periodData)) {
      const totalProfit = trades.reduce((sum, t) => sum + t.profit, 0);
      
      if (
        (type === 'best' && totalProfit > extremeValue) ||
        (type === 'worst' && totalProfit < extremeValue)
      ) {
        extremeValue = totalProfit;
        extremePeriod = {
          period,
          totalProfit,
          trades: trades.length,
          winRate: calculateWinRate(
            trades.filter(t => t.profit > 0).length,
            trades.length
          )
        };
      }
    }
    
    return extremePeriod;
  }

  /**
   * Calculate Sortino ratio
   * @param {number[]} returns 
   * @returns {number}
   */
  calculateSortinoRatio(returns) {
    if (returns.length < 2) return 0;
    
    const avgReturn = this.calculateAverage(returns);
    const downsideReturns = returns.filter(r => r < 0);
    
    if (downsideReturns.length === 0) return Infinity;
    
    const downsideDeviation = Math.sqrt(
      downsideReturns.reduce((sum, ret) => sum + Math.pow(ret, 2), 0) / 
      downsideReturns.length
    );
    
    return downsideDeviation !== 0 ? avgReturn / downsideDeviation : 0;
  }

  /**
   * Analyze performance by time of day
   * @param {Trade[]} trades 
   * @returns {TimeOfDayAnalysis}
   */
  analyzeTimeOfDay(trades) {
    const timeSlots = {
      '00:00-04:00': { trades: [], label: 'Late Night' },
      '04:00-08:00': { trades: [], label: 'Early Morning' },
      '08:00-12:00': { trades: [], label: 'Morning' },
      '12:00-16:00': { trades: [], label: 'Afternoon' },
      '16:00-20:00': { trades: [], label: 'Evening' },
      '20:00-00:00': { trades: [], label: 'Night' }
    };
    
    // Group trades by time slots
    for (const trade of trades) {
      const hour = new Date(trade.entryTime).getHours();
      
      if (hour >= 0 && hour < 4) timeSlots['00:00-04:00'].trades.push(trade);
      else if (hour >= 4 && hour < 8) timeSlots['04:00-08:00'].trades.push(trade);
      else if (hour >= 8 && hour < 12) timeSlots['08:00-12:00'].trades.push(trade);
      else if (hour >= 12 && hour < 16) timeSlots['12:00-16:00'].trades.push(trade);
      else if (hour >= 16 && hour < 20) timeSlots['16:00-20:00'].trades.push(trade);
      else timeSlots['20:00-00:00'].trades.push(trade);
    }
    
    // Calculate metrics for each slot
    return Object.entries(timeSlots).reduce((acc, [slot, data]) => {
      const profitable = data.trades.filter(t => t.profit > 0);
      
      acc[slot] = {
        label: data.label,
        totalTrades: data.trades.length,
        winRate: calculateWinRate(profitable.length, data.trades.length),
        avgProfit: this.calculateAverage(data.trades.map(t => t.profit)),
        profitPerMinute: this.calculateProfitPerMinute(data.trades)
      };
      return acc;
    }, {});
  }

  /**
   * Analyze performance by day of week
   * @param {Trade[]} trades 
   * @returns {DayOfWeekAnalysis}
   */
  analyzeDayOfWeek(trades) {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    
    return trades.reduce((acc, trade) => {
      const dayIndex = new Date(trade.entryTime).getDay();
      const dayName = days[dayIndex];
      
      if (!acc[dayName]) {
        acc[dayName] = {
          trades: [],
          dayIndex
        };
      }
      
      acc[dayName].trades.push(trade);
      return acc;
    }, {});
  }

  /**
   * Analyze correlations between assets
   * @param {Trade[]} trades 
   * @returns {CorrelationAnalysis}
   */
  analyzeAssetCorrelations(trades) {
    const symbols = [...new Set(trades.map(t => t.symbol))];
    const correlationMatrix = {};
    
    // Initialize matrix
    for (const sym1 of symbols) {
      correlationMatrix[sym1] = {};
      for (const sym2 of symbols) {
        correlationMatrix[sym1][sym2] = 0;
      }
    }
    
    // Simple correlation based on win/loss patterns
    for (const sym1 of symbols) {
      const sym1Trades = trades.filter(t => t.symbol === sym1);
      const sym1Results = sym1Trades.map(t => t.profit > 0 ? 1 : -1);
      
      for (const sym2 of symbols) {
        if (sym1 === sym2) {
          correlationMatrix[sym1][sym2] = 1;
          continue;
        }
        
        const sym2Trades = trades.filter(t => t.symbol === sym2);
        const sym2Results = sym2Trades.map(t => t.profit > 0 ? 1 : -1);
        
        // Simple correlation calculation
        const minLength = Math.min(sym1Results.length, sym2Results.length);
        if (minLength > 0) {
          let sum = 0;
          for (let i = 0; i < minLength; i++) {
            sum += sym1Results[i] * sym2Results[i];
          }
          correlationMatrix[sym1][sym2] = sum / minLength;
        }
      }
    }
    
    return correlationMatrix;
  }

  /**
   * Analyze impact of volatility on performance
   * @param {Trade[]} trades 
   * @returns {VolatilityAnalysis}
   */
  analyzeVolatilityImpact(trades) {
    // Placeholder - would integrate with market volatility data
    return {
      highVolatilityTrades: trades.filter(t => t.tags?.includes('high-volatility')),
      lowVolatilityTrades: trades.filter(t => t.tags?.includes('low-volatility')),
      performanceComparison: {
        highVolatilityWinRate: calculateWinRate(
          trades.filter(t => t.tags?.includes('high-volatility') && t.profit > 0).length,
          trades.filter(t => t.tags?.includes('high-volatility')).length
        ),
        lowVolatilityWinRate: calculateWinRate(
          trades.filter(t => t.tags?.includes('low-volatility') && t.profit > 0).length,
          trades.filter(t => t.tags?.includes('low-volatility')).length
        )
      }
    };
  }

  /**
   * Calculate strategy consistency
   * @param {Trade[]} trades 
   * @returns {number}
   */
  calculateConsistency(trades) {
    if (trades.length < 3) return 0;
    
    const results = trades.map(t => t.profit);
    const mean = this.calculateAverage(results);
    const stdDev = Math.sqrt(
      results.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / 
      results.length
    );
    
    return stdDev !== 0 ? mean / stdDev : 0;
  }

  /**
   * Calculate profit per minute
   * @param {Trade[]} trades 
   * @returns {number}
   */
  calculateProfitPerMinute(trades) {
    if (trades.length === 0) return 0;
    
    const totalProfit = trades.reduce((sum, t) => sum + t.profit, 0);
    const totalMinutes = trades.reduce((sum, t) => sum + (t.duration || 1), 0);
    
    return totalProfit / totalMinutes;
  }

  /**
   * Analyze strategy performance across timeframes
   * @param {Trade[]} trades 
   * @returns {Object.<string, StrategyTimeframePerformance>}
   */
  analyzeStrategyTimeframes(trades) {
    const timeframes = [...new Set(trades.map(t => t.timeframe))];
    
    return timeframes.reduce((acc, tf) => {
      const tfTrades = trades.filter(t => t.timeframe === tf);
      const profitable = tfTrades.filter(t => t.profit > 0);
      
      acc[tf] = {
        totalTrades: tfTrades.length,
        winRate: calculateWinRate(profitable.length, tfTrades.length),
        avgProfit: this.calculateAverage(tfTrades.map(t => t.profit)),
        profitFactor: this.calculateProfitFactor(
          profitable,
          tfTrades.filter(t => t.profit <= 0)
        )
      };
      return acc;
    }, {});
  }

  /**
   * Find best performing strategy
   * @param {Trade[]} trades 
   * @returns {string|null}
   */
  findBestStrategy(trades) {
    const strategies = [...new Set(trades.map(t => t.strategy))];
    if (strategies.length === 0) return null;
    
    return strategies.reduce((best, strategy) => {
      const stratTrades = trades.filter(t => t.strategy === strategy);
      const currentWinRate = calculateWinRate(
        stratTrades.filter(t => t.profit > 0).length,
        stratTrades.length
      );
      
      const bestTrades = trades.filter(t => t.strategy === best);
      const bestWinRate = calculateWinRate(
        bestTrades.filter(t => t.profit > 0).length,
        bestTrades.length
      );
      
      return currentWinRate > bestWinRate ? strategy : best;
    }, strategies[0]);
  }

  /**
   * Find worst performing strategy
   * @param {Trade[]} trades 
   * @returns {string|null}
   */
  findWorstStrategy(trades) {
    const strategies = [...new Set(trades.map(t => t.strategy))];
    if (strategies.length === 0) return null;
    
    return strategies.reduce((worst, strategy) => {
      const stratTrades = trades.filter(t => t.strategy === strategy);
      const currentWinRate = calculateWinRate(
        stratTrades.filter(t => t.profit > 0).length,
        stratTrades.length
      );
      
      const worstTrades = trades.filter(t => t.strategy === worst);
      const worstWinRate = calculateWinRate(
        worstTrades.filter(t => t.profit > 0).length,
        worstTrades.length
      );
      
      return currentWinRate < worstWinRate ? strategy : worst;
    }, strategies[0]);
  }

  /**
   * Detect revenge trading patterns
   * @param {Trade[]} trades 
   * @returns {RevengeTradingAnalysis}
   */
  detectRevengeTrading(trades) {
    const losingStreaks = [];
    let currentStreak = [];
    
    for (const trade of trades) {
      if (trade.profit <= 0) {
        currentStreak.push(trade);
      } else if (currentStreak.length > 0) {
        losingStreaks.push([...currentStreak]);
        currentStreak = [];
      }
    }
    
    // Analyze losing streaks for revenge patterns
    return losingStreaks.map(streak => ({
      startTime: streak[0].entryTime,
      endTime: streak[streak.length - 1].exitTime,
      durationMinutes: streak.reduce((sum, t) => sum + (t.duration || 0), 0),
      totalLoss: streak.reduce((sum, t) => sum + t.profit, 0),
      avgTimeBetweenTrades: this.calculateAverage
    }));
  }

  /**
   * Detect overconfidence patterns
   * @param {Trade[]} trades 
   * @returns {OverconfidenceAnalysis}
   */
  detectOverconfidence(trades) {
    const winStreaks = [];
    let currentStreak = [];
    
    for (const trade of trades) {
      if (trade.profit > 0) {
        currentStreak.push(trade);
      } else if (currentStreak.length > 0) {
        winStreaks.push([...currentStreak]);
        currentStreak = [];
      }
    }
    
    // Analyze winning streaks for overconfidence
    return winStreaks.map(streak => ({
      startTime: streak[0].entryTime,
      endTime: streak[streak.length - 1].exitTime,
      durationMinutes: streak.reduce((sum, t) => sum + (t.duration || 0), 0),
      totalProfit: streak.reduce((sum, t) => sum + t.profit, 0),
      riskIncrease: streak.length > 1 ? 
        streak[streak.length - 1].size * Math.abs(streak[streak.length - 1].stopLoss) / 
        (streak[0].size * Math.abs(streak[0].stopLoss)) : 1
    }));
  }

  /**
   * Analyze changes in risk appetite
   * @param {Trade[]} trades 
   * @returns {RiskAppetiteAnalysis}
   */
  analyzeRiskAppetite(trades) {
    if (trades.length < 2) return {};
    
    const riskScores = trades.map(t => 
      t.size * Math.abs(t.stopLoss) / (t.entryPrice || 1)
    );
    
    return {
      initialRisk: riskScores[0],
      finalRisk: riskScores[riskScores.length - 1],
      avgRisk: this.calculateAverage(riskScores),
      maxRisk: Math.max(...riskScores),
      minRisk: Math.min(...riskScores),
      riskTrend: this.calculateTrend(riskScores)
    };
  }

  /**
   * Analyze performance after losing trades
   * @param {Trade[]} trades 
   * @returns {PostLossAnalysis}
   */
  analyzePostLossPerformance(trades) {
    const postLossTrades = [];
    
    for (let i = 1; i < trades.length; i++) {
      if (trades[i - 1].profit <= 0) {
        postLossTrades.push(trades[i]);
      }
    }
    
    if (postLossTrades.length === 0) return {};
    
    const profitable = postLossTrades.filter(t => t.profit > 0);
    
    return {
      totalTrades: postLossTrades.length,
      winRate: calculateWinRate(profitable.length, postLossTrades.length),
      avgProfit: this.calculateAverage(postLossTrades.map(t => t.profit)),
      comparisonToNormal: this.metrics.overall.winRate ?
        calculateWinRate(profitable.length, postLossTrades.length) / 
        this.metrics.overall.winRate : 1
    };
  }

  /**
   * Analyze weekend effect on trading
   * @param {Trade[]} trades 
   * @returns {WeekendEffectAnalysis}
   */
  analyzeWeekendEffect(trades) {
    const weekdays = [1, 2, 3, 4, 5]; // Monday to Friday
    const weekdayTrades = trades.filter(t => 
      weekdays.includes(new Date(t.entryTime).getDay())
    );
    const weekendTrades = trades.filter(t => 
      !weekdays.includes(new Date(t.entryTime).getDay())
    );
    
    return {
      weekdayTrades: weekdayTrades.length,
      weekendTrades: weekendTrades.length,
      weekdayWinRate: calculateWinRate(
        weekdayTrades.filter(t => t.profit > 0).length,
        weekdayTrades.length
      ),
      weekendWinRate: calculateWinRate(
        weekendTrades.filter(t => t.profit > 0).length,
        weekendTrades.length
      ),
      weekdayProfit: weekdayTrades.reduce((sum, t) => sum + t.profit, 0),
      weekendProfit: weekendTrades.reduce((sum, t) => sum + t.profit, 0)
    };
  }

  // ===== Trade Cluster Methods =====

  /**
   * Find trades with high win rate characteristics
   * @param {Trade[]} trades 
   * @returns {Trade[]}
   */
  findHighWinRateTrades(trades) {
    const strategyWinRates = {};
    
    // Calculate win rates by strategy
    const strategies = [...new Set(trades.map(t => t.strategy))];
    for (const strategy of strategies) {
      const stratTrades = trades.filter(t => t.strategy === strategy);
      strategyWinRates[strategy] = calculateWinRate(
        stratTrades.filter(t => t.profit > 0).length,
        stratTrades.length
      );
    }
    
    // Find strategies with above average win rate
    const avgWinRate = this.metrics.overall.winRate || 0.5;
    const highWinStrategies = Object.entries(strategyWinRates)
      .filter(([_, rate]) => rate > avgWinRate * 1.2)
      .map(([strategy]) => strategy);
    
    return trades.filter(t => 
      highWinStrategies.includes(t.strategy) && 
      t.profit > 0
    );
  }

  /**
   * Find trades with high risk/reward ratio
   * @param {Trade[]} trades 
   * @returns {Trade[]}
   */
  findHighRiskRewardTrades(trades) {
    return trades.filter(t => {
      if (!t.takeProfit || !t.stopLoss) return false;
      const rrRatio = Math.abs(t.takeProfit - t.entryPrice) / 
                     Math.abs(t.entryPrice - t.stopLoss);
      return rrRatio >= 2.0 && t.profit > 0;
    });
  }

  /**
   * Find quick winning trades
   * @param {Trade[]} trades 
   * @returns {Trade[]}
   */
  findQuickWinTrades(trades) {
    return trades.filter(t => 
      t.profit > 0 && 
      t.duration <= 15 && // 15 minutes or less
      (t.profit / t.size) >= (this.metrics.overall.avgProfit || 0)
    );
  }

  /**
   * Find long losing trades
   * @param {Trade[]} trades 
   * @returns {Trade[]}
   */
  findLongLosingTrades(trades) {
    return trades.filter(t => 
      t.profit <= 0 && 
      t.duration >= 240 && // 4 hours or more
      Math.abs(t.profit) >= (this.metrics.overall.avgLoss || 0)
    );
  }

  /**
   * Find trades impacted by news events
   * @param {Trade[]} trades 
   * @returns {Trade[]}
   */
  findNewsImpactTrades(trades) {
    return trades.filter(t => 
      t.tags?.includes('news') || 
      t.notes?.toLowerCase().includes('news')
    );
  }

  // ===== Report Generation Methods =====

  /**
   * Generate performance summary
   * @returns {PerformanceSummary}
   */
  generateSummary() {
    const overall = this.metrics.overall;
    
    return {
      performanceRating: this.calculatePerformanceRating(),
      keyStrength: this.identifyKeyStrength(),
      mainWeakness: this.identifyMainWeakness(),
      bestOpportunity: this.identifyBestOpportunity(),
      riskAssessment: this.assessRisk(),
      consistencyScore: this.calculateConsistencyScore()
    };
  }

  /**
   * Generate trading recommendations
   * @returns {TradingRecommendations}
   */
  generateRecommendations() {
    return {
      recommendedStrategy: this.metrics.strategyBased.bestPerformingStrategy,
      recommendedSymbol: Object.entries(this.metrics.assetBased.bySymbol)
        .sort((a, b) => b[1].winRate - a[1].winRate)
        .map(([symbol]) => symbol)[0],
      recommendedTimeframe: Object.entries(this.metrics.timeBased.dayOfWeekAnalysis)
        .sort((a, b) => 
          calculateWinRate(
            a[1].trades.filter(t => t.profit > 0).length,
            a[1].trades.length
          ) - 
          calculateWinRate(
            b[1].trades.filter(t => t.profit > 0).length,
            b[1].trades.length
          )
        )
        .map(([day]) => day)[0],
      riskAdjustment: this.suggestRiskAdjustment(),
      behavioralAdvice: this.provideBehavioralAdvice()
    };
  }

  /**
   * Calculate overall performance rating (1-10)
   * @returns {number}
   */
  calculatePerformanceRating() {
    const overall = this.metrics.overall;
    if (!overall.winRate) return 5;
    
    const rating = (
      (overall.winRate * 4) +
      (overall.profitFactor * 3) +
      (1 - overall.maxDrawdown) * 2 +
      (overall.kellyCriterion > 0 ? 1 : 0)
    );
    
    return Math.min(10, Math.max(1, Math.round(rating)));
  }

  /**
   * Identify key strength in trading
   * @returns {string}
   */
  identifyKeyStrength() {
    const overall = this.metrics.overall;
    const strategy = this.metrics.strategyBased;
    
    if (overall.winRate > 0.7) return 'High win rate';
    if (overall.profitFactor > 2.0) return 'Excellent risk management';
    if (strategy.bestPerformingStrategy && 
        this.metrics.strategyBased.byStrategy[strategy.bestPerformingStrategy].winRate > 0.8) {
      return `Strong performance with ${strategy.bestPerformingStrategy} strategy`;
    }
    if (this.metrics.timeBased.sharpeRatio > 1.5) return 'Consistent profitability';
    
    return 'Solid overall performance';
  }

  /**
   * Identify main weakness in trading
   * @returns {string}
   */
  identifyMainWeakness() {
    const overall = this.metrics.overall;
    const psych = this.metrics.psychological;
    
    if (overall.winRate < 0.4) return 'Low win rate';
    if (overall.profitFactor < 1.0) return 'Poor risk/reward ratio';
    if (overall.maxDrawdown > 0.3) return 'Large drawdowns';
    if (psych.revengeTrading.length > 2) return 'Revenge trading patterns';
    if (psych.overconfidence.length > 2) return 'Overconfidence after wins';
    
    return 'No significant weaknesses detected';
  }

  /**
   * Identify best opportunity for improvement
   * @returns {string}
   */
  identifyBestOpportunity() {
    const metrics = this.metrics;
    
    if (metrics.psychological.revengeTrading.length > 0) {
      return 'Reduce revenge trading after losses';
    }
    if (metrics.strategyBased.worstPerformingStrategy) {
      return `Improve or avoid ${metrics.strategyBased.worstPerformingStrategy} strategy`;
    }
    if (metrics.timeBased.worstDay) {
      return `Address performance issues on ${metrics.timeBased.worstDay.period}`;
    }
    
    return 'Increase position sizing on best performing strategies';
  }

  /**
   * Assess overall risk profile
   * @returns {string}
   */
  assessRisk() {
    const overall = this.metrics.overall;
    
    if (overall.maxDrawdown > 0.4) return 'High Risk';
    if (overall.maxDrawdown > 0.2) return 'Moderate Risk';
    return 'Low Risk';
  }

  /**
   * Calculate consistency score (0-1)
   * @returns {number}
   */
  calculateConsistencyScore() {
    const overall = this.metrics.overall;
    const timeBased = this.metrics.timeBased;
    
    if (!overall.winRate || !timeBased.sharpeRatio) return 0;
    
    return (
      (0.4 * (1 - overall.maxDrawdown)) +
      (0.3 * Math.min(1, timeBased.sharpeRatio / 2)) +
      (0.3 * (overall.profitFactor > 1 ? 1 : overall.profitFactor))
    );
  }

  /**
   * Suggest risk adjustment
   * @returns {string}
   */
  suggestRiskAdjustment() {
    const overall = this.metrics.overall;
    const kelly = overall.kellyCriterion || 0;
    
    if (kelly > 0.2) return 'Consider increasing position size';
    if (kelly < 0.05) return 'Reduce position size to optimize growth';
    return 'Current risk levels appear appropriate';
  }

  /**
   * Provide behavioral trading advice
   * @returns {string[]}
   */
  provideBehavioralAdvice() {
    const advice = [];
    const psych = this.metrics.psychological;
    
    if (psych.revengeTrading.length > 0) {
      advice.push('Implement cooling-off period after losing trades');
    }
    if (psych.overconfidence.length > 0) {
      advice.push('Set strict rules after winning streaks to prevent over-trading');
    }
    if (psych.performanceAfterLoss.comparisonToNormal < 0.8) {
      advice.push('Practice emotional control exercises after losses');
    }
    if (psych.weekendEffect.weekendWinRate < psych.weekendEffect.weekdayWinRate * 0.7) {
      advice.push('Avoid trading during weekends when performance drops');
    }
    
    if (advice.length === 0) {
      advice.push('Continue current disciplined approach');
    }
    
    return advice;
  }

  // ===== Utility Methods =====

  /**
   * Calculate simple average
   * @param {number[]} values 
   * @returns {number}
   */
  calculateAverage(values) {
    const filtered = values.filter(v => !isNaN(v));
    if (filtered.length === 0) return 0;
    return filtered.reduce((sum, val) => sum + val, 0) / filtered.length;
  }

  /**
   * Calculate profit factor
   * @param {Trade[]} profitableTrades 
   * @param {Trade[]} losingTrades 
   * @returns {number}
   */
  calculateProfitFactor(profitableTrades, losingTrades) {
    const grossProfit = profitableTrades.reduce((sum, t) => sum + t.profit, 0);
    const grossLoss = losingTrades.reduce((sum, t) => sum + Math.abs(t.profit), 0);
    return grossLoss > 0 ? grossProfit / grossLoss : Infinity;
  }

  /**
   * Find max consecutive wins/losses
   * @param {Trade[]} trades 
   * @param {boolean} findWins 
   * @returns {number}
   */
  findMaxConsecutive(trades, findWins = true) {
    let max = 0;
    let current = 0;
    
    for (const trade of trades) {
      if ((findWins && trade.profit > 0) || (!findWins && trade.profit <= 0)) {
        current++;
        max = Math.max(max, current);
      } else {
        current = 0;
      }
    }
    
    return max;
  }

  /**
   * Get ISO week number
   * @param {Date} date 
   * @returns {number}
   */
  getWeekNumber(date) {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() + 3 - (d.getDay() + 6) % 7);
    const week1 = new Date(d.getFullYear(), 0, 4);
    return 1 + Math.round(((d - week1) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
  }

  /**
   * Calculate linear trend from values
   * @param {number[]} values 
   * @returns {number} - Slope of trend line
   */
  calculateTrend(values) {
    if (values.length < 2) return 0;
    
    const x = values.map((_, i) => i);
    const y = values;
    
    const n = x.length;
    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = y.reduce((a, b) => a + b, 0);
    const sumXY = x.map((xi, i) => xi * y[i]).reduce((a, b) => a + b, 0);
    const sumXX = x.map(xi => xi * xi).reduce((a, b) => a + b, 0);
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    return slope;
  }
}

// Singleton instance
export const performanceAnalyzer = new PerformanceAnalyzer();

// ===== Type Definitions =====

/**
 * @typedef {Object} PerformanceReport
 * @property {PerformanceMetrics} metrics
 * @property {Object.<string, Trade[]>} clusters
 * @property {PerformanceSummary} summary
 * @property {TradingRecommendations} recommendations
 */

/**
 * @typedef {Object} PerformanceMetrics
 * @property {OverallMetrics} overall
 * @property {TimeBasedMetrics} timeBased
 * @property {AssetBasedMetrics} assetBased
 * @property {StrategyBasedMetrics} strategyBased
 * @property {PsychologicalMetrics} psychological
 */

/**
 * @typedef {Object} OverallMetrics
 * @property {number} totalTrades
 * @property {number} profitableTrades
 * @property {number} losingTrades
 * @property {number} winRate
 * @property {number} lossRate
 * @property {number} totalProfit
 * @property {number} avgProfit
 * @property {number} avgLoss
 * @property {number} largestWin
 * @property {number} largestLoss
 * @property {number} profitFactor
 * @property {number} expectancy
 * @property {number} kellyCriterion
 * @property {number} consecutiveWins
 * @property {number} consecutiveLosses
 */

/**
 * @typedef {Object} TimeBasedMetrics
 * @property {Object.<string, Trade[]>} dailyPerformance
 * @property {Object.<string, Trade[]>} monthlyPerformance
 * @property {PeriodPerformance} bestDay
 * @property {PeriodPerformance} worstDay
 * @property {PeriodPerformance} bestMonth
 * @property {PeriodPerformance} worstMonth
 * @property {number} sharpeRatio
 * @property {number} sortinoRatio
 * @property {number} drawdown
 * @property {TimeOfDayAnalysis} timeOfDayAnalysis
 * @property {DayOfWeekAnalysis} dayOfWeekAnalysis
 */

/**
 * @typedef {Object} AssetBasedMetrics
 * @property {Object.<string, SymbolMetrics>} bySymbol
 * @property {CorrelationAnalysis} correlationAnalysis
 * @property {VolatilityAnalysis} volatilityAnalysis
 */

/**
 * @typedef {Object} StrategyBasedMetrics
 * @property {Object.<string, StrategyMetrics>} byStrategy
 * @property {string|null} bestPerformingStrategy
 * @property {string|null} worstPerformingStrategy
 */

/**
 * @typedef {Object} PsychologicalMetrics
 * @property {RevengeTradingAnalysis[]} revengeTrading
 * @property {OverconfidenceAnalysis[]} overconfidence
 * @property {RiskAppetiteAnalysis} riskAppetiteChanges
 * @property {PostLossAnalysis} performanceAfterLoss
 * @property {WeekendEffectAnalysis} weekendEffect
 */

/**
 * @typedef {Object} PeriodPerformance
 * @property {string} period
 * @property {number} totalProfit
 * @property {number} trades
 * @property {number} winRate
 */

/**
 * @typedef {Object} TimeOfDayAnalysis
 * @property {string} label
 * @property {number} totalTrades
 * @property {number} winRate
 * @property {number} avgProfit
 * @property {number} profitPerMinute
 */

/**
 * @typedef {Object} DayOfWeekAnalysis
 * @property {Trade[]} trades
 * @property {number} dayIndex
 */

/**
 * @typedef {Object} SymbolMetrics
 * @property {number} totalTrades
 * @property {number} winRate
 * @property {number} avgProfit
 * @property {number} avgLoss
 * @property {number} profitFactor
 * @property {number} riskReward
 */

/**
 * @typedef {Object.<string, Object.<string, number>>} CorrelationAnalysis
 */

/**
 * @typedef {Object} VolatilityAnalysis
 * @property {Trade[]} highVolatilityTrades
 * @property {Trade[]} lowVolatilityTrades
 * @property {Object} performanceComparison
 * @property {number} performanceComparison.highVolatilityWinRate
 * @property {number} performanceComparison.lowVolatilityWinRate
 */

/**
 * @typedef {Object} StrategyMetrics
 * @property {number} totalTrades
 * @property {number} winRate
 * @property {number} consistency
 * @property {number} avgDuration
 * @property {number} profitPerMinute
 * @property {Object.<string, StrategyTimeframePerformance>} successByTimeframe
 */

/**
 * @typedef {Object} StrategyTimeframePerformance
 * @property {number} totalTrades
 * @property {number} winRate
 * @property {number} avgProfit
 * @property {number} profitFactor
 */

/**
 * @typedef {Object} RevengeTradingAnalysis
 * @property {string} startTime
 * @property {string} endTime
 * @property {number} durationMinutes
 * @property {number} totalLoss
 * @property {number} avgTimeBetweenTrades
 * @property {number} sizeIncrease
 */

/**
 * @typedef {Object} OverconfidenceAnalysis
 * @property {string} startTime
 * @property {string} endTime
 * @property {number} durationMinutes
 * @property {number} totalProfit
 * @property {number} riskIncrease
 */

/**
 * @typedef {Object} RiskAppetiteAnalysis
 * @property {number} initialRisk
 * @property {number} finalRisk
 * @property {number} avgRisk
 * @property {number} maxRisk
 * @property {number} minRisk
 * @property {number} riskTrend
 */

/**
 * @typedef {Object} PostLossAnalysis
 * @property {number} totalTrades
 * @property {number} winRate
 * @property {number} avgProfit
 * @property {number} comparisonToNormal
 */

/**
 * @typedef {Object} WeekendEffectAnalysis
 * @property {number} weekdayTrades
 * @property {number} weekendTrades
 * @property {number} weekdayWinRate
 * @property {number} weekendWinRate
 * @property {number} weekdayProfit
 * @property {number} weekendProfit
 */

/**
 * @typedef {Object} PerformanceSummary
 * @property {number} performanceRating
 * @property {string} keyStrength
 * @property {string} mainWeakness
 * @property {string} bestOpportunity
 * @property {string} riskAssessment
 * @property {number} consistencyScore
 */

/**
 * @typedef {Object} TradingRecommendations
 * @property {string} recommendedStrategy
 * @property {string} recommendedSymbol
 * @property {string} recommendedTimeframe
 * @property {string} riskAdjustment
 * @property {string[]} behavioralAdvice
 */

/**
 * @typedef {Object} Trade
 * @property {string} id
 * @property {string} symbol
 * @property {'buy'|'sell'} direction
 * @property {number} entryPrice
 * @property {number} exitPrice
 * @property {number} size
 * @property {number} profit
 * @property {string} entryTime
 * @property {string} exitTime
 * @property {number} duration
 * @property {string} timeframe
 * @property {string} strategy
 * @property {number} takeProfit
 * @property {number} stopLoss
 * @property {string} [notes]
 * @property {string[]} [tags]
 * @property {string} [screenshot]
 */