// services/riskManager.js
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { tradingMath } from '../utils/tradingMath';
import { dateUtils } from '../utils/dateUtils';
import { ALERT_LEVELS } from './alertSystem';

/**
 * Risk Management System for TradeTellerAI
 * Handles:
 * - Position sizing
 * - Stop-loss calculation
 * - Risk/reward ratio analysis
 * - Volatility assessment
 * - Account risk profiling
 */

// Risk levels
export const RISK_LEVELS = {
  LOW: 'low',
  MODERATE: 'moderate',
  HIGH: 'high',
  EXTREME: 'extreme'
};

// Risk assessment factors
const RISK_FACTORS = {
  VOLATILITY_WEIGHT: 0.4,
  LIQUIDITY_WEIGHT: 0.2,
  LEVERAGE_WEIGHT: 0.2,
  NEWS_IMPACT_WEIGHT: 0.1,
  TIME_WEIGHT: 0.1
};

/**
 * Calculate risk level for a trading opportunity
 * @param {Object} marketData - Current market data
 * @param {Object} positionData - Position details
 * @returns {Object} Risk assessment result
 */
export const calculateRiskLevel = async (marketData, positionData = {}) => {
  try {
    const {
      symbol,
      volatility,
      liquidity,
      spread,
      leverage = 1,
      newsImpact = 0,
      timeOfDay
    } = marketData;

    // Calculate individual risk components
    const volatilityScore = _calculateVolatilityScore(volatility);
    const liquidityScore = _calculateLiquidityScore(liquidity, spread);
    const leverageScore = _calculateLeverageScore(leverage);
    const newsScore = _calculateNewsImpactScore(newsImpact);
    const timeScore = _calculateTimeScore(timeOfDay);

    // Calculate composite risk score (0-100)
    const compositeScore = 
      (volatilityScore * RISK_FACTORS.VOLATILITY_WEIGHT) +
      (liquidityScore * RISK_FACTORS.LIQUIDITY_WEIGHT) +
      (leverageScore * RISK_FACTORS.LEVERAGE_WEIGHT) +
      (newsScore * RISK_FACTORS.NEWS_IMPACT_WEIGHT) +
      (timeScore * RISK_FACTORS.TIME_WEIGHT);

    // Determine risk level
    const riskLevel = _scoreToRiskLevel(compositeScore);

    // Calculate position sizing if position data provided
    let positionSizing = {};
    if (positionData.accountSize && positionData.riskPercentage) {
      positionSizing = calculatePositionSize({
        entryPrice: marketData.price,
        stopLoss: positionData.stopLoss,
        accountSize: positionData.accountSize,
        riskPercentage: positionData.riskPercentage
      });
    }

    const result = {
      symbol,
      riskScore: Math.round(compositeScore * 100) / 100,
      riskLevel,
      components: {
        volatility: volatilityScore,
        liquidity: liquidityScore,
        leverage: leverageScore,
        newsImpact: newsScore,
        time: timeScore
      },
      positionSizing,
      timestamp: dateUtils.getCurrentTimestamp()
    };

    logger.debug(`Risk assessment for ${symbol}:`, result);
    return result;
  } catch (error) {
    logger.error('Risk calculation failed:', error);
    return {
      riskScore: 0,
      riskLevel: RISK_LEVELS.HIGH,
      error: 'Risk calculation failed'
    };
  }
};

/**
 * Calculate optimal position size based on risk parameters
 * @param {Object} params 
 * @param {number} params.entryPrice - Entry price
 * @param {number} params.stopLoss - Stop-loss price
 * @param {number} params.accountSize - Total account size
 * @param {number} params.riskPercentage - Risk percentage (1-100)
 * @returns {Object} Position sizing details
 */
export const calculatePositionSize = ({
  entryPrice,
  stopLoss,
  accountSize,
  riskPercentage
}) => {
  if (!entryPrice || !stopLoss || !accountSize || !riskPercentage) {
    throw new Error('Missing required parameters for position sizing');
  }

  // Validate inputs
  if (riskPercentage > config.risk.maxPercentage) {
    logger.warn(`Risk percentage ${riskPercentage}% exceeds maximum allowed ${config.risk.maxPercentage}%`);
    riskPercentage = config.risk.maxPercentage;
  }

  const priceDistance = Math.abs(entryPrice - stopLoss);
  const riskAmount = (accountSize * riskPercentage) / 100;
  const positionSize = riskAmount / priceDistance;

  return {
    entryPrice,
    stopLoss,
    priceDistance,
    riskAmount,
    positionSize: Math.floor(positionSize * 100) / 100, // Round to 2 decimals
    riskPercentage,
    accountSize
  };
};

/**
 * Calculate dynamic stop-loss level
 * @param {Object} marketData 
 * @param {string} strategy - Trading strategy
 * @returns {number} Recommended stop-loss price
 */
export const calculateDynamicStopLoss = (marketData, strategy = 'standard') => {
  const { price, volatility, atr } = marketData;
  
  switch (strategy) {
    case 'conservative':
      return price * (1 - (volatility * 0.02));
    case 'aggressive':
      return price * (1 - (volatility * 0.01));
    case 'atr':
      return atr ? (price - (atr * 2)) : null;
    default: // standard
      return price * (1 - (volatility * 0.015));
  }
};

/**
 * Calculate risk/reward ratio
 * @param {number} entryPrice 
 * @param {number} stopLoss 
 * @param {number} takeProfit 
 * @returns {number} Risk/reward ratio
 */
export const calculateRiskRewardRatio = (entryPrice, stopLoss, takeProfit) => {
  const risk = Math.abs(entryPrice - stopLoss);
  const reward = Math.abs(takeProfit - entryPrice);
  return reward / risk;
};

// Private helper functions
const _calculateVolatilityScore = (volatility) => {
  // Normalize volatility to 0-1 scale
  return Math.min(volatility / 0.05, 1); // 5% volatility = max score
};

const _calculateLiquidityScore = (liquidity, spread) => {
  // Higher liquidity and lower spread = better score
  const liquidityNorm = Math.min(liquidity / 1000000, 1); // 1M volume = max
  const spreadNorm = 1 - Math.min(spread / 0.0005, 1); // 0.5 pip spread = min
  return (liquidityNorm * 0.7) + (spreadNorm * 0.3);
};

const _calculateLeverageScore = (leverage) => {
  // Lower leverage = better score
  return 1 - Math.min(leverage / 10, 1); // 10x leverage = min score
};

const _calculateNewsImpactScore = (impact) => {
  // Higher news impact = worse score
  return impact; // Assuming impact is already 0-1
};

const _calculateTimeScore = (timeOfDay) => {
  // Higher market activity = worse score (more volatility)
  const hour = new Date().getHours();
  if (hour >= 8 && hour < 12) return 0.8; // London/NY overlap
  if (hour >= 14 && hour < 17) return 0.6; // NY session
  if (hour >= 22 || hour < 4) return 0.3; // Asia session
  return 0.5; // Other times
};

const _scoreToRiskLevel = (score) => {
  if (score >= 0.8) return RISK_LEVELS.EXTREME;
  if (score >= 0.6) return RISK_LEVELS.HIGH;
  if (score >= 0.4) return RISK_LEVELS.MODERATE;
  return RISK_LEVELS.LOW;
};

/**
 * Get recommended maximum risk percentage based on account size and experience
 * @param {number} accountSize 
 * @param {string} experienceLevel - beginner/intermediate/advanced/professional
 * @returns {number} Recommended risk percentage (1-100)
 */
export const getRecommendedRiskPercentage = (accountSize, experienceLevel) => {
  const baseRisk = {
    beginner: 1,
    intermediate: 2,
    advanced: 3,
    professional: 5
  }[experienceLevel] || 1;

  // Adjust based on account size
  if (accountSize < 1000) return Math.min(baseRisk * 1.5, 5);
  if (accountSize < 5000) return baseRisk;
  if (accountSize < 20000) return Math.min(baseRisk * 0.8, 4);
  return Math.min(baseRisk * 0.5, 3);
};