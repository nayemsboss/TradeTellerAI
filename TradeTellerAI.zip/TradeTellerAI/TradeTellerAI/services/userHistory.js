// services/userHistory.js
import { logger } from '../utils/logger';
import { config } from '../constants/config';
import { calculateWinRate, calculateRiskReward } from '../utils/tradingMath';
import { EventEmitter } from 'events';

/**
 * User Trading History and Performance Analysis Service
 */
export class UserHistory extends EventEmitter {
  constructor() {
    super();
    this.history = [];
    this.performanceMetrics = {};
    this.personalizedSettings = {};
    this.initStorage();
  }

  /**
   * Initialize storage and load saved data
   */
  async initStorage() {
    try {
      const savedData = await this.loadFromStorage();
      if (savedData) {
        this.history = savedData.history || [];
        this.performanceMetrics = savedData.metrics || {};
        this.personalizedSettings = savedData.settings || {};
        logger.log('User history loaded from storage', 'UserHistory');
      }
      this.emit('initialized');
    } catch (error) {
      logger.error(`Failed to initialize user history: ${error.message}`, 'UserHistory');
      throw error;
    }
  }

  /**
   * Add a new trade to history
   * @param {Trade} trade 
   * @returns {Promise<void>}
   */
  async addTrade(trade) {
    try {
      // Validate and normalize trade data
      const normalizedTrade = this.normalizeTrade(trade);
      
      // Add to history
      this.history.unshift(normalizedTrade);
      
      // Update performance metrics
      await this.updatePerformanceMetrics();
      
      // Save to persistent storage
      await this.saveToStorage();
      
      logger.log(`Added trade ${trade.id} to history`, 'UserHistory');
      this.emit('tradeAdded', normalizedTrade);
    } catch (error) {
      logger.error(`Failed to add trade: ${error.message}`, 'UserHistory');
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Update performance metrics based on current history
   */
  async updatePerformanceMetrics() {
    const metrics = {
      overall: this.calculateOverallMetrics(),
      bySymbol: this.calculateSymbolMetrics(),
      byTimeframe: this.calculateTimeframeMetrics(),
      byStrategy: this.calculateStrategyMetrics(),
      recentPerformance: this.calculateRecentPerformance(),
      winStreaks: this.calculateWinStreaks()
    };

    this.performanceMetrics = metrics;
    this.updatePersonalizedSettings();
    
    this.emit('metricsUpdated', metrics);
    return metrics;
  }

  /**
   * Calculate overall performance metrics
   * @returns {OverallMetrics}
   */
  calculateOverallMetrics() {
    if (this.history.length === 0) return {};
    
    const profitableTrades = this.history.filter(t => t.profit > 0);
    const losingTrades = this.history.filter(t => t.profit <= 0);
    
    return {
      totalTrades: this.history.length,
      winRate: calculateWinRate(profitableTrades.length, this.history.length),
      avgProfit: this.calculateAverage(this.history.map(t => t.profit)),
      avgLoss: this.calculateAverage(losingTrades.map(t => Math.abs(t.profit))),
      profitFactor: this.calculateProfitFactor(profitableTrades, losingTrades),
      maxDrawdown: this.calculateMaxDrawdown(),
      riskRewardRatio: calculateRiskReward(
        this.calculateAverage(this.history.map(t => t.takeProfit)), 
        this.calculateAverage(this.history.map(t => t.stopLoss))
      ),
      bestTrade: this.findBestTrade(),
      worstTrade: this.findWorstTrade()
    };
  }

  /**
   * Calculate metrics grouped by symbol
   * @returns {Object.<string, SymbolMetrics>}
   */
  calculateSymbolMetrics() {
    const symbols = [...new Set(this.history.map(t => t.symbol))];
    return symbols.reduce((acc, symbol) => {
      const symbolTrades = this.history.filter(t => t.symbol === symbol);
      const profitable = symbolTrades.filter(t => t.profit > 0);
      
      acc[symbol] = {
        totalTrades: symbolTrades.length,
        winRate: calculateWinRate(profitable.length, symbolTrades.length),
        avgProfit: this.calculateAverage(profitable.map(t => t.profit)),
        avgLoss: this.calculateAverage(
          symbolTrades.filter(t => t.profit <= 0).map(t => Math.abs(t.profit))
        ),
        bestTrade: this.findBestTrade(symbol),
        worstTrade: this.findWorstTrade(symbol)
      };
      return acc;
    }, {});
  }

  /**
   * Calculate metrics grouped by timeframe
   * @returns {Object.<string, TimeframeMetrics>}
   */
  calculateTimeframeMetrics() {
    const timeframes = [...new Set(this.history.map(t => t.timeframe))];
    return timeframes.reduce((acc, timeframe) => {
      const tfTrades = this.history.filter(t => t.timeframe === timeframe);
      const profitable = tfTrades.filter(t => t.profit > 0);
      
      acc[timeframe] = {
        totalTrades: tfTrades.length,
        winRate: calculateWinRate(profitable.length, tfTrades.length),
        avgDuration: this.calculateAverage(tfTrades.map(t => t.duration)),
        performanceScore: this.calculateTimeframeScore(timeframe)
      };
      return acc;
    }, {});
  }

  /**
   * Calculate metrics grouped by strategy
   * @returns {Object.<string, StrategyMetrics>}
   */
  calculateStrategyMetrics() {
    const strategies = [...new Set(this.history.map(t => t.strategy))];
    return strategies.reduce((acc, strategy) => {
      const stratTrades = this.history.filter(t => t.strategy === strategy);
      const profitable = stratTrades.filter(t => t.profit > 0);
      
      acc[strategy] = {
        totalTrades: stratTrades.length,
        winRate: calculateWinRate(profitable.length, stratTrades.length),
        consistencyScore: this.calculateStrategyConsistency(strategy),
        avgRiskReward: calculateRiskReward(
          this.calculateAverage(stratTrades.map(t => t.takeProfit)),
          this.calculateAverage(stratTrades.map(t => t.stopLoss))
        )
      };
      return acc;
    }, {});
  }

  /**
   * Calculate recent performance (last 30 days)
   * @returns {RecentPerformance}
   */
  calculateRecentPerformance() {
    const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
    const recentTrades = this.history.filter(t => 
      new Date(t.exitTime) > thirtyDaysAgo
    );
    
    if (recentTrades.length === 0) return {};
    
    const profitable = recentTrades.filter(t => t.profit > 0);
    const dailyReturns = this.calculateDailyReturns(recentTrades);
    
    return {
      totalTrades: recentTrades.length,
      winRate: calculateWinRate(profitable.length, recentTrades.length),
      profitChange: this.calculateProfitChange(recentTrades),
      dailyReturns,
      sharpeRatio: this.calculateSharpeRatio(dailyReturns)
    };
  }

  /**
   * Update personalized trading settings based on performance
   */
  updatePersonalizedSettings() {
    const bestSymbol = this.findBestPerformingSymbol();
    const bestTimeframe = this.findBestPerformingTimeframe();
    const bestStrategy = this.findBestPerformingStrategy();
    
    this.personalizedSettings = {
      recommendedSymbol: bestSymbol,
      recommendedTimeframe: bestTimeframe,
      recommendedStrategy: bestStrategy,
      riskLevel: this.calculateRecommendedRiskLevel(),
      tradeSize: this.calculateRecommendedTradeSize(),
      takeProfitMultiplier: this.calculateTakeProfitMultiplier(),
      stopLossMultiplier: this.calculateStopLossMultiplier()
    };
    
    this.emit('settingsUpdated', this.personalizedSettings);
  }

  /**
   * Find best performing symbol
   * @returns {string|null}
   */
  findBestPerformingSymbol() {
    if (!this.performanceMetrics.bySymbol) return null;
    
    return Object.entries(this.performanceMetrics.bySymbol)
      .sort((a, b) => b[1].winRate - a[1].winRate)
      .map(([symbol]) => symbol)[0] || null;
  }

  /**
   * Find best performing timeframe
   * @returns {string|null}
   */
  findBestPerformingTimeframe() {
    if (!this.performanceMetrics.byTimeframe) return null;
    
    return Object.entries(this.performanceMetrics.byTimeframe)
      .sort((a, b) => b[1].performanceScore - a[1].performanceScore)
      .map(([tf]) => tf)[0] || null;
  }

  /**
   * Find best performing strategy
   * @returns {string|null}
   */
  findBestPerformingStrategy() {
    if (!this.performanceMetrics.byStrategy) return null;
    
    return Object.entries(this.performanceMetrics.byStrategy)
      .sort((a, b) => b[1].consistencyScore - a[1].consistencyScore)
      .map(([strategy]) => strategy)[0] || null;
  }

  /**
   * Calculate recommended risk level (1-5)
   * @returns {number}
   */
  calculateRecommendedRiskLevel() {
    if (!this.performanceMetrics.overall) return 3;
    
    const { winRate, avgProfit, avgLoss } = this.performanceMetrics.overall;
    const riskScore = (winRate * 0.6) + (avgProfit / (avgLoss || 1) * 0.4);
    
    return Math.min(5, Math.max(1, Math.round(riskScore * 5)));
  }

  /**
   * Calculate recommended trade size (% of balance)
   * @returns {number}
   */
  calculateRecommendedTradeSize() {
    const riskLevel = this.personalizedSettings.riskLevel || 
      this.calculateRecommendedRiskLevel();
    
    // Base size (1%) adjusted by risk level (0.5% to 5%)
    return Math.min(5, Math.max(0.5, 1 * (riskLevel * 0.2)));
  }

  /**
   * Calculate take profit multiplier based on performance
   * @returns {number}
   */
  calculateTakeProfitMultiplier() {
    if (!this.performanceMetrics.overall) return 1.5;
    
    const { winRate } = this.performanceMetrics.overall;
    // Higher win rate → lower multiplier (take profits earlier)
    return Math.max(1.2, Math.min(3, 2 - (winRate * 0.02)));
  }

  /**
   * Calculate stop loss multiplier based on performance
   * @returns {number}
   */
  calculateStopLossMultiplier() {
    if (!this.performanceMetrics.overall) return 1.0;
    
    const { winRate } = this.performanceMetrics.overall;
    // Higher win rate → tighter stops
    return Math.max(0.5, Math.min(2, 1.5 - (winRate * 0.01)));
  }

  /**
   * Get personalized trading recommendations
   * @returns {PersonalizedSettings}
   */
  getRecommendations() {
    return this.personalizedSettings;
  }

  /**
   * Get performance metrics
   * @returns {PerformanceMetrics}
   */
  getMetrics() {
    return this.performanceMetrics;
  }

  /**
   * Get complete trading history
   * @param {object} [options]
   * @param {number} [options.limit]
   * @param {string} [options.symbol]
   * @param {string} [options.timeframe]
   * @returns {Trade[]}
   */
  getHistory(options = {}) {
    let history = [...this.history];
    
    if (options.symbol) {
      history = history.filter(t => t.symbol === options.symbol);
    }
    
    if (options.timeframe) {
      history = history.filter(t => t.timeframe === options.timeframe);
    }
    
    if (options.limit) {
      history = history.slice(0, options.limit);
    }
    
    return history;
  }

  /**
   * Load data from persistent storage
   * @returns {Promise<StoredData>}
   */
  async loadFromStorage() {
    try {
      // Using chrome.storage for extension persistence
      return new Promise(resolve => {
        chrome.storage.local.get(['userHistory'], result => {
          resolve(result.userHistory || null);
        });
      });
    } catch (error) {
      logger.error('Failed to load from storage', 'UserHistory');
      return null;
    }
  }

  /**
   * Save data to persistent storage
   * @returns {Promise<void>}
   */
  async saveToStorage() {
    try {
      const data = {
        history: this.history,
        metrics: this.performanceMetrics,
        settings: this.personalizedSettings
      };
      
      return new Promise(resolve => {
        chrome.storage.local.set({ userHistory: data }, () => {
          logger.log('User history saved to storage', 'UserHistory');
          resolve();
        });
      });
    } catch (error) {
      logger.error('Failed to save to storage', 'UserHistory');
    }
  }

  // Helper methods
  normalizeTrade(trade) {
    return {
      id: trade.id || this.generateTradeId(),
      symbol: trade.symbol,
      direction: trade.direction,
      entryPrice: parseFloat(trade.entryPrice),
      exitPrice: parseFloat(trade.exitPrice),
      size: parseFloat(trade.size),
      profit: parseFloat(trade.profit),
      entryTime: trade.entryTime || new Date().toISOString(),
      exitTime: trade.exitTime || new Date().toISOString(),
      duration: this.calculateTradeDuration(trade.entryTime, trade.exitTime),
      timeframe: trade.timeframe || '1h',
      strategy: trade.strategy || 'manual',
      takeProfit: parseFloat(trade.takeProfit) || 0,
      stopLoss: parseFloat(trade.stopLoss) || 0,
      notes: trade.notes || '',
      tags: trade.tags || [],
      screenshot: trade.screenshot || null
    };
  }

  generateTradeId() {
    return `trd_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
  }

  calculateTradeDuration(entryTime, exitTime) {
    const entry = new Date(entryTime);
    const exit = new Date(exitTime || new Date());
    return (exit - entry) / (1000 * 60); // Duration in minutes
  }

  calculateAverage(values) {
    const filtered = values.filter(v => !isNaN(v));
    if (filtered.length === 0) return 0;
    return filtered.reduce((sum, val) => sum + val, 0) / filtered.length;
  }

  calculateProfitFactor(profitableTrades, losingTrades) {
    const grossProfit = profitableTrades.reduce((sum, t) => sum + t.profit, 0);
    const grossLoss = losingTrades.reduce((sum, t) => sum + Math.abs(t.profit), 0);
    return grossLoss > 0 ? grossProfit / grossLoss : Infinity;
  }

  calculateMaxDrawdown() {
    let maxDrawdown = 0;
    let peak = this.history[0]?.profit || 0;
    let trough = peak;
    
    for (const trade of this.history) {
      if (trade.profit > peak) {
        peak = trade.profit;
        trough = peak;
      } else if (trade.profit < trough) {
        trough = trade.profit;
        maxDrawdown = Math.max(maxDrawdown, (peak - trough) / peak);
      }
    }
    
    return maxDrawdown;
  }

  findBestTrade(symbol = null) {
    const trades = symbol ? 
      this.history.filter(t => t.symbol === symbol) : 
      [...this.history];
      
    return trades.length > 0 ? 
      trades.reduce((best, current) => 
        current.profit > best.profit ? current : best
      ) : 
      null;
  }

  findWorstTrade(symbol = null) {
    const trades = symbol ? 
      this.history.filter(t => t.symbol === symbol) : 
      [...this.history];
      
    return trades.length > 0 ? 
      trades.reduce((worst, current) => 
        current.profit < worst.profit ? current : worst
      ) : 
      null;
  }

  calculateTimeframeScore(timeframe) {
    const metrics = this.performanceMetrics.byTimeframe[timeframe];
    if (!metrics) return 0;
    
    return (metrics.winRate * 0.7) + 
           ((1 - metrics.avgDuration / 1440) * 0.3); // Normalize duration (1440 = 1 day)
  }

  calculateStrategyConsistency(strategy) {
    const metrics = this.performanceMetrics.byStrategy[strategy];
    if (!metrics) return 0;
    
    // Combine win rate and risk/reward ratio
    return (metrics.winRate * 0.6) + 
           (Math.min(1, metrics.avgRiskReward / 3) * 0.4);
  }

  calculateDailyReturns(trades) {
    const daily = {};
    
    for (const trade of trades) {
      const date = new Date(trade.exitTime).toDateString();
      if (!daily[date]) daily[date] = 0;
      daily[date] += trade.profit;
    }
    
    return Object.values(daily);
  }

  calculateSharpeRatio(returns) {
    if (returns.length < 2) return 0;
    
    const avgReturn = this.calculateAverage(returns);
    const stdDev = Math.sqrt(
      returns.reduce((sum, ret) => sum + Math.pow(ret - avgReturn, 2), 0) / 
      returns.length
    );
    
    return stdDev !== 0 ? avgReturn / stdDev : 0;
  }

  calculateProfitChange(recentTrades) {
    if (recentTrades.length < 2) return 0;
    
    const half = Math.ceil(recentTrades.length / 2);
    const firstHalf = recentTrades.slice(0, half);
    const secondHalf = recentTrades.slice(half);
    
    const firstProfit = firstHalf.reduce((sum, t) => sum + t.profit, 0);
    const secondProfit = secondHalf.reduce((sum, t) => sum + t.profit, 0);
    
    return firstProfit !== 0 ? 
      ((secondProfit - firstProfit) / Math.abs(firstProfit)) * 100 : 
      0;
  }

  calculateWinStreaks() {
    let currentStreak = 0;
    let maxStreak = 0;
    let streakType = null;
    const streaks = [];
    
    for (const trade of this.history) {
      const isWin = trade.profit > 0;
      
      if (streakType === null) {
        streakType = isWin ? 'win' : 'loss';
        currentStreak = 1;
      } else if (
        (streakType === 'win' && isWin) || 
        (streakType === 'loss' && !isWin)
      ) {
        currentStreak++;
      } else {
        streaks.push({ type: streakType, length: currentStreak });
        maxStreak = Math.max(maxStreak, currentStreak);
        streakType = isWin ? 'win' : 'loss';
        currentStreak = 1;
      }
    }
    
    if (streakType !== null) {
      streaks.push({ type: streakType, length: currentStreak });
      maxStreak = Math.max(maxStreak, currentStreak);
    }
    
    return {
      currentStreak: streaks[0] || null,
      maxStreak,
      streaks
    };
  }
}

// Singleton instance
export const userHistory = new UserHistory();

// Type Definitions
/**
 * @typedef {Object} Trade
 * @property {string} id
 * @property {string} symbol
 * @property {'buy'|'sell'} direction
 * @property {number} entryPrice
 * @property {number} exitPrice
 * @property {number} size
 * @property {number} profit
 * @property {string} entryTime
 * @property {string} exitTime
 * @property {number} duration - Minutes
 * @property {string} timeframe
 * @property {string} strategy
 * @property {number} takeProfit
 * @property {number} stopLoss
 * @property {string} [notes]
 * @property {string[]} [tags]
 * @property {string} [screenshot] - Base64 image
 */

/**
 * @typedef {Object} OverallMetrics
 * @property {number} totalTrades
 * @property {number} winRate - Percentage (0-1)
 * @property {number} avgProfit
 * @property {number} avgLoss
 * @property {number} profitFactor
 * @property {number} maxDrawdown - Percentage (0-1)
 * @property {number} riskRewardRatio
 * @property {Trade} bestTrade
 * @property {Trade} worstTrade
 */

/**
 * @typedef {Object} SymbolMetrics
 * @property {number} totalTrades
 * @property {number} winRate
 * @property {number} avgProfit
 * @property {number} avgLoss
 * @property {Trade} bestTrade
 * @property {Trade} worstTrade
 */

/**
 * @typedef {Object} TimeframeMetrics
 * @property {number} totalTrades
 * @property {number} winRate
 * @property {number} avgDuration - Minutes
 * @property {number} performanceScore - (0-1)
 */

/**
 * @typedef {Object} StrategyMetrics
 * @property {number} totalTrades
 * @property {number} winRate
 * @property {number} consistencyScore - (0-1)
 * @property {number} avgRiskReward
 */

/**
 * @typedef {Object} RecentPerformance
 * @property {number} totalTrades
 * @property {number} winRate
 * @property {number} profitChange - Percentage
 * @property {number[]} dailyReturns
 * @property {number} sharpeRatio
 */

/**
 * @typedef {Object} WinStreaks
 * @property {Object} currentStreak - {type: 'win'|'loss', length: number}
 * @property {number} maxStreak
 * @property {Array} streaks - Array of streak objects
 */

/**
 * @typedef {Object} PerformanceMetrics
 * @property {OverallMetrics} overall
 * @property {Object.<string, SymbolMetrics>} bySymbol
 * @property {Object.<string, TimeframeMetrics>} byTimeframe
 * @property {Object.<string, StrategyMetrics>} byStrategy
 * @property {RecentPerformance} recentPerformance
 * @property {WinStreaks} winStreaks
 */

/**
 * @typedef {Object} PersonalizedSettings
 * @property {string} recommendedSymbol
 * @property {string} recommendedTimeframe
 * @property {string} recommendedStrategy
 * @property {number} riskLevel - (1-5)
 * @property {number} tradeSize - Percentage of balance
 * @property {number} takeProfitMultiplier
 * @property {number} stopLossMultiplier
 */

/**
 * @typedef {Object} StoredData
 * @property {Trade[]} history
 * @property {PerformanceMetrics} metrics
 * @property {PersonalizedSettings} settings
 */

/**
 * @typedef {'initialized'|'tradeAdded'|'metricsUpdated'|'settingsUpdated'|'error'} UserHistoryEvents
 */