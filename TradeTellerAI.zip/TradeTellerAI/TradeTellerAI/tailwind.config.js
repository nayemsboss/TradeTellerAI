const colors = require('tailwindcss/colors');

module.exports = {
  mode: 'jit',
  purge: [
    './popup/**/*.{js,jsx}',
    './ui/**/*.{js,jsx}',
    './content/**/*.js',
    './**/*.html'
  ],
  darkMode: 'class', // or 'media' based on your preference
  theme: {
    extend: {
      colors: {
        // Trading-specific color palette
        'buy': {
          DEFAULT: '#22C55E',
          50: '#F0FDF4',
          100: '#DCFCE7',
          200: '#BBF7D0',
          300: '#86EFAC',
          400: '#4ADE80',
          500: '#22C55E',
          600: '#16A34A',
          700: '#15803D',
          800: '#166534',
          900: '#14532D',
        },
        'sell': {
          DEFAULT: '#EF4444',
          50: '#FEF2F2',
          100: '#FEE2E2',
          200: '#FECACA',
          300: '#FCA5A5',
          400: '#F87171',
          500: '#EF4444',
          600: '#DC2626',
          700: '#B91C1C',
          800: '#991B1B',
          900: '#7F1D1D',
        },
        'hold': {
          DEFAULT: '#3B82F6',
          50: '#EFF6FF',
          100: '#DBEAFE',
          200: '#BFDBFE',
          300: '#93C5FD',
          400: '#60A5FA',
          500: '#3B82F6',
          600: '#2563EB',
          700: '#1D4ED8',
          800: '#1E40AF',
          900: '#1E3A8A',
        },
        'market-up': '#10B981',
        'market-down': '#F43F5E',
        'market-flat': '#64748B',
        'indicator-rsi': '#F59E0B',
        'indicator-macd': '#8B5CF6',
        'indicator-ema': '#EC4899',
        'indicator-sma': '#14B8A6',
        'candle-up': '#22C55E',
        'candle-down': '#EF4444',
        'candle-wick': '#94A3B8',
        'pattern-bullish': 'rgba(34, 197, 94, 0.2)',
        'pattern-bearish': 'rgba(239, 68, 68, 0.2)',
        'alert-high': '#F59E0B',
        'alert-critical': '#DC2626',
        'alert-info': '#3B82F6',
        'bg-chart': '#1E293B',
        'bg-surface': '#1E293B',
        'bg-elevated': '#334155',
      },
      spacing: {
        'chart': '400px',
        'indicator': '80px',
      },
      fontFamily: {
        'inter': ['Inter', 'sans-serif'],
        'roboto': ['Roboto', 'sans-serif'],
        'mono': ['"Fira Code"', 'monospace'],
      },
      boxShadow: {
        'signal-buy': '0 0 0 2px rgba(34, 197, 94, 0.5)',
        'signal-sell': '0 0 0 2px rgba(239, 68, 68, 0.5)',
        'signal-hold': '0 0 0 2px rgba(59, 130, 246, 0.5)',
        'glow-buy': '0 0 10px rgba(34, 197, 94, 0.5)',
        'glow-sell': '0 0 10px rgba(239, 68, 68, 0.5)',
      },
      animation: {
        'pulse-buy': 'pulse-buy 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'pulse-sell': 'pulse-sell 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'flash-buy': 'flash-buy 1s ease-out',
        'flash-sell': 'flash-sell 1s ease-out',
      },
      keyframes: {
        'pulse-buy': {
          '0%, 100%': { opacity: 1 },
          '50%': { opacity: 0.5, boxShadow: '0 0 0 10px rgba(34, 197, 94, 0)' },
        },
        'pulse-sell': {
          '0%, 100%': { opacity: 1 },
          '50%': { opacity: 0.5, boxShadow: '0 0 0 10px rgba(239, 68, 68, 0)' },
        },
        'flash-buy': {
          '0%': { backgroundColor: 'rgba(34, 197, 94, 0.5)' },
          '100%': { backgroundColor: 'transparent' },
        },
        'flash-sell': {
          '0%': { backgroundColor: 'rgba(239, 68, 68, 0.5)' },
          '100%': { backgroundColor: 'transparent' },
        },
      },
      zIndex: {
        'chart': 5,
        'chart-crosshair': 10,
        'chart-tooltip': 20,
        'chart-pattern': 15,
      },
    },
  },
  variants: {
    extend: {
      backgroundColor: ['active', 'disabled'],
      borderColor: ['active', 'disabled'],
      textColor: ['active', 'disabled'],
      opacity: ['disabled'],
      cursor: ['disabled'],
      animation: ['hover', 'group-hover'],
      boxShadow: ['active'],
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
    require('@tailwindcss/aspect-ratio'),
    function({ addUtilities }) {
      addUtilities({
        '.scrollbar-hide': {
          /* IE and Edge */
          '-ms-overflow-style': 'none',
          /* Firefox */
          'scrollbar-width': 'none',
          /* Safari and Chrome */
          '&::-webkit-scrollbar': {
            display: 'none',
          },
        },
        '.trading-card': {
          '@apply bg-surface rounded border border-opacity-10 shadow-sm transition-all': {},
          '&:hover': {
            '@apply shadow-md transform -translate-y-0.5': {},
          },
        },
        '.signal-badge': {
          '@apply px-2 py-1 rounded-full text-xs font-medium inline-flex items-center': {},
          '&-buy': {
            '@apply bg-buy-100 text-buy-800 border border-buy-300': {},
          },
          '&-sell': {
            '@apply bg-sell-100 text-sell-800 border border-sell-300': {},
          },
          '&-hold': {
            '@apply bg-hold-100 text-hold-800 border border-hold-300': {},
          },
        },
      });
    },
  ],
  corePlugins: {
    // Disable preflight to avoid conflicts with Chrome extension styles
    preflight: false,
  },
};