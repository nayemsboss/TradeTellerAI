// ui/dashboard/AIPredictionEngine/DirectionProbability.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as BullishIcon } from '../../../../assets/icons/svg/upArrow.svg';
import { ReactComponent as BearishIcon } from '../../../../assets/icons/svg/downArrow.svg';
import ConfidenceBar from '../../widgets/ConfidenceBar';
import AnimatedArrow from '../../widgets/AnimatedArrow';
import { formatPercentage } from '../../../../utils/tradingMath';
import { useTheme } from '../../../../constants/uiConstants';

/**
 * DirectionProbability component displays AI's directional prediction with confidence
 * @param {Object} props - Component props
 * @param {number} props.probability - Probability percentage (0-100)
 * @param {string} props.direction - 'up' or 'down'
 * @param {string} [props.timeframe] - Prediction timeframe (e.g., 'next 4 hours')
 * @param {boolean} [props.animated] - Whether to show animated elements
 * @param {string} [props.className] - Additional CSS classes
 */
const DirectionProbability = ({ 
  probability, 
  direction, 
  timeframe = 'next 4 hours', 
  animated = true,
  className = '' 
}) => {
  const theme = useTheme();
  const isBullish = direction === 'up';
  const confidenceLevel = Math.floor(probability / 20); // 1-5 scale
  
  // Determine color scheme based on direction and theme
  const colors = {
    bullish: theme === 'dark' ? '#10b981' : '#059669',
    bearish: theme === 'dark' ? '#ef4444' : '#dc2626',
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b' : '#f8fafc'
  };

  return (
    <div className={`direction-probability ${className} ${direction}`}>
      <div className="probability-header">
        <h3 className="title">AI Direction Prediction</h3>
        {timeframe && (
          <span className="timeframe">
            ({timeframe})
          </span>
        )}
      </div>
      
      <div className="probability-display">
        <div className="direction-indicator">
          {isBullish ? (
            <>
              {animated ? (
                <AnimatedArrow 
                  direction="up" 
                  size={48} 
                  color={colors.bullish}
                />
              ) : (
                <BullishIcon 
                  className="direction-icon" 
                  style={{ color: colors.bullish }}
                />
              )}
              <span className="direction-label" style={{ color: colors.bullish }}>
                Bullish
              </span>
            </>
          ) : (
            <>
              {animated ? (
                <AnimatedArrow 
                  direction="down" 
                  size={48} 
                  color={colors.bearish}
                />
              ) : (
                <BearishIcon 
                  className="direction-icon" 
                  style={{ color: colors.bearish }}
                />
              )}
              <span className="direction-label" style={{ color: colors.bearish }}>
                Bearish
              </span>
            </>
          )}
        </div>
        
        <div className="probability-details">
          <div className="probability-value" style={{ color: colors.text }}>
            {formatPercentage(probability / 100)}
          </div>
          
          <ConfidenceBar 
            level={confidenceLevel} 
            color={isBullish ? colors.bullish : colors.bearish}
            className="confidence-indicator"
          />
          
          <div className="probability-description">
            {probability >= 70 ? (
              <strong>Strong {isBullish ? 'buy' : 'sell'} signal</strong>
            ) : probability >= 55 ? (
              <span>Moderate {isBullish ? 'bullish' : 'bearish'} bias</span>
            ) : (
              <span>Slight {isBullish ? 'upward' : 'downward'} tendency</span>
            )}
          </div>
        </div>
      </div>
      
      <div className="probability-footer">
        <span className="updated-time">
          Updated: {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </div>
  );
};

DirectionProbability.propTypes = {
  probability: PropTypes.number.isRequired,
  direction: PropTypes.oneOf(['up', 'down']).isRequired,
  timeframe: PropTypes.string,
  animated: PropTypes.bool,
  className: PropTypes.string
};

export default DirectionProbability;