// ui/dashboard/AIPredictionEngine/ExpectedRange.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { formatCurrency } from '../../../../utils/tradingMath';
import { useTheme } from '../../../../constants/uiConstants';
import GaugeMeter from '../../widgets/GaugeMeter';
import { ReactComponent as RangeIcon } from '../../../../assets/icons/svg/range.svg';
import { ReactComponent as VolatilityIcon } from '../../../../assets/icons/svg/volatility.svg';

/**
 * ExpectedRange component displays AI-predicted price range with volatility indicator
 * @param {Object} props - Component props
 * @param {number} props.low - Predicted low price
 * @param {number} props.high - Predicted high price
 * @param {number} props.current - Current price
 * @param {string} props.timeframe - Prediction timeframe (e.g., 'next 4 hours')
 * @param {number} props.volatility - Volatility index (0-100)
 * @param {string} [props.className] - Additional CSS classes
 */
const ExpectedRange = ({ 
  low, 
  high, 
  current, 
  timeframe, 
  volatility, 
  className = '' 
}) => {
  const theme = useTheme();
  const rangeWidth = ((high - low) / current) * 100;
  const currentPosition = ((current - low) / (high - low)) * 100;
  
  // Determine volatility level
  const volatilityLevel = volatility >= 70 ? 'high' : 
                         volatility >= 40 ? 'medium' : 'low';
  
  // Color scheme based on theme
  const colors = {
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b80' : '#f8fafc80',
    range: theme === 'dark' ? '#3b82f6' : '#2563eb',
    current: theme === 'dark' ? '#f59e0b' : '#d97706',
    highVolatility: theme === 'dark' ? '#ef4444' : '#dc2626',
    mediumVolatility: theme === 'dark' ? '#f59e0b' : '#d97706',
    lowVolatility: theme === 'dark' ? '#10b981' : '#059669'
  };
  
  // Get volatility color based on level
  const volatilityColor = 
    volatilityLevel === 'high' ? colors.highVolatility :
    volatilityLevel === 'medium' ? colors.mediumVolatility : colors.lowVolatility;

  return (
    <div className={`expected-range ${className}`}>
      <div className="range-header">
        <h3 className="title">
          <RangeIcon className="header-icon" />
          Expected Price Range
        </h3>
        <span className="timeframe">
          ({timeframe})
        </span>
      </div>
      
      <div className="range-visualization">
        <div className="range-bar">
          <div 
            className="range-track"
            style={{
              width: `${rangeWidth}%`,
              left: `${Math.max(0, currentPosition - rangeWidth/2)}%`,
              backgroundColor: colors.range
            }}
          />
          <div 
            className="current-price-marker"
            style={{
              left: `${currentPosition}%`,
              backgroundColor: colors.current
            }}
          />
        </div>
        
        <div className="price-labels">
          <span className="price-label low">
            {formatCurrency(low)}
          </span>
          <span className="price-label current">
            Current: {formatCurrency(current)}
          </span>
          <span className="price-label high">
            {formatCurrency(high)}
          </span>
        </div>
      </div>
      
      <div className="range-details">
        <div className="range-metrics">
          <div className="metric">
            <span className="metric-label">Range Width:</span>
            <span className="metric-value">
              {formatCurrency(high - low)} ({((high - low) / current * 100).toFixed(2)}%)
            </span>
          </div>
          
          <div className="metric">
            <span className="metric-label">Current Position:</span>
            <span className="metric-value">
              {currentPosition.toFixed(1)}% of range
            </span>
          </div>
        </div>
        
        <div className="volatility-indicator">
          <div className="volatility-header">
            <VolatilityIcon className="volatility-icon" />
            <span>Volatility:</span>
            <span 
              className={`level ${volatilityLevel}`}
              style={{ color: volatilityColor }}
            >
              {volatilityLevel.toUpperCase()}
            </span>
          </div>
          
          <GaugeMeter 
            value={volatility} 
            color={volatilityColor}
            size="small"
          />
        </div>
      </div>
      
      <div className="range-footer">
        <span className="ai-note">
          AI-calculated range based on technical patterns and market conditions
        </span>
      </div>
    </div>
  );
};

ExpectedRange.propTypes = {
  low: PropTypes.number.isRequired,
  high: PropTypes.number.isRequired,
  current: PropTypes.number.isRequired,
  timeframe: PropTypes.string.isRequired,
  volatility: PropTypes.number.isRequired,
  className: PropTypes.string
};

export default ExpectedRange;