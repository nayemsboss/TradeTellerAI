// ui/dashboard/AIPredictionEngine/KeyDrivers.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as TechnicalIcon } from '../../../../assets/icons/svg/technical.svg';
import { ReactComponent as FundamentalIcon } from '../../../../assets/icons/svg/fundamental.svg';
import { ReactComponent as SentimentIcon } from '../../../../assets/icons/svg/sentiment.svg';
import { ReactComponent as PatternIcon } from '../../../../assets/icons/svg/pattern.svg';
import { useTheme } from '../../../../constants/uiConstants';
import ConfidenceBar from '../../widgets/ConfidenceBar';

const DRIVER_ICONS = {
  technical: <TechnicalIcon />,
  fundamental: <FundamentalIcon />,
  sentiment: <SentimentIcon />,
  pattern: <PatternIcon />
};

const DRIVER_LABELS = {
  technical: 'Technical Indicators',
  fundamental: 'Fundamental Factors',
  sentiment: 'Market Sentiment',
  pattern: 'Price Patterns'
};

/**
 * KeyDrivers component displays the main factors influencing AI predictions
 * @param {Object} props - Component props
 * @param {Array} props.drivers - Array of driver objects
 * @param {string} [props.className] - Additional CSS classes
 */
const KeyDrivers = ({ drivers, className = '' }) => {
  const theme = useTheme();
  
  // Color scheme based on theme
  const colors = {
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b' : '#f8fafc',
    highlight: theme === 'dark' ? '#3b82f6' : '#2563eb'
  };

  return (
    <div className={`key-drivers ${className}`}>
      <h3 className="title">Key Prediction Drivers</h3>
      <p className="subtitle">Main factors influencing current AI signals</p>
      
      <div className="drivers-list">
        {drivers.map((driver, index) => (
          <div key={index} className="driver-card">
            <div className="driver-header">
              <div className="driver-icon">
                {DRIVER_ICONS[driver.type]}
              </div>
              <h4 className="driver-type">
                {DRIVER_LABELS[driver.type]}
              </h4>
              <div className="driver-impact">
                Impact: {driver.impact}/5
              </div>
            </div>
            
            <div className="driver-details">
              <ConfidenceBar 
                level={driver.confidence} 
                color={colors.highlight}
                className="confidence-indicator"
              />
              
              <ul className="driver-factors">
                {driver.factors.map((factor, factorIndex) => (
                  <li key={factorIndex} className="factor">
                    <span className="factor-name">{factor.name}:</span>
                    <span className="factor-value">{factor.value}</span>
                    {factor.direction && (
                      <span className={`factor-direction ${factor.direction}`}>
                        {factor.direction === 'positive' ? '↑' : '↓'}
                      </span>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
      
      <div className="driver-footer">
        <p className="ai-note">
          Drivers weighted by AI model based on current market conditions
        </p>
      </div>
    </div>
  );
};

KeyDrivers.propTypes = {
  drivers: PropTypes.arrayOf(
    PropTypes.shape({
      type: PropTypes.oneOf(['technical', 'fundamental', 'sentiment', 'pattern']).isRequired,
      impact: PropTypes.number.isRequired,
      confidence: PropTypes.number.isRequired,
      factors: PropTypes.arrayOf(
        PropTypes.shape({
          name: PropTypes.string.isRequired,
          value: PropTypes.string.isRequired,
          direction: PropTypes.oneOf(['positive', 'negative', 'neutral'])
        })
      ).isRequired
    })
  ).isRequired,
  className: PropTypes.string
};

// Default example data (can be overridden by props)
KeyDrivers.defaultProps = {
  drivers: [
    {
      type: 'technical',
      impact: 4,
      confidence: 4,
      factors: [
        { name: 'RSI', value: '62', direction: 'positive' },
        { name: 'MACD', value: 'Bullish Crossover', direction: 'positive' },
        { name: 'Volume', value: '+42%', direction: 'positive' }
      ]
    },
    {
      type: 'fundamental',
      impact: 3,
      confidence: 3,
      factors: [
        { name: 'ECB Rate Decision', value: 'Hold', direction: 'neutral' },
        { name: 'US GDP', value: '2.4%', direction: 'positive' }
      ]
    },
    {
      type: 'sentiment',
      impact: 3,
      confidence: 3,
      factors: [
        { name: 'News Sentiment', value: '68% Positive', direction: 'positive' },
        { name: 'Trader Positions', value: '62% Long', direction: 'positive' }
      ]
    },
    {
      type: 'pattern',
      impact: 4,
      confidence: 4,
      factors: [
        { name: 'Candle Pattern', value: 'Bullish Engulfing', direction: 'positive' },
        { name: 'Support Level', value: '1.0920', direction: 'positive' }
      ]
    }
  ]
};

export default KeyDrivers;