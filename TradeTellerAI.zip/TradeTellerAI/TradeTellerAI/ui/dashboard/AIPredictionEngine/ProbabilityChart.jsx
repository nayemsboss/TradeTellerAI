// ui/dashboard/AIPredictionEngine/ProbabilityChart.jsx
import React, { useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { scaleLinear, scaleTime } from 'd3-scale';
import { line, area } from 'd3-shape';
import { axisBottom, axisLeft } from 'd3-axis';
import { select } from 'd3-selection';
import { timeFormat } from 'd3-time-format';
import { useTheme } from '../../../../constants/uiConstants';
import { ReactComponent as ProbabilityIcon } from '../../../../assets/icons/svg/probability.svg';
import { ReactComponent as BullishIcon } from '../../../../assets/icons/svg/upArrow.svg';
import { ReactComponent as BearishIcon } from '../../../../assets/icons/svg/downArrow.svg';

/**
 * ProbabilityChart component visualizes AI prediction probabilities over time
 * @param {Object} props - Component props
 * @param {Array} props.data - Prediction data points
 * @param {string} [props.timeframe] - Chart timeframe
 * @param {string} [props.className] - Additional CSS classes
 */
const ProbabilityChart = ({ data, timeframe = '24h', className = '' }) => {
  const svgRef = useRef(null);
  const tooltipRef = useRef(null);
  const theme = useTheme();
  
  // Chart dimensions and margins
  const margin = { top: 20, right: 30, bottom: 30, left: 40 };
  const width = 600 - margin.left - margin.right;
  const height = 300 - margin.top - margin.bottom;
  
  // Color scheme based on theme
  const colors = {
    bullish: theme === 'dark' ? '#10b981' : '#059669',
    bearish: theme === 'dark' ? '#ef4444' : '#dc2626',
    grid: theme === 'dark' ? '#334155' : '#e2e8f0',
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b80' : '#f8fafc80'
  };

  useEffect(() => {
    if (!data || data.length === 0 || !svgRef.current) return;

    // Parse timestamps
    const parsedData = data.map(d => ({
      ...d,
      timestamp: new Date(d.timestamp),
      bullishProb: d.bullishProbability,
      bearishProb: d.bearishProbability
    }));

    // Set up scales
    const xScale = scaleTime()
      .domain([parsedData[0].timestamp, parsedData[parsedData.length - 1].timestamp])
      .range([0, width]);

    const yScale = scaleLinear()
      .domain([0, 100])
      .range([height, 0]);

    // Create line generators
    const bullishLine = line()
      .x(d => xScale(d.timestamp))
      .y(d => yScale(d.bullishProb));

    const bearishLine = line()
      .x(d => xScale(d.timestamp))
      .y(d => yScale(d.bearishProb));

    // Create area generators
    const bullishArea = area()
      .x(d => xScale(d.timestamp))
      .y0(height)
      .y1(d => yScale(d.bullishProb));

    const bearishArea = area()
      .x(d => xScale(d.timestamp))
      .y0(height)
      .y1(d => yScale(d.bearishProb));

    // Clear previous chart
    const svg = select(svgRef.current);
    svg.selectAll('*').remove();

    // Create chart group
    const chart = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Add grid lines
    chart.append('g')
      .attr('class', 'grid')
      .attr('transform', `translate(0,${height})`)
      .call(axisBottom(xScale)
        .tickSize(-height)
        .tickFormat('')
      )
      .selectAll('line')
      .attr('stroke', colors.grid)
      .attr('stroke-opacity', 0.3);

    chart.append('g')
      .attr('class', 'grid')
      .call(axisLeft(yScale)
        .tickSize(-width)
        .tickFormat('')
      )
      .selectAll('line')
      .attr('stroke', colors.grid)
      .attr('stroke-opacity', 0.3);

    // Add areas
    chart.append('path')
      .datum(parsedData)
      .attr('class', 'bullish-area')
      .attr('d', bullishArea)
      .attr('fill', colors.bullish)
      .attr('fill-opacity', 0.2)
      .attr('stroke', 'none');

    chart.append('path')
      .datum(parsedData)
      .attr('class', 'bearish-area')
      .attr('d', bearishArea)
      .attr('fill', colors.bearish)
      .attr('fill-opacity', 0.2)
      .attr('stroke', 'none');

    // Add lines
    chart.append('path')
      .datum(parsedData)
      .attr('class', 'bullish-line')
      .attr('d', bullishLine)
      .attr('fill', 'none')
      .attr('stroke', colors.bullish)
      .attr('stroke-width', 2);

    chart.append('path')
      .datum(parsedData)
      .attr('class', 'bearish-line')
      .attr('d', bearishLine)
      .attr('fill', 'none')
      .attr('stroke', colors.bearish)
      .attr('stroke-width', 2);

    // Add axes
    chart.append('g')
      .attr('class', 'x-axis')
      .attr('transform', `translate(0,${height})`)
      .callaxisBottom(xScale)
      .selectAll('text')
      .attr('fill', colors.text)
      .style('font-size', '10px');

    chart.append('g')
      .attr('class', 'y-axis')
      .call(axisLeft(yScale).ticks(5))
      .selectAll('text')
      .attr('fill', colors.text)
      .style('font-size', '10px');

    // Add axis labels
    chart.append('text')
      .attr('class', 'y-axis-label')
      .attr('transform', 'rotate(-90)')
      .attr('y', -margin.left)
      .attr('x', -height / 2)
      .attr('dy', '1em')
      .attr('fill', colors.text)
      .style('text-anchor', 'middle')
      .style('font-size', '11px')
      .text('Probability (%)');

    // Add tooltip interaction
    const tooltip = select(tooltipRef.current);
    
    const focus = chart.append('g')
      .attr('class', 'focus')
      .style('display', 'none');

    focus.append('circle')
      .attr('r', 4.5)
      .attr('fill', colors.text);

    focus.append('text')
      .attr('x', 9)
      .attr('dy', '.35em');

    chart.append('rect')
      .attr('class', 'overlay')
      .attr('width', width)
      .attr('height', height)
      .attr('fill', 'none')
      .attr('pointer-events', 'all')
      .on('mouseover', () => {
        focus.style('display', null);
        tooltip.style('display', 'block');
      })
      .on('mouseout', () => {
        focus.style('display', 'none');
        tooltip.style('display', 'none');
      })
      .on('mousemove', (event) => {
        const bisectTime = (array, x) => {
          const date = xScale.invert(x);
          let i = 0;
          let j = array.length;
          while (j - i > 1) {
            const m = Math.floor((i + j) / 2);
            if (array[m].timestamp > date) j = m;
            else i = m;
          }
          return i;
        };

        const x0 = xScale.invert(select(event).mouse(svg.node())[0]);
        const i = bisectTime(parsedData, x0);
        const d0 = parsedData[i];
        
        focus.attr('transform', 
          `translate(${xScale(d0.timestamp)},${yScale(d0.bullishProb)})`);

        tooltip
          .html(`
            <div class="tooltip-time">${timeFormat('%H:%M')(d0.timestamp)}</div>
            <div class="tooltip-row">
              <span class="tooltip-label bullish">Bullish:</span>
              <span class="tooltip-value">${d0.bullishProb.toFixed(1)}%</span>
            </div>
            <div class="tooltip-row">
              <span class="tooltip-label bearish">Bearish:</span>
              <span class="tooltip-value">${d0.bearishProb.toFixed(1)}%</span>
            </div>
          `)
          .style('left', `${event.pageX + 10}px`)
          .style('top', `${event.pageY - 28}px`);
      });

  }, [data, theme]);

  return (
    <div className={`probability-chart ${className}`}>
      <div className="chart-header">
        <ProbabilityIcon className="header-icon" />
        <h3 className="title">Probability Trend</h3>
        <span className="timeframe">
          ({timeframe})
        </span>
      </div>
      
      <div className="chart-container">
        <svg 
          ref={svgRef} 
          width={600} 
          height={300}
          viewBox={`0 0 600 300`}
          preserveAspectRatio="xMidYMid meet"
        />
        
        <div 
          ref={tooltipRef} 
          className="chart-tooltip"
          style={{
            backgroundColor: theme === 'dark' ? '#1e293b' : '#f8fafc',
            borderColor: theme === 'dark' ? '#334155' : '#e2e8f0',
            color: theme === 'dark' ? '#e2e8f0' : '#1e293b'
          }}
        />
      </div>
      
      <div className="chart-legend">
        <div className="legend-item bullish">
          <BullishIcon className="legend-icon" />
          <span className="legend-label">Bullish Probability</span>
        </div>
        <div className="legend-item bearish">
          <BearishIcon className="legend-icon" />
          <span className="legend-label">Bearish Probability</span>
        </div>
      </div>
    </div>
  );
};

ProbabilityChart.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.shape({
      timestamp: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Date)]).isRequired,
      bullishProbability: PropTypes.number.isRequired,
      bearishProbability: PropTypes.number.isRequired
    })
  ).isRequired,
  timeframe: PropTypes.string,
  className: PropTypes.string
};

export default ProbabilityChart;