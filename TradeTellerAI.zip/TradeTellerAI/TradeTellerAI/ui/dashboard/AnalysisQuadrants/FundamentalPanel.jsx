// ui/dashboard/AnalysisQuadrants/FundamentalPanel.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as FundamentalIcon } from '../../../../assets/icons/svg/fundamental.svg';
import { ReactComponent as UpIcon } from '../../../../assets/icons/svg/upArrow.svg';
import { ReactComponent as DownIcon } from '../../../../assets/icons/svg/downArrow.svg';
import { ReactComponent as NeutralIcon } from '../../../../assets/icons/svg/neutral.svg';
import GaugeMeter from '../../widgets/GaugeMeter';
import { useTheme } from '../../../../constants/uiConstants';
import { formatCurrency, formatPercentage, formatNumber } from '../../../../utils/tradingMath';

/**
 * FundamentalPanel component displays fundamental analysis in quadrant format
 * @param {Object} props - Component props
 * @param {Object} props.data - Fundamental analysis data
 * @param {string} [props.timeframe] - Analysis timeframe
 * @param {string} [props.className] - Additional CSS classes
 */
const FundamentalPanel = ({ data, timeframe = 'Current', className = '' }) => {
  const theme = useTheme();

  // Color scheme based on theme
  const colors = {
    positive: theme === 'dark' ? '#10b981' : '#059669',
    negative: theme === 'dark' ? '#ef4444' : '#dc2626',
    neutral: theme === 'dark' ? '#3b82f6' : '#2563eb',
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b' : '#f8fafc',
    grid: theme === 'dark' ? '#334155' : '#e2e8f0'
  };

  // Determine direction indicator
  const getDirectionIcon = (change) => {
    if (change > 0) return <UpIcon style={{ color: colors.positive }} />;
    if (change < 0) return <DownIcon style={{ color: colors.negative }} />;
    return <NeutralIcon style={{ color: colors.neutral }} />;
  };

  // Format change value with color
  const formatChange = (value) => {
    const color = value > 0 ? colors.positive : value < 0 ? colors.negative : colors.neutral;
    return (
      <span style={{ color }}>
        {value > 0 ? '+' : ''}{formatPercentage(value / 100)}
      </span>
    );
  };

  // Format impact level
  const renderImpact = (impact) => {
    const impactLevels = [
      { label: 'Low', color: theme === 'dark' ? '#3b82f6' : '#2563eb' },
      { label: 'Medium', color: theme === 'dark' ? '#f59e0b' : '#d97706' },
      { label: 'High', color: theme === 'dark' ? '#ef4444' : '#dc2626' }
    ];
    
    const level = impactLevels[Math.min(Math.floor(impact), 2)];
    return (
      <span style={{ color: level.color }}>
        {level.label} Impact
      </span>
    );
  };

  return (
    <div 
      className={`fundamental-panel ${className}`}
      style={{
        backgroundColor: colors.background,
        borderColor: colors.grid
      }}
    >
      <div className="panel-header">
        <FundamentalIcon className="panel-icon" />
        <h3 className="panel-title" style={{ color: colors.text }}>
          Fundamental Analysis
        </h3>
        <span className="timeframe" style={{ color: colors.text }}>
          ({timeframe})
        </span>
      </div>

      <div className="quadrants-container">
        {/* Economic Indicators Quadrant */}
        <div 
          className="quadrant economic"
          style={{ borderColor: colors.grid }}
        >
          <h4 className="quadrant-title" style={{ color: colors.text }}>
            Economic Indicators
          </h4>
          <div className="indicators-grid">
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                GDP Growth
              </span>
              <div className="indicator-value">
                {formatPercentage(data.gdpGrowth.value / 100)}
                {getDirectionIcon(data.gdpGrowth.change)}
              </div>
              <div className="indicator-meta" style={{ color: colors.text }}>
                QoQ: {formatChange(data.gdpGrowth.change)}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Inflation Rate
              </span>
              <div className="indicator-value">
                {formatPercentage(data.inflation.value / 100)}
                {getDirectionIcon(data.inflation.change)}
              </div>
              <div className="indicator-meta" style={{ color: colors.text }}>
                {renderImpact(data.inflation.impact)}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Unemployment
              </span>
              <div className="indicator-value">
                {formatPercentage(data.unemployment.value / 100)}
                {getDirectionIcon(-data.unemployment.change)}
              </div>
              <div className="indicator-meta" style={{ color: colors.text }}>
                Trend: {data.unemployment.change < 0 ? 'Improving' : 'Worsening'}
              </div>
            </div>
          </div>
        </div>

        {/* Central Bank Quadrant */}
        <div 
          className="quadrant central-bank"
          style={{ borderColor: colors.grid }}
        >
          <h4 className="quadrant-title" style={{ color: colors.text }}>
            Central Bank
          </h4>
          <div className="indicators-grid">
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Interest Rate
              </span>
              <div className="indicator-value">
                {formatPercentage(data.interestRate.value / 100)}
              </div>
              <div className="indicator-meta" style={{ color: colors.text }}>
                Next Meeting: {new Date(data.interestRate.nextMeeting).toLocaleDateString()}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Policy Stance
              </span>
              <div 
                className="indicator-value" 
                style={{ 
                  color: data.policyStance === 'Hawkish' ? colors.negative : 
                         data.policyStance === 'Dovish' ? colors.positive : colors.neutral
                }}
              >
                {data.policyStance}
              </div>
              <div className="indicator-meta" style={{ color: colors.text }}>
                {data.policyExpectation}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Balance Sheet
              </span>
              <div className="indicator-value">
                {formatCurrency(data.balanceSheet.value)}B
              </div>
              <div className="indicator-meta" style={{ color: colors.text }}>
                {data.balanceSheet.change > 0 ? 'Expanding' : 'Contracting'}
              </div>
            </div>
          </div>
        </div>

        {/* Market Sentiment Quadrant */}
        <div 
          className="quadrant sentiment"
          style={{ borderColor: colors.grid }}
        >
          <h4 className="quadrant-title" style={{ color: colors.text }}>
            Market Sentiment
          </h4>
          <div className="indicators-grid">
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Risk Appetite
              </span>
              <GaugeMeter 
                value={data.riskAppetite} 
                color={data.riskAppetite > 66 ? colors.positive : 
                      data.riskAppetite < 33 ? colors.negative : colors.neutral}
                size="small"
              />
              <div className="indicator-meta" style={{ color: colors.text }}>
                {data.riskAppetite > 66 ? 'Risk On' : 
                 data.riskAppetite < 33 ? 'Risk Off' : 'Neutral'}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Investor Flows
              </span>
              <div className="indicator-value">
                {formatCurrency(data.investorFlows.value)}B
                {getDirectionIcon(data.investorFlows.change)}
              </div>
              <div className="indicator-meta" style={{ color: colors.text }}>
                {data.investorFlows.change > 0 ? 'Inflows' : 'Outflows'}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Volatility Index
              </span>
              <div className="indicator-value">
                {data.volatilityIndex.value.toFixed(2)}
                {getDirectionIcon(-data.volatilityIndex.change)}
              </div>
              <div className="indicator-meta" style={{ color: colors.text }}>
                {data.volatilityIndex.change < 0 ? 'Decreasing' : 'Increasing'}
              </div>
            </div>
          </div>
        </div>

        {/* Sector Performance Quadrant */}
        <div 
          className="quadrant sectors"
          style={{ borderColor: colors.grid }}
        >
          <h4 className="quadrant-title" style={{ color: colors.text }}>
            Sector Performance
          </h4>
          <div className="indicators-grid">
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Top Sector
              </span>
              <div 
                className="indicator-value" 
                style={{ color: colors.positive }}
              >
                {data.topSector.name}
              </div>
              <div className="indicator-meta" style={{ color: colors.text }}>
                {formatPercentage(data.topSector.performance / 100)}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Worst Sector
              </span>
              <div 
                className="indicator-value" 
                style={{ color: colors.negative }}
              >
                {data.worstSector.name}
              </div>
              <div className="indicator-meta" style={{ color: colors.text }}>
                {formatPercentage(data.worstSector.performance / 100)}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Sector Correlation
              </span>
              <div className="indicator-value">
                {data.sectorCorrelation.toFixed(2)}
              </div>
              <div className="indicator-meta" style={{ color: colors.text }}>
                {data.sectorCorrelation > 0.7 ? 'High' : 
                 data.sectorCorrelation < 0.3 ? 'Low' : 'Moderate'}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="panel-footer">
        <span className="composite-score" style={{ color: colors.text }}>
          Fundamental Score: 
          <span style={{ 
            color: data.compositeScore > 70 ? colors.positive : 
                  data.compositeScore < 30 ? colors.negative : colors.neutral
          }}>
            {data.compositeScore}/100
          </span>
        </span>
        <span className="last-updated" style={{ color: colors.text }}>
          Updated: {new Date(data.timestamp).toLocaleString()}
        </span>
      </div>
    </div>
  );
};

FundamentalPanel.propTypes = {
  data: PropTypes.shape({
    // Economic Indicators
    gdpGrowth: PropTypes.shape({
      value: PropTypes.number.isRequired,
      change: PropTypes.number.isRequired
    }).isRequired,
    inflation: PropTypes.shape({
      value: PropTypes.number.isRequired,
      change: PropTypes.number.isRequired,
      impact: PropTypes.number.isRequired
    }).isRequired,
    unemployment: PropTypes.shape({
      value: PropTypes.number.isRequired,
      change: PropTypes.number.isRequired
    }).isRequired,
    
    // Central Bank
    interestRate: PropTypes.shape({
      value: PropTypes.number.isRequired,
      nextMeeting: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired
    }).isRequired,
    policyStance: PropTypes.oneOf(['Hawkish', 'Dovish', 'Neutral']).isRequired,
    policyExpectation: PropTypes.string.isRequired,
    balanceSheet: PropTypes.shape({
      value: PropTypes.number.isRequired,
      change: PropTypes.number.isRequired
    }).isRequired,
    
    // Market Sentiment
    riskAppetite: PropTypes.number.isRequired,
    investorFlows: PropTypes.shape({
      value: PropTypes.number.isRequired,
      change: PropTypes.number.isRequired
    }).isRequired,
    volatilityIndex: PropTypes.shape({
      value: PropTypes.number.isRequired,
      change: PropTypes.number.isRequired
    }).isRequired,
    
    // Sector Performance
    topSector: PropTypes.shape({
      name: PropTypes.string.isRequired,
      performance: PropTypes.number.isRequired
    }).isRequired,
    worstSector: PropTypes.shape({
      name: PropTypes.string.isRequired,
      performance: PropTypes.number.isRequired
    }).isRequired,
    sectorCorrelation: PropTypes.number.isRequired,
    
    // Metadata
    compositeScore: PropTypes.number.isRequired,
    timestamp: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired
  }).isRequired,
  timeframe: PropTypes.string,
  className: PropTypes.string
};

export default FundamentalPanel;