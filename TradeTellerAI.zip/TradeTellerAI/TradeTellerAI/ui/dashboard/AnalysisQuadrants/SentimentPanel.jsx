// ui/dashboard/AnalysisQuadrants/SentimentPanel.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as SentimentIcon } from '../../../../assets/icons/svg/sentiment.svg';
import { ReactComponent as BullishIcon } from '../../../../assets/icons/svg/bullish.svg';
import { ReactComponent as BearishIcon } from '../../../../assets/icons/svg/bearish.svg';
import { ReactComponent as NewsIcon } from '../../../../assets/icons/svg/news.svg';
import { ReactComponent as SocialIcon } from '../../../../assets/icons/svg/social.svg';
import GaugeMeter from '../../widgets/GaugeMeter';
import Heatmap from '../../widgets/Heatmap';
import { useTheme } from '../../../../constants/uiConstants';
import { formatPercentage } from '../../../../utils/tradingMath';

/**
 * SentimentPanel component displays market sentiment analysis
 * @param {Object} props - Component props
 * @param {Object} props.sentiment - Sentiment data object
 * @param {string} [props.timeframe] - Analysis timeframe
 * @param {string} [props.className] - Additional CSS classes
 */
const SentimentPanel = ({ sentiment, timeframe = '24h', className = '' }) => {
  const theme = useTheme();

  // Color scheme based on theme
  const colors = {
    bullish: theme === 'dark' ? '#10b981' : '#059669',
    bearish: theme === 'dark' ? '#ef4444' : '#dc2626',
    neutral: theme === 'dark' ? '#3b82f6' : '#2563eb',
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b' : '#f8fafc',
    grid: theme === 'dark' ? '#334155' : '#e2e8f0'
  };

  // Sentiment direction indicator
  const renderSentimentDirection = (value) => {
    if (value > 55) {
      return (
        <div className="sentiment-direction bullish">
          <BullishIcon style={{ color: colors.bullish }} />
          <span style={{ color: colors.bullish }}>Bullish</span>
        </div>
      );
    }
    if (value < 45) {
      return (
        <div className="sentiment-direction bearish">
          <BearishIcon style={{ color: colors.bearish }} />
          <span style={{ color: colors.bearish }}>Bearish</span>
        </div>
      );
    }
    return (
      <div className="sentiment-direction neutral">
        <span style={{ color: colors.neutral }}>Neutral</span>
      </div>
    );
  };

  // Format sentiment value with color
  const formatSentimentValue = (value) => {
    const color = value > 50 ? colors.bullish : value < 50 ? colors.bearish : colors.neutral;
    return <span style={{ color }}>{value}%</span>;
  };

  return (
    <div 
      className={`sentiment-panel ${className}`}
      style={{
        backgroundColor: colors.background,
        borderColor: colors.grid
      }}
    >
      <div className="panel-header">
        <SentimentIcon className="panel-icon" />
        <h3 className="panel-title" style={{ color: colors.text }}>
          Market Sentiment
        </h3>
        <span className="timeframe" style={{ color: colors.text }}>
          ({timeframe})
        </span>
      </div>

      <div className="quadrants-container">
        {/* Overall Sentiment Quadrant */}
        <div 
          className="quadrant overall"
          style={{ borderColor: colors.grid }}
        >
          <h4 className="quadrant-title" style={{ color: colors.text }}>
            Overall Sentiment
          </h4>
          <div className="sentiment-content">
            <div className="gauge-container">
              <GaugeMeter 
                value={sentiment.overall.score}
                color={sentiment.overall.score > 50 ? colors.bullish : colors.bearish}
                size="medium"
              />
              <div className="sentiment-score">
                {renderSentimentDirection(sentiment.overall.score)}
                <div className="change-indicator" style={{ color: colors.text }}>
                  {sentiment.overall.change > 0 ? '↑' : '↓'} {Math.abs(sentiment.overall.change)}% 
                  <span> from previous period</span>
                </div>
              </div>
            </div>
            <div className="sentiment-stats">
              <div className="stat">
                <span className="label" style={{ color: colors.text }}>Strength:</span>
                <span className="value" style={{ 
                  color: sentiment.overall.strength > 70 ? colors.bullish : 
                         sentiment.overall.strength < 30 ? colors.bearish : colors.neutral
                }}>
                  {sentiment.overall.strength}/100
                </span>
              </div>
              <div className="stat">
                <span className="label" style={{ color: colors.text }}>Consistency:</span>
                <span className="value" style={{ color: colors.text }}>
                  {formatPercentage(sentiment.overall.consistency / 100)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* News Sentiment Quadrant */}
        <div 
          className="quadrant news"
          style={{ borderColor: colors.grid }}
        >
          <h4 className="quadrant-title" style={{ color: colors.text }}>
            <NewsIcon className="quadrant-icon" />
            News Sentiment
          </h4>
          <div className="sentiment-metrics">
            <div className="metric">
              <span className="label" style={{ color: colors.text }}>Headlines:</span>
              {formatSentimentValue(sentiment.news.score)}
            </div>
            <div className="metric">
              <span className="label" style={{ color: colors.text }}>Positive:</span>
              <span style={{ color: colors.bullish }}>
                {formatPercentage(sentiment.news.positive / 100)}
              </span>
            </div>
            <div className="metric">
              <span className="label" style={{ color: colors.text }}>Negative:</span>
              <span style={{ color: colors.bearish }}>
                {formatPercentage(sentiment.news.negative / 100)}
              </span>
            </div>
            <Heatmap 
              data={sentiment.news.sources}
              colors={[colors.bearish, colors.neutral, colors.bullish]}
              className="news-heatmap"
            />
          </div>
        </div>

        {/* Social Media Quadrant */}
        <div 
          className="quadrant social"
          style={{ borderColor: colors.grid }}
        >
          <h4 className="quadrant-title" style={{ color: colors.text }}>
            <SocialIcon className="quadrant-icon" />
            Social Sentiment
          </h4>
          <div className="sentiment-metrics">
            <div className="metric">
              <span className="label" style={{ color: colors.text }}>Twitter:</span>
              {formatSentimentValue(sentiment.social.twitter)}
            </div>
            <div className="metric">
              <span className="label" style={{ color: colors.text }}>Reddit:</span>
              {formatSentimentValue(sentiment.social.reddit)}
            </div>
            <div className="metric">
              <span className="label" style={{ color: colors.text }}>Forums:</span>
              {formatSentimentValue(sentiment.social.forums)}
            </div>
            <div className="metric">
              <span className="label" style={{ color: colors.text }}>Engagement:</span>
              <span style={{ 
                color: sentiment.social.engagement > 70 ? colors.bullish : 
                       sentiment.social.engagement < 30 ? colors.bearish : colors.neutral
              }}>
                {formatPercentage(sentiment.social.engagement / 100)}
              </span>
            </div>
          </div>
        </div>

        {/* Trader Positioning Quadrant */}
        <div 
          className="quadrant positioning"
          style={{ borderColor: colors.grid }}
        >
          <h4 className="quadrant-title" style={{ color: colors.text }}>
            Trader Positioning
          </h4>
          <div className="positioning-content">
            <div className="positioning-chart">
              <div className="long-short-ratio">
                <div 
                  className="long-bar" 
                  style={{
                    width: `${sentiment.positioning.long}%`,
                    backgroundColor: colors.bullish
                  }}
                >
                  <span className="label">Long {sentiment.positioning.long}%</span>
                </div>
                <div 
                  className="short-bar" 
                  style={{
                    width: `${sentiment.positioning.short}%`,
                    backgroundColor: colors.bearish
                  }}
                >
                  <span className="label">Short {sentiment.positioning.short}%</span>
                </div>
              </div>
              <div className="positioning-stats">
                <div className="stat">
                  <span className="label" style={{ color: colors.text }}>Open Interest:</span>
                  <span className="value" style={{ color: colors.text }}>
                    {formatPercentage(sentiment.positioning.openInterestChange / 100)}
                  </span>
                </div>
                <div className="stat">
                  <span className="label" style={{ color: colors.text }}>Liquidation:</span>
                  <span className="value" style={{ 
                    color: sentiment.positioning.liquidationRatio > 1 ? colors.bearish : colors.bullish
                  }}>
                    {sentiment.positioning.liquidationRatio.toFixed(2)}:1
                  </span>
                </div>
              </div>
            </div>
            <div className="sentiment-contrarian">
              <span className="label" style={{ color: colors.text }}>Contrarian Index:</span>
              <span 
                className="value" 
                style={{ 
                  color: sentiment.positioning.contrarianIndex > 70 ? colors.bearish : 
                         sentiment.positioning.contrarianIndex < 30 ? colors.bullish : colors.neutral
                }}
              >
                {sentiment.positioning.contrarianIndex}/100
              </span>
              <div className="hint" style={{ color: colors.text }}>
                {sentiment.positioning.contrarianIndex > 70 ? 
                  'Extreme bullishness may signal reversal' :
                  sentiment.positioning.contrarianIndex < 30 ?
                  'Extreme bearishness may signal reversal' :
                  'Market sentiment in normal range'}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="panel-footer">
        <div className="sentiment-summary">
          <span className="label" style={{ color: colors.text }}>Composite Sentiment:</span>
          <span 
            className="value" 
            style={{ 
              color: sentiment.composite.score > 55 ? colors.bullish : 
                     sentiment.composite.score < 45 ? colors.bearish : colors.neutral
            }}
          >
            {sentiment.composite.score}% ({sentiment.composite.score > 50 ? 'Bullish' : 'Bearish'})
          </span>
        </div>
        <div className="last-updated" style={{ color: colors.text }}>
          Updated: {new Date(sentiment.timestamp).toLocaleTimeString()}
        </div>
      </div>
    </div>
  );
};

SentimentPanel.propTypes = {
  sentiment: PropTypes.shape({
    overall: PropTypes.shape({
      score: PropTypes.number.isRequired,
      change: PropTypes.number.isRequired,
      strength: PropTypes.number.isRequired,
      consistency: PropTypes.number.isRequired
    }).isRequired,
    news: PropTypes.shape({
      score: PropTypes.number.isRequired,
      positive: PropTypes.number.isRequired,
      negative: PropTypes.number.isRequired,
      sources: PropTypes.arrayOf(
        PropTypes.shape({
          name: PropTypes.string.isRequired,
          score: PropTypes.number.isRequired
        })
      ).isRequired
    }).isRequired,
    social: PropTypes.shape({
      twitter: PropTypes.number.isRequired,
      reddit: PropTypes.number.isRequired,
      forums: PropTypes.number.isRequired,
      engagement: PropTypes.number.isRequired
    }).isRequired,
    positioning: PropTypes.shape({
      long: PropTypes.number.isRequired,
      short: PropTypes.number.isRequired,
      openInterestChange: PropTypes.number.isRequired,
      liquidationRatio: PropTypes.number.isRequired,
      contrarianIndex: PropTypes.number.isRequired
    }).isRequired,
    composite: PropTypes.shape({
      score: PropTypes.number.isRequired,
      trend: PropTypes.oneOf(['rising', 'falling', 'steady']).isRequired
    }).isRequired,
    timestamp: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired
  }).isRequired,
  timeframe: PropTypes.string,
  className: PropTypes.string
};

export default SentimentPanel;