// ui/dashboard/AnalysisQuadrants/TechnicalPanel.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as TechnicalIcon } from '../../../../assets/icons/svg/technical.svg';
import { ReactComponent as UpArrowIcon } from '../../../../assets/icons/svg/upArrow.svg';
import { ReactComponent as DownArrowIcon } from '../../../../assets/icons/svg/downArrow.svg';
import GaugeMeter from '../../widgets/GaugeMeter';
import { useTheme } from '../../../../constants/uiConstants';
import { formatPercentage } from '../../../../utils/tradingMath';

/**
 * TechnicalPanel component displays technical indicators in quadrant format
 * @param {Object} props - Component props
 * @param {Object} props.indicators - Technical indicators data
 * @param {string} [props.timeframe] - Analysis timeframe
 * @param {string} [props.className] - Additional CSS classes
 */
const TechnicalPanel = ({ indicators, timeframe = '1H', className = '' }) => {
  const theme = useTheme();

  // Color scheme based on theme
  const colors = {
    bullish: theme === 'dark' ? '#10b981' : '#059669',
    bearish: theme === 'dark' ? '#ef4444' : '#dc2626',
    neutral: theme === 'dark' ? '#3b82f6' : '#2563eb',
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b' : '#f8fafc',
    grid: theme === 'dark' ? '#334155' : '#e2e8f0'
  };

  // Determine trend direction and strength
  const getTrendIndicator = (value, threshold = 50) => {
    if (value > threshold + 10) return { icon: <UpArrowIcon />, color: colors.bullish, label: 'Bullish' };
    if (value < threshold - 10) return { icon: <DownArrowIcon />, color: colors.bearish, label: 'Bearish' };
    return { icon: null, color: colors.neutral, label: 'Neutral' };
  };

  // Format indicator value with direction
  const renderIndicatorValue = (value, formatFn = formatPercentage) => {
    const trend = getTrendIndicator(value);
    return (
      <div className="indicator-value">
        <span className="value" style={{ color: trend.color }}>
          {formatFn(value / 100)}
        </span>
        <span className="trend-icon" style={{ color: trend.color }}>
          {trend.icon}
        </span>
      </div>
    );
  };

  return (
    <div 
      className={`technical-panel ${className}`}
      style={{
        backgroundColor: colors.background,
        borderColor: colors.grid
      }}
    >
      <div className="panel-header">
        <TechnicalIcon className="panel-icon" />
        <h3 className="panel-title" style={{ color: colors.text }}>
          Technical Analysis
        </h3>
        <span className="timeframe" style={{ color: colors.text }}>
          ({timeframe})
        </span>
      </div>

      <div className="quadrants-container">
        {/* Momentum Quadrant */}
        <div 
          className="quadrant momentum"
          style={{ borderColor: colors.grid }}
        >
          <h4 className="quadrant-title" style={{ color: colors.text }}>
            Momentum
          </h4>
          <div className="indicators-grid">
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                RSI (14)
              </span>
              {renderIndicatorValue(indicators.rsi)}
              <GaugeMeter 
                value={indicators.rsi} 
                color={getTrendIndicator(indicators.rsi).color}
                size="small"
              />
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Stochastic
              </span>
              {renderIndicatorValue(indicators.stochastic)}
              <div className="indicator-note" style={{ color: colors.text }}>
                {indicators.stochastic > 80 ? 'Overbought' : 
                 indicators.stochastic < 20 ? 'Oversold' : 'Neutral'}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                MACD
              </span>
              <div className="macd-value">
                <span className="value" style={{ color: colors.text }}>
                  {indicators.macd.value.toFixed(4)}
                </span>
                <span 
                  className="signal" 
                  style={{ 
                    color: indicators.macd.histogram > 0 ? colors.bullish : colors.bearish 
                  }}
                >
                  {indicators.macd.histogram > 0 ? '↑ Bullish' : '↓ Bearish'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Trend Quadrant */}
        <div 
          className="quadrant trend"
          style={{ borderColor: colors.grid }}
        >
          <h4 className="quadrant-title" style={{ color: colors.text }}>
            Trend
          </h4>
          <div className="indicators-grid">
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                ADX (14)
              </span>
              {renderIndicatorValue(indicators.adx)}
              <div className="indicator-note" style={{ color: colors.text }}>
                {indicators.adx > 25 ? 'Strong Trend' : 'Weak Trend'}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                EMA Cross
              </span>
              <div className="ema-value">
                <span 
                  className="value" 
                  style={{ 
                    color: indicators.ema.direction === 'bullish' ? colors.bullish : colors.bearish 
                  }}
                >
                  {indicators.ema.value.toFixed(5)}
                </span>
                <span 
                  className="direction" 
                  style={{ 
                    color: indicators.ema.direction === 'bullish' ? colors.bullish : colors.bearish 
                  }}
                >
                  {indicators.ema.direction === 'bullish' ? 'Bullish' : 'Bearish'}
                </span>
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Ichimoku
              </span>
              <div className="ichimoku-value">
                <span 
                  className="value" 
                  style={{ 
                    color: indicators.ichimoku.signal === 'above' ? colors.bullish : colors.bearish 
                  }}
                >
                  {indicators.ichimoku.signal === 'above' ? 'Above Cloud' : 'Below Cloud'}
                </span>
                <span className="conversion" style={{ color: colors.text }}>
                  Conversion: {indicators.ichimoku.conversionLine.toFixed(5)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Volatility Quadrant */}
        <div 
          className="quadrant volatility"
          style={{ borderColor: colors.grid }}
        >
          <h4 className="quadrant-title" style={{ color: colors.text }}>
            Volatility
          </h4>
          <div className="indicators-grid">
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                ATR (14)
              </span>
              <span className="value" style={{ color: colors.text }}>
                {indicators.atr.toFixed(5)}
              </span>
              <div className="indicator-note" style={{ color: colors.text }}>
                {indicators.atr > 0.001 ? 'High Volatility' : 'Low Volatility'}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Bollinger %
              </span>
              {renderIndicatorValue(indicators.bollingerPercent)}
              <div className="indicator-note" style={{ color: colors.text }}>
                {indicators.bollingerPercent > 80 ? 'Upper Band' : 
                 indicators.bollingerPercent < 20 ? 'Lower Band' : 'Mid Range'}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Donchian
              </span>
              <span className="value" style={{ color: colors.text }}>
                {indicators.donchian.width.toFixed(5)}
              </span>
              <div className="indicator-note" style={{ color: colors.text }}>
                {indicators.donchian.breakout ? 'Breakout Detected' : 'Within Channel'}
              </div>
            </div>
          </div>
        </div>

        {/* Volume Quadrant */}
        <div 
          className="quadrant volume"
          style={{ borderColor: colors.grid }}
        >
          <h4 className="quadrant-title" style={{ color: colors.text }}>
            Volume
          </h4>
          <div className="indicators-grid">
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                OBV
              </span>
              {renderIndicatorValue(indicators.obv)}
              <div className="indicator-note" style={{ color: colors.text }}>
                {indicators.obv > 50 ? 'Accumulation' : 'Distribution'}
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                Volume Change
              </span>
              <span 
                className="value" 
                style={{ 
                  color: indicators.volumeChange > 0 ? colors.bullish : colors.bearish 
                }}
              >
                {formatPercentage(indicators.volumeChange / 100)}
              </span>
              <div className="indicator-note" style={{ color: colors.text }}>
                vs. 24h average
              </div>
            </div>
            <div className="indicator">
              <span className="indicator-label" style={{ color: colors.text }}>
                VWAP
              </span>
              <span className="value" style={{ color: colors.text }}>
                {indicators.vwap.toFixed(5)}
              </span>
              <div 
                className="indicator-note" 
                style={{ 
                  color: indicators.priceRelativeToVWAP > 0 ? colors.bullish : colors.bearish 
                }}
              >
                {indicators.priceRelativeToVWAP > 0 ? 'Above VWAP' : 'Below VWAP'}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="panel-footer">
        <span className="last-updated" style={{ color: colors.text }}>
          Last updated: {new Date(indicators.timestamp).toLocaleTimeString()}
        </span>
        <span 
          className="strength-meter"
          style={{ 
            backgroundColor: colors.background,
            borderColor: getTrendIndicator(indicators.compositeScore).color
          }}
        >
          <span className="label" style={{ color: colors.text }}>
            Composite Strength:
          </span>
          <span 
            className="value" 
            style={{ color: getTrendIndicator(indicators.compositeScore).color }}
          >
            {indicators.compositeScore}/100
          </span>
        </span>
      </div>
    </div>
  );
};

TechnicalPanel.propTypes = {
  indicators: PropTypes.shape({
    rsi: PropTypes.number.isRequired,
    stochastic: PropTypes.number.isRequired,
    macd: PropTypes.shape({
      value: PropTypes.number.isRequired,
      histogram: PropTypes.number.isRequired
    }).isRequired,
    adx: PropTypes.number.isRequired,
    ema: PropTypes.shape({
      value: PropTypes.number.isRequired,
      direction: PropTypes.oneOf(['bullish', 'bearish']).isRequired
    }).isRequired,
    ichimoku: PropTypes.shape({
      signal: PropTypes.oneOf(['above', 'below']).isRequired,
      conversionLine: PropTypes.number.isRequired
    }).isRequired,
    atr: PropTypes.number.isRequired,
    bollingerPercent: PropTypes.number.isRequired,
    donchian: PropTypes.shape({
      width: PropTypes.number.isRequired,
      breakout: PropTypes.bool.isRequired
    }).isRequired,
    obv: PropTypes.number.isRequired,
    volumeChange: PropTypes.number.isRequired,
    vwap: PropTypes.number.isRequired,
    priceRelativeToVWAP: PropTypes.number.isRequired,
    compositeScore: PropTypes.number.isRequired,
    timestamp: PropTypes.number.isRequired
  }).isRequired,
  timeframe: PropTypes.string,
  className: PropTypes.string
};

export default TechnicalPanel;