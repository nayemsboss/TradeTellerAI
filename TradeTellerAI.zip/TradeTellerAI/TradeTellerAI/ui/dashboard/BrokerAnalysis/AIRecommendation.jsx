// ui/dashboard/BrokerAnalysis/AIRecommendation.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as RecommendationIcon } from '../../../../assets/icons/svg/recommendation.svg';
import { ReactComponent as CheckIcon } from '../../../../assets/icons/svg/check.svg';
import { ReactComponent as WarningIcon } from '../../../../assets/icons/svg/warning.svg';
import { useTheme } from '../../../../constants/uiConstants';
import ConfidenceBar from '../../widgets/ConfidenceBar';

/**
 * AIRecommendation component displays AI's broker recommendation with reasoning
 * @param {Object} props - Component props
 * @param {Object} props.recommendation - Recommendation data object
 * @param {string} [props.size] - Size variant ('compact' | 'normal' | 'detailed')
 * @param {string} [props.className] - Additional CSS classes
 */
const AIRecommendation = ({ 
  recommendation, 
  size = 'normal', 
  className = '' 
}) => {
  const theme = useTheme();
  
  // Color scheme based on theme
  const colors = {
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b' : '#f8fafc',
    highlight: theme === 'dark' ? '#3b82f6' : '#2563eb',
    positive: theme === 'dark' ? '#10b981' : '#059669',
    negative: theme === 'dark' ? '#ef4444' : '#dc2626'
  };

  // Recommendation strength text
  const getStrengthText = (strength) => {
    if (strength >= 90) return 'STRONG RECOMMENDATION';
    if (strength >= 70) return 'SOLID CHOICE';
    if (strength >= 50) return 'MODERATE MATCH';
    return 'LOW CONFIDENCE';
  };

  return (
    <div 
      className={`ai-recommendation ${size} ${className}`}
      style={{
        backgroundColor: colors.background,
        borderColor: theme === 'dark' ? '#334155' : '#e2e8f0'
      }}
    >
      <div className="recommendation-header">
        <RecommendationIcon 
          className="recommendation-icon"
          style={{ color: colors.highlight }}
        />
        <h3 className="title" style={{ color: colors.text }}>
          AI Broker Recommendation
        </h3>
        <div 
          className="strength-badge"
          style={{
            backgroundColor: colors.highlight + '20',
            color: colors.highlight
          }}
        >
          {getStrengthText(recommendation.confidence)}
        </div>
      </div>

      <div className="confidence-indicator">
        <ConfidenceBar 
          level={Math.ceil(recommendation.confidence / 20)} 
          color={colors.highlight}
          size={size === 'compact' ? 'small' : 'medium'}
        />
        <span 
          className="confidence-value"
          style={{ color: colors.highlight }}
        >
          {recommendation.confidence}% Confidence
        </span>
      </div>

      {size !== 'compact' && (
        <div className="recommendation-reasons">
          <h4 className="reasons-title" style={{ color: colors.text }}>
            Key Advantages:
          </h4>
          <ul className="reasons-list">
            {recommendation.strengths.map((strength, index) => (
              <li key={index} className="reason-item">
                <CheckIcon 
                  className="reason-icon" 
                  style={{ color: colors.positive }} 
                />
                <span className="reason-text" style={{ color: colors.text }}>
                  {strength}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {size === 'detailed' && recommendation.considerations.length > 0 && (
        <div className="considerations">
          <h4 className="considerations-title" style={{ color: colors.text }}>
            Considerations:
          </h4>
          <ul className="considerations-list">
            {recommendation.considerations.map((consideration, index) => (
              <li key={index} className="consideration-item">
                <WarningIcon 
                  className="consideration-icon" 
                  style={{ color: colors.negative }} 
                />
                <span className="consideration-text" style={{ color: colors.text }}>
                  {consideration}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {size !== 'compact' && (
        <div className="recommendation-footer">
          <span className="update-time" style={{ color: colors.text }}>
            Last analyzed: {new Date(recommendation.timestamp).toLocaleString()}
          </span>
          <span 
            className="ai-model" 
            style={{ 
              backgroundColor: colors.highlight + '20',
              color: colors.highlight
            }}
          >
            {recommendation.modelVersion}
          </span>
        </div>
      )}
    </div>
  );
};

AIRecommendation.propTypes = {
  recommendation: PropTypes.shape({
    confidence: PropTypes.number.isRequired,
    strengths: PropTypes.arrayOf(PropTypes.string).isRequired,
    considerations: PropTypes.arrayOf(PropTypes.string),
    timestamp: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    modelVersion: PropTypes.string.isRequired
  }).isRequired,
  size: PropTypes.oneOf(['compact', 'normal', 'detailed']),
  className: PropTypes.string
};

// Default recommendation data structure
AIRecommendation.defaultProps = {
  recommendation: {
    confidence: 87,
    strengths: [
      'Lowest spreads for EUR/USD',
      'Fastest execution speed (0.8ms)',
      'High liquidity during news events',
      '90% win rate for similar strategies'
    ],
    considerations: [
      'Higher minimum deposit required',
      'Limited cryptocurrency offerings'
    ],
    timestamp: Date.now(),
    modelVersion: 'TFFC v3.2'
  }
};

export default AIRecommendation;