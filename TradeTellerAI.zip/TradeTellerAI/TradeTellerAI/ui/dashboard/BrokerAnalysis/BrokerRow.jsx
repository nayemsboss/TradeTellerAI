// ui/dashboard/BrokerAnalysis/BrokerRow.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as StarIcon } from '../../../../assets/icons/svg/star.svg';
import { ReactComponent as CheckIcon } from '../../../../assets/icons/svg/check.svg';
import { ReactComponent as WarningIcon } from '../../../../assets/icons/svg/warning.svg';
import { formatCurrency, formatPercentage } from '../../../../utils/tradingMath';
import { useTheme } from '../../../../constants/uiConstants';

/**
 * BrokerRow component displays a single broker's analysis in a table row
 * @param {Object} props - Component props
 * @param {Object} props.broker - Broker data object
 * @param {boolean} [props.isRecommended] - Whether marked as AI-recommended
 * @param {boolean} [props.isSelected] - Whether currently selected
 * @param {function} [props.onSelect] - Callback when broker is selected
 * @param {string} [props.className] - Additional CSS classes
 */
const BrokerRow = ({ 
  broker, 
  isRecommended = false, 
  isSelected = false, 
  onSelect, 
  className = '' 
}) => {
  const theme = useTheme();

  // Determine broker rating stars
  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < 5; i++) {
      let starType;
      if (i < fullStars) {
        starType = 'full';
      } else if (i === fullStars && hasHalfStar) {
        starType = 'half';
      } else {
        starType = 'empty';
      }
      
      stars.push(
        <StarIcon 
          key={i}
          className={`star ${starType}`}
          style={{ color: theme === 'dark' ? '#f59e0b' : '#d97706' }}
        />
      );
    }
    
    return stars;
  };

  // Color for spread value based on quality
  const getSpreadColor = (spread) => {
    if (spread <= 0.8) return theme === 'dark' ? '#10b981' : '#059669'; // Excellent
    if (spread <= 1.2) return theme === 'dark' ? '#f59e0b' : '#d97706'; // Good
    return theme === 'dark' ? '#ef4444' : '#dc2626'; // Poor
  };

  // Color for execution speed
  const getSpeedColor = (speed) => {
    if (speed < 1) return theme === 'dark' ? '#10b981' : '#059669'; // Excellent
    if (speed < 2) return theme === 'dark' ? '#f59e0b' : '#d97706'; // Good
    return theme === 'dark' ? '#ef4444' : '#dc2626'; // Poor
  };

  return (
    <div 
      className={`broker-row ${isSelected ? 'selected' : ''} ${className}`}
      onClick={() => onSelect && onSelect(broker.id)}
      style={{
        backgroundColor: isSelected 
          ? (theme === 'dark' ? '#334155' : '#e2e8f0')
          : 'transparent',
        borderColor: theme === 'dark' ? '#334155' : '#e2e8f0'
      }}
    >
      <div className="broker-info">
        <div className="broker-name">
          {isRecommended && (
            <CheckIcon 
              className="recommended-icon" 
              style={{ color: theme === 'dark' ? '#10b981' : '#059669' }}
            />
          )}
          <img 
            src={`../../../../assets/icons/broker-logos/${broker.id}.png`} 
            alt={broker.name} 
            className="broker-logo" 
          />
          <span className="name">{broker.name}</span>
          {broker.isECN && (
            <span className="ecn-badge">ECN</span>
          )}
        </div>
      </div>

      <div className="broker-metrics">
        <div className="metric rating">
          <div className="stars">
            {renderStars(broker.rating)}
          </div>
          <span className="value">{broker.rating.toFixed(1)}</span>
        </div>

        <div className="metric spread">
          <span 
            className="value" 
            style={{ color: getSpreadColor(broker.spread) }}
          >
            {formatCurrency(broker.spread)}
          </span>
          <span className="label">pips</span>
        </div>

        <div className="metric execution">
          <span 
            className="value" 
            style={{ color: getSpeedColor(broker.executionSpeed) }}
          >
            {broker.executionSpeed.toFixed(1)}ms
          </span>
        </div>

        <div className="metric win-rate">
          <span className="value">
            {formatPercentage(broker.winRate / 100)}
          </span>
        </div>

        <div className="metric slippage">
          {broker.slippage > 0 ? (
            <>
              <WarningIcon 
                className="warning-icon" 
                style={{ color: theme === 'dark' ? '#ef4444' : '#dc2626' }} 
              />
              <span className="value negative">
                +{formatCurrency(broker.slippage)}
              </span>
            </>
          ) : (
            <span className="value positive">
              {formatCurrency(broker.slippage)}
            </span>
          )}
        </div>

        <div className="metric match-score">
          <div 
            className="score-bar"
            style={{
              backgroundColor: theme === 'dark' ? '#334155' : '#e2e8f0'
            }}
          >
            <div 
              className="score-fill"
              style={{
                width: `${broker.matchScore}%`,
                backgroundColor: theme === 'dark' ? '#3b82f6' : '#2563eb'
              }}
            />
          </div>
          <span className="value">
            {broker.matchScore}%
          </span>
        </div>
      </div>

      {isRecommended && (
        <div 
          className="recommended-tag"
          style={{
            backgroundColor: theme === 'dark' ? '#10b98130' : '#05966930',
            color: theme === 'dark' ? '#10b981' : '#059669'
          }}
        >
          AI Recommended
        </div>
      )}
    </div>
  );
};

BrokerRow.propTypes = {
  broker: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    isECN: PropTypes.bool,
    rating: PropTypes.number.isRequired,
    spread: PropTypes.number.isRequired,
    executionSpeed: PropTypes.number.isRequired,
    winRate: PropTypes.number.isRequired,
    slippage: PropTypes.number.isRequired,
    matchScore: PropTypes.number.isRequired
  }).isRequired,
  isRecommended: PropTypes.bool,
  isSelected: PropTypes.bool,
  onSelect: PropTypes.func,
  className: PropTypes.string
};

export default BrokerRow;