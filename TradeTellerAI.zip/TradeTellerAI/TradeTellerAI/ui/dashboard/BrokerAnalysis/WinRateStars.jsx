// ui/dashboard/BrokerAnalysis/WinRateStars.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as StarFull } from '../../../../assets/icons/svg/star-full.svg';
import { ReactComponent as StarHalf } from '../../../../assets/icons/svg/star-half.svg';
import { ReactComponent as StarEmpty } from '../../../../assets/icons/svg/star-empty.svg';
import { useTheme } from '../../../../constants/uiConstants';

/**
 * WinRateStars component displays a broker's win rate as star ratings with precision
 * @param {Object} props - Component props
 * @param {number} props.winRate - Win rate percentage (0-100)
 * @param {string} [props.size] - Size variant ('small' | 'medium' | 'large')
 * @param {boolean} [props.showPercentage] - Whether to show numeric percentage
 * @param {string} [props.className] - Additional CSS classes
 */
const WinRateStars = ({ 
  winRate, 
  size = 'medium', 
  showPercentage = true,
  className = '' 
}) => {
  const theme = useTheme();
  const clampedWinRate = Math.min(Math.max(winRate, 0), 100);
  
  // Size variants
  const sizes = {
    small: {
      starSize: 12,
      fontSize: 10,
      spacing: 2
    },
    medium: {
      starSize: 16,
      fontSize: 12,
      spacing: 4
    },
    large: {
      starSize: 20,
      fontSize: 14,
      spacing: 6
    }
  };
  
  const { starSize, fontSize, spacing } = sizes[size];
  
  // Convert win rate to 5-star scale (with half-star precision)
  const starRating = (clampedWinRate / 100) * 5;
  const fullStars = Math.floor(starRating);
  const hasHalfStar = starRating % 1 >= 0.5;
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
  
  // Color based on win rate performance
  const getWinRateColor = () => {
    if (clampedWinRate >= 80) return theme === 'dark' ? '#10b981' : '#059669'; // Excellent
    if (clampedWinRate >= 60) return theme === 'dark' ? '#f59e0b' : '#d97706'; // Good
    return theme === 'dark' ? '#ef4444' : '#dc2626'; // Poor
  };

  return (
    <div className={`win-rate-stars ${size} ${className}`}>
      <div className="stars-container" style={{ gap: `${spacing}px` }}>
        {/* Render full stars */}
        {[...Array(fullStars)].map((_, i) => (
          <StarFull
            key={`full-${i}`}
            style={{ 
              width: `${starSize}px`,
              height: `${starSize}px`,
              color: getWinRateColor()
            }}
          />
        ))}
        
        {/* Render half star if needed */}
        {hasHalfStar && (
          <StarHalf
            style={{ 
              width: `${starSize}px`,
              height: `${starSize}px`,
              color: getWinRateColor()
            }}
          />
        )}
        
        {/* Render empty stars */}
        {[...Array(emptyStars)].map((_, i) => (
          <StarEmpty
            key={`empty-${i}`}
            style={{ 
              width: `${starSize}px`,
              height: `${starSize}px`,
              color: theme === 'dark' ? '#334155' : '#e2e8f0'
            }}
          />
        ))}
      </div>
      
      {showPercentage && (
        <span 
          className="percentage-value"
          style={{
            fontSize: `${fontSize}px`,
            color: getWinRateColor(),
            marginLeft: `${spacing}px`
          }}
        >
          {clampedWinRate}%
        </span>
      )}
    </div>
  );
};

WinRateStars.propTypes = {
  winRate: PropTypes.number.isRequired,
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  showPercentage: PropTypes.bool,
  className: PropTypes.string
};

export default WinRateStars;