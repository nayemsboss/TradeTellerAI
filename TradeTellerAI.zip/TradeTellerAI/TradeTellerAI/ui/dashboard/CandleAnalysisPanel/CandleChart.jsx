// ui/dashboard/CandleAnalysisPanel/CandleChart.jsx
import React, { useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { useCandleData } from '../../../services/candleAnalysisService';
import { detectPatterns } from '../../../ai/candleAnalysisProcessor';
import { drawChart, updateChart } from '../../../utils/chartHelpers';
import { candlePatternDefinitions } from '../../../constants/patternDefinitions';
import '../../../assets/styles/_candle-chart.scss';

/**
 * Interactive Candlestick Chart with Pattern Annotations
 */
export const CandleChart = ({ 
  currencyPair, 
  timeframe, 
  showVolume = true,
  showPatterns = true,
  showIndicators = false
}) => {
  const chartContainerRef = useRef(null);
  const [chartInstance, setChartInstance] = useState(null);
  const [activePattern, setActivePattern] = useState(null);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });
  const [isTooltipVisible, setIsTooltipVisible] = useState(false);
  
  const { candleData, loading, error } = useCandleData(currencyPair, timeframe);
  const [detectedPatterns, setDetectedPatterns] = useState([]);

  // Initialize chart when data loads
  useEffect(() => {
    if (!candleData || !chartContainerRef.current) return;

    const patterns = detectPatterns(candleData);
    setDetectedPatterns(patterns);

    const config = {
      container: chartContainerRef.current,
      data: candleData,
      patterns: showPatterns ? patterns : [],
      showVolume,
      showIndicators,
      onPatternHover: (pattern, event) => {
        if (pattern) {
          setActivePattern(pattern);
          setTooltipPosition({
            x: event.clientX,
            y: event.clientY
          });
          setIsTooltipVisible(true);
        } else {
          setIsTooltipVisible(false);
        }
      }
    };

    const instance = drawChart(config);
    setChartInstance(instance);

    return () => {
      if (instance && instance.destroy) {
        instance.destroy();
      }
    };
  }, [candleData, showVolume, showPatterns, showIndicators]);

  // Update chart when props change
  useEffect(() => {
    if (!chartInstance || !candleData) return;

    updateChart(chartInstance, {
      data: candleData,
      patterns: showPatterns ? detectedPatterns : [],
      showVolume,
      showIndicators
    });
  }, [timeframe, showVolume, showPatterns, showIndicators]);

  if (loading) {
    return (
      <div className="chart-loading-state">
        <img 
          src="../../assets/images/loading/chart-loading.gif" 
          alt="Loading chart data" 
        />
        <p>Loading {currencyPair} {timeframe} chart...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="chart-error-state">
        <div className="error-icon">⚠️</div>
        <div className="error-message">
          Failed to load chart data: {error.message}
        </div>
        <button 
          className="retry-button"
          onClick={() => window.location.reload()}
        >
          Reload Chart
        </button>
      </div>
    );
  }

  return (
    <div className="candle-chart-container">
      <div className="chart-header">
        <h3>
          {currencyPair} • {timeframe} Chart
          {showPatterns && (
            <span className="pattern-count">
              {detectedPatterns.length} patterns detected
            </span>
          )}
        </h3>
        <div className="chart-controls">
          <button 
            className={`control-btn ${showVolume ? 'active' : ''}`}
            onClick={() => updateChart(chartInstance, { showVolume: !showVolume })}
          >
            Volume {showVolume ? 'ON' : 'OFF'}
          </button>
          <button 
            className={`control-btn ${showPatterns ? 'active' : ''}`}
            onClick={() => updateChart(chartInstance, { showPatterns: !showPatterns })}
          >
            Patterns {showPatterns ? 'ON' : 'OFF'}
          </button>
          <button 
            className={`control-btn ${showIndicators ? 'active' : ''}`}
            onClick={() => updateChart(chartInstance, { showIndicators: !showIndicators })}
          >
            Indicators {showIndicators ? 'ON' : 'OFF'}
          </button>
        </div>
      </div>

      <div 
        ref={chartContainerRef} 
        className="candle-chart" 
        style={{ height: '500px', width: '100%' }}
      />

      {isTooltipVisible && activePattern && (
        <div 
          className="pattern-tooltip"
          style={{
            left: `${tooltipPosition.x + 15}px`,
            top: `${tooltipPosition.y + 15}px`
          }}
        >
          <div className="tooltip-header">
            <span className={`pattern-type ${activePattern.type}`}>
              {activePattern.type.toUpperCase()}
            </span>
            <h4>{activePattern.name}</h4>
          </div>
          <div className="tooltip-body">
            <p>{candlePatternDefinitions[activePattern.name]?.description}</p>
            <div className="pattern-stats">
              <div className="stat-item">
                <span className="stat-label">Strength:</span>
                <span className="stat-value">{activePattern.strength}/10</span>
              </div>
              <div className="stat-item">
                <span className="stat-label">Confidence:</span>
                <span className="stat-value">{activePattern.confidence}%</span>
              </div>
              <div className="stat-item">
                <span className="stat-label">Time:</span>
                <span className="stat-value">
                  {new Date(activePattern.timestamp).toLocaleString()}
                </span>
              </div>
            </div>
          </div>
          <div className="tooltip-footer">
            <span className="pattern-implications">
              {candlePatternDefinitions[activePattern.name]?.implications || 
               'Potential trend continuation/reversal pattern'}
            </span>
          </div>
        </div>
      )}

      <div className="chart-footer">
        <div className="timeframe-info">
          Last updated: {new Date().toLocaleTimeString()}
        </div>
        <div className="chart-legend">
          <span className="legend-item bullish">Bullish</span>
          <span className="legend-item bearish">Bearish</span>
          <span className="legend-item neutral">Neutral</span>
        </div>
      </div>
    </div>
  );
};

CandleChart.propTypes = {
  currencyPair: PropTypes.string.isRequired,
  timeframe: PropTypes.oneOf([
    '1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'
  ]).isRequired,
  showVolume: PropTypes.bool,
  showPatterns: PropTypes.bool,
  showIndicators: PropTypes.bool
};

export default CandleChart;