// ui/dashboard/CandleAnalysisPanel/CandlePatternList.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { PatternIndicator } from '../../widgets/PatternIndicator';
import { useCandleAnalysis } from '../../../services/candleAnalysisService';
import { candlePatternDefinitions } from '../../../constants/patternDefinitions';
import { formatStrength } from '../../../utils/statsCalculator';
import '../../../assets/styles/_candle-patterns.scss';

/**
 * CandlePatternList Component
 * Displays recognized candlestick patterns with visual indicators and details
 */
export const CandlePatternList = ({ currencyPair, timeframe }) => {
  const { patterns, loading, error } = useCandleAnalysis(currencyPair, timeframe);

  if (loading) {
    return (
      <div className="candle-pattern-loading">
        <img 
          src="../../assets/images/loading/spinner.gif" 
          alt="Loading patterns" 
          className="loading-spinner"
        />
        <p>Analyzing candlestick patterns...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="candle-pattern-error">
        <p className="error-message">⚠️ {error.message}</p>
        <button 
          className="retry-button"
          onClick={() => window.location.reload()}
        >
          Retry Analysis
        </button>
      </div>
    );
  }

  return (
    <div className="candle-pattern-list">
      <div className="pattern-list-header">
        <h3>Detected Candlestick Patterns</h3>
        <div className="timeframe-indicator">
          {timeframe} • {currencyPair}
        </div>
      </div>

      <div className="patterns-container">
        {patterns.length > 0 ? (
          patterns.map((pattern) => (
            <div 
              key={`${pattern.name}-${pattern.timestamp}`}
              className={`pattern-card ${pattern.type}`}
            >
              <div className="pattern-visual">
                <PatternIndicator 
                  pattern={pattern.name} 
                  strength={pattern.strength}
                />
                <img
                  src={`../../assets/icons/candle_patterns/${pattern.name.toLowerCase().replace(' ', '_')}.png`}
                  alt={pattern.name}
                  className="pattern-image"
                />
              </div>
              <div className="pattern-details">
                <h4 className="pattern-name">
                  {pattern.name} ({pattern.type.toUpperCase()})
                </h4>
                <div className="pattern-strength">
                  <span className="strength-label">Strength:</span>
                  <span className="strength-value">
                    {formatStrength(pattern.strength)}/10
                  </span>
                  <div 
                    className="strength-bar"
                    style={{ width: `${pattern.strength * 10}%` }}
                  />
                </div>
                <p className="pattern-description">
                  {candlePatternDefinitions[pattern.name]?.description}
                </p>
                <div className="pattern-meta">
                  <span className="pattern-time">
                    Detected: {new Date(pattern.timestamp).toLocaleTimeString()}
                  </span>
                  <span className="pattern-confidence">
                    Confidence: {pattern.confidence}%
                  </span>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="no-patterns">
            <p>No significant candlestick patterns detected</p>
            <small>Analysis performed on last 50 candles</small>
          </div>
        )}
      </div>

      <div className="pattern-legend">
        <div className="legend-item bullish">
          <span className="legend-color" />
          <span>Bullish Pattern</span>
        </div>
        <div className="legend-item bearish">
          <span className="legend-color" />
          <span>Bearish Pattern</span>
        </div>
        <div className="legend-item reversal">
          <span className="legend-color" />
          <span>Reversal Pattern</span>
        </div>
      </div>
    </div>
  );
};

CandlePatternList.propTypes = {
  currencyPair: PropTypes.string.isRequired,
  timeframe: PropTypes.oneOf([
    '1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'
  ]).isRequired
};

export default CandlePatternList;