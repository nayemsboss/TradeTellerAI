// ui/dashboard/CombinedSignal/ConfidenceBadge.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as ConfidenceIcon } from '../../../../assets/icons/svg/confidence.svg';
import { useTheme } from '../../../../constants/uiConstants';
import { formatPercentage } from '../../../../utils/tradingMath';

/**
 * ConfidenceBadge component displays a compact confidence indicator
 * @param {Object} props - Component props
 * @param {number} props.confidence - Confidence percentage (0-100)
 * @param {string} [props.size] - Size variant ('small' | 'medium' | 'large')
 * @param {boolean} [props.showIcon] - Whether to show the confidence icon
 * @param {boolean} [props.showPercentage] - Whether to show the percentage value
 * @param {string} [props.className] - Additional CSS classes
 */
const ConfidenceBadge = ({ 
  confidence, 
  size = 'medium', 
  showIcon = true,
  showPercentage = true,
  className = '' 
}) => {
  const theme = useTheme();
  const clampedConfidence = Math.min(Math.max(confidence, 0), 100);
  
  // Size variants
  const sizes = {
    small: {
      diameter: 24,
      fontSize: 10,
      iconSize: 12,
      strokeWidth: 3
    },
    medium: {
      diameter: 32,
      fontSize: 12,
      iconSize: 16,
      strokeWidth: 4
    },
    large: {
      diameter: 40,
      fontSize: 14,
      iconSize: 20,
      strokeWidth: 5
    }
  };
  
  const { diameter, fontSize, iconSize, strokeWidth } = sizes[size];
  const radius = (diameter - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (clampedConfidence / 100) * circumference;
  
  // Color based on confidence level
  const getConfidenceColor = () => {
    if (clampedConfidence >= 80) return theme === 'dark' ? '#10b981' : '#059669'; // High confidence
    if (clampedConfidence >= 50) return theme === 'dark' ? '#f59e0b' : '#d97706'; // Medium confidence
    return theme === 'dark' ? '#ef4444' : '#dc2626'; // Low confidence
  };
  
  // Confidence level text
  const getConfidenceLevel = () => {
    if (clampedConfidence >= 80) return 'High';
    if (clampedConfidence >= 60) return 'Strong';
    if (clampedConfidence >= 40) return 'Moderate';
    if (clampedConfidence >= 20) return 'Low';
    return 'Very Low';
  };

  return (
    <div 
      className={`confidence-badge ${size} ${className}`}
      style={{
        '--diameter': `${diameter}px`,
        '--font-size': `${fontSize}px`,
        '--icon-size': `${iconSize}px`,
        '--confidence-color': getConfidenceColor(),
        '--text-color': theme === 'dark' ? '#e2e8f0' : '#1e293b',
        '--bg-color': theme === 'dark' ? '#1e293b' : '#f8fafc'
      }}
    >
      <div className="badge-container">
        <svg 
          className="confidence-ring" 
          width={diameter} 
          height={diameter}
          viewBox={`0 0 ${diameter} ${diameter}`}
        >
          {/* Background circle */}
          <circle
            className="ring-bg"
            cx={diameter / 2}
            cy={diameter / 2}
            r={radius}
            strokeWidth={strokeWidth}
            stroke={theme === 'dark' ? '#334155' : '#e2e8f0'}
            fill="none"
          />
          {/* Confidence progress */}
          <circle
            className="ring-progress"
            cx={diameter / 2}
            cy={diameter / 2}
            r={radius}
            strokeWidth={strokeWidth}
            stroke={getConfidenceColor()}
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            fill="none"
            transform={`rotate(-90 ${diameter / 2} ${diameter / 2})`}
          />
        </svg>
        
        <div className="badge-content">
          {showIcon && (
            <ConfidenceIcon 
              className="confidence-icon" 
              style={{ 
                width: iconSize,
                height: iconSize,
                color: getConfidenceColor()
              }} 
            />
          )}
          {showPercentage && (
            <span className="confidence-value">
              {clampedConfidence}%
            </span>
          )}
        </div>
      </div>
      
      <div className="confidence-label">
        {getConfidenceLevel()} Confidence
      </div>
    </div>
  );
};

ConfidenceBadge.propTypes = {
  confidence: PropTypes.number.isRequired,
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  showIcon: PropTypes.bool,
  showPercentage: PropTypes.bool,
  className: PropTypes.string
};

export default ConfidenceBadge;