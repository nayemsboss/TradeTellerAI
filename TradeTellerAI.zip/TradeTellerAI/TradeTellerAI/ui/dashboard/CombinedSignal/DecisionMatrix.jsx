// ui/dashboard/CombinedSignal/DecisionMatrix.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as DecisionIcon } from '../../../../assets/icons/svg/decision.svg';
import { ReactComponent as BullishIcon } from '../../../../assets/icons/svg/bullish.svg';
import { ReactComponent as BearishIcon } from '../../../../assets/icons/svg/bearish.svg';
import { ReactComponent as NeutralIcon } from '../../../../assets/icons/svg/neutral.svg';
import { useTheme } from '../../../../constants/uiConstants';
import ConfidenceBar from '../../widgets/ConfidenceBar';
import { formatPercentage } from '../../../../utils/tradingMath';

/**
 * DecisionMatrix component visualizes AI's combined trading decision
 * @param {Object} props - Component props
 * @param {Object} props.decision - Decision data object
 * @param {string} [props.timeframe] - Decision timeframe
 * @param {string} [props.className] - Additional CSS classes
 */
const DecisionMatrix = ({ decision, timeframe = '4H', className = '' }) => {
  const theme = useTheme();

  // Color scheme based on theme
  const colors = {
    bullish: theme === 'dark' ? '#10b981' : '#059669',
    bearish: theme === 'dark' ? '#ef4444' : '#dc2626',
    neutral: theme === 'dark' ? '#3b82f6' : '#2563eb',
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b' : '#f8fafc',
    grid: theme === 'dark' ? '#334155' : '#e2e8f0'
  };

  // Determine direction icon and color
  const getDirectionIcon = () => {
    if (decision.direction === 'bullish') {
      return <BullishIcon style={{ color: colors.bullish }} />;
    }
    if (decision.direction === 'bearish') {
      return <BearishIcon style={{ color: colors.bearish }} />;
    }
    return <NeutralIcon style={{ color: colors.neutral }} />;
  };

  // Get color based on confidence level
  const getConfidenceColor = (confidence) => {
    if (confidence >= 70) return colors.bullish;
    if (confidence >= 40) return colors.neutral;
    return colors.bearish;
  };

  // Get decision strength text
  const getStrengthText = (confidence) => {
    if (confidence >= 80) return 'Very Strong';
    if (confidence >= 60) return 'Strong';
    if (confidence >= 40) return 'Moderate';
    if (confidence >= 20) return 'Weak';
    return 'Very Weak';
  };

  return (
    <div 
      className={`decision-matrix ${className}`}
      style={{
        backgroundColor: colors.background,
        borderColor: colors.grid
      }}
    >
      <div className="matrix-header">
        <DecisionIcon className="header-icon" />
        <h3 className="title" style={{ color: colors.text }}>
          AI Decision Matrix
        </h3>
        <span className="timeframe" style={{ color: colors.text }}>
          ({timeframe})
        </span>
      </div>

      <div className="decision-summary">
        <div className="direction-indicator">
          <div className="direction-icon">
            {getDirectionIcon()}
          </div>
          <div className="direction-text">
            <span 
              className="direction-label" 
              style={{ 
                color: decision.direction === 'bullish' ? colors.bullish : 
                       decision.direction === 'bearish' ? colors.bearish : colors.neutral
              }}
            >
              {decision.direction.toUpperCase()}
            </span>
            <span className="strength-label" style={{ color: colors.text }}>
              {getStrengthText(decision.confidence)} Signal
            </span>
          </div>
        </div>

        <div className="confidence-display">
          <ConfidenceBar 
            level={Math.ceil(decision.confidence / 20)} 
            color={getConfidenceColor(decision.confidence)}
            size="medium"
          />
          <span 
            className="confidence-value"
            style={{ color: getConfidenceColor(decision.confidence) }}
          >
            {decision.confidence}% Confidence
          </span>
        </div>
      </div>

      <div className="factor-matrix">
        <div className="matrix-row header">
          <span className="factor-label" style={{ color: colors.text }}>Factor</span>
          <span className="factor-direction" style={{ color: colors.text }}>Direction</span>
          <span className="factor-weight" style={{ color: colors.text }}>Weight</span>
          <span className="factor-confidence" style={{ color: colors.text }}>Confidence</span>
        </div>

        {decision.factors.map((factor, index) => (
          <div key={index} className="matrix-row">
            <span className="factor-label" style={{ color: colors.text }}>
              {factor.name}
            </span>
            <span 
              className="factor-direction" 
              style={{ 
                color: factor.direction === 'bullish' ? colors.bullish : 
                       factor.direction === 'bearish' ? colors.bearish : colors.neutral
              }}
            >
              {factor.direction.toUpperCase()}
            </span>
            <span className="factor-weight" style={{ color: colors.text }}>
              {formatPercentage(factor.weight / 100)}
            </span>
            <div className="factor-confidence">
              <ConfidenceBar 
                level={Math.ceil(factor.confidence / 20)} 
                color={getConfidenceColor(factor.confidence)}
                size="small"
              />
              <span 
                className="confidence-value"
                style={{ color: getConfidenceColor(factor.confidence) }}
              >
                {factor.confidence}%
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="decision-details">
        <div className="detail-card">
          <h4 className="detail-title" style={{ color: colors.text }}>Key Drivers</h4>
          <ul className="driver-list">
            {decision.keyDrivers.map((driver, index) => (
              <li key={index} className="driver-item">
                <span 
                  className="driver-bullet" 
                  style={{ 
                    backgroundColor: driver.impact === 'high' ? colors.bullish : 
                                   driver.impact === 'low' ? colors.neutral : colors.bearish
                  }}
                />
                <span className="driver-text" style={{ color: colors.text }}>
                  {driver.description}
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div className="detail-card">
          <h4 className="detail-title" style={{ color: colors.text }}>Potential Risks</h4>
          <ul className="risk-list">
            {decision.risks.map((risk, index) => (
              <li key={index} className="risk-item">
                <span 
                  className="risk-bullet" 
                  style={{ backgroundColor: colors.bearish }}
                />
                <span className="risk-text" style={{ color: colors.text }}>
                  {risk.description}
                  {risk.probability && (
                    <span 
                      className="probability" 
                      style={{ 
                        color: risk.probability > 50 ? colors.bearish : colors.neutral
                      }}
                    >
                      ({risk.probability}% probability)
                    </span>
                  )}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="decision-footer">
        <span className="model-info" style={{ color: colors.text }}>
          AI Model: {decision.modelVersion} | Fusion Score: {decision.fusionScore}/100
        </span>
        <span className="timestamp" style={{ color: colors.text }}>
          Last Updated: {new Date(decision.timestamp).toLocaleTimeString()}
        </span>
      </div>
    </div>
  );
};

DecisionMatrix.propTypes = {
  decision: PropTypes.shape({
    direction: PropTypes.oneOf(['bullish', 'bearish', 'neutral']).isRequired,
    confidence: PropTypes.number.isRequired,
    factors: PropTypes.arrayOf(
      PropTypes.shape({
        name: PropTypes.string.isRequired,
        direction: PropTypes.oneOf(['bullish', 'bearish', 'neutral']).isRequired,
        weight: PropTypes.number.isRequired,
        confidence: PropTypes.number.isRequired
      })
    ).isRequired,
    keyDrivers: PropTypes.arrayOf(
      PropTypes.shape({
        description: PropTypes.string.isRequired,
        impact: PropTypes.oneOf(['high', 'medium', 'low']).isRequired
      })
    ).isRequired,
    risks: PropTypes.arrayOf(
      PropTypes.shape({
        description: PropTypes.string.isRequired,
        probability: PropTypes.number
      })
    ).isRequired,
    modelVersion: PropTypes.string.isRequired,
    fusionScore: PropTypes.number.isRequired,
    timestamp: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired
  }).isRequired,
  timeframe: PropTypes.string,
  className: PropTypes.string
};

export default DecisionMatrix;