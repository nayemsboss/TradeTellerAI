// ui/dashboard/CombinedSignal/ReasoningTree.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as DecisionIcon } from '../../../../assets/icons/svg/decision.svg';
import { ReactComponent as BullishIcon } from '../../../../assets/icons/svg/bullish.svg';
import { ReactComponent as BearishIcon } from '../../../../assets/icons/svg/bearish.svg';
import { ReactComponent as NeutralIcon } from '../../../../assets/icons/svg/neutral.svg';
import { ReactComponent as FactorIcon } from '../../../../assets/icons/svg/factor.svg';
import { ReactComponent as ConfidenceIcon } from '../../../../assets/icons/svg/confidence.svg';
import { useTheme } from '../../../../constants/uiConstants';
import { formatPercentage } from '../../../../utils/tradingMath';
import ConfidenceBadge from './ConfidenceBadge';

/**
 * ReasoningTree component visualizes AI decision logic in a hierarchical tree
 * @param {Object} props - Component props
 * @param {Object} props.decision - Decision data object
 * @param {string} [props.className] - Additional CSS classes
 */
const ReasoningTree = ({ decision, className = '' }) => {
  const theme = useTheme();

  // Color scheme based on theme
  const colors = {
    bullish: theme === 'dark' ? '#10b981' : '#059669',
    bearish: theme === 'dark' ? '#ef4444' : '#dc2626',
    neutral: theme === 'dark' ? '#3b82f6' : '#2563eb',
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b' : '#f8fafc',
    grid: theme === 'dark' ? '#334155' : '#e2e8f0',
    connector: theme === 'dark' ? '#475569' : '#cbd5e1'
  };

  // Get icon for decision direction
  const getDirectionIcon = (direction) => {
    switch (direction) {
      case 'bullish': return <BullishIcon className="direction-icon" />;
      case 'bearish': return <BearishIcon className="direction-icon" />;
      default: return <NeutralIcon className="direction-icon" />;
    }
  };

  // Get color for factor weight
  const getWeightColor = (weight) => {
    if (weight >= 30) return colors.bullish;
    if (weight >= 15) return theme === 'dark' ? '#f59e0b' : '#d97706';
    return colors.neutral;
  };

  return (
    <div 
      className={`reasoning-tree ${className}`}
      style={{
        backgroundColor: colors.background,
        borderColor: colors.grid,
        '--connector-color': colors.connector,
        '--text-color': colors.text
      }}
    >
      <div className="tree-header">
        <DecisionIcon className="header-icon" />
        <h3 className="title">AI Reasoning Tree</h3>
        <div className="decision-summary">
          <span className="direction">
            {getDirectionIcon(decision.direction)}
            <span 
              className="direction-label"
              style={{
                color: decision.direction === 'bullish' ? colors.bullish :
                       decision.direction === 'bearish' ? colors.bearish : colors.neutral
              }}
            >
              {decision.direction.toUpperCase()}
            </span>
          </span>
          <ConfidenceBadge 
            confidence={decision.confidence} 
            size="small" 
            showIcon={false}
          />
        </div>
      </div>

      <div className="tree-container">
        {/* Root Decision Node */}
        <div className="node root">
          <div 
            className="node-content"
            style={{
              backgroundColor: theme === 'dark' ? '#334155' : '#e2e8f0',
              borderColor: decision.direction === 'bullish' ? colors.bullish :
                          decision.direction === 'bearish' ? colors.bearish : colors.neutral
            }}
          >
            <div className="node-header">
              <span className="node-title">Final Decision</span>
              {getDirectionIcon(decision.direction)}
            </div>
            <div className="node-body">
              <div className="confidence-metric">
                <ConfidenceIcon className="metric-icon" />
                <span className="metric-value">{decision.confidence}%</span>
              </div>
              <div className="fusion-metric">
                <span className="metric-label">Fusion Score:</span>
                <span className="metric-value">{decision.fusionScore}/100</span>
              </div>
            </div>
          </div>
        </div>

        {/* Factors Level */}
        <div className="node-level factors">
          {decision.factors.map((factor, index) => (
            <React.Fragment key={`factor-${index}`}>
              <div className="tree-connector vertical" />
              <div className="node factor">
                <div 
                  className="node-content"
                  style={{
                    backgroundColor: theme === 'dark' ? '#334155' : '#e2e8f0',
                    borderColor: factor.direction === 'bullish' ? colors.bullish :
                                factor.direction === 'bearish' ? colors.bearish : colors.neutral
                  }}
                >
                  <div className="node-header">
                    <FactorIcon className="factor-icon" />
                    <span className="node-title">{factor.name}</span>
                    {getDirectionIcon(factor.direction)}
                  </div>
                  <div className="node-body">
                    <div className="factor-metrics">
                      <div className="metric weight">
                        <span 
                          className="metric-value"
                          style={{ color: getWeightColor(factor.weight) }}
                        >
                          {formatPercentage(factor.weight / 100)}
                        </span>
                        <span className="metric-label">Weight</span>
                      </div>
                      <div className="metric confidence">
                        <span className="metric-value">{factor.confidence}%</span>
                        <span className="metric-label">Confidence</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Subfactors Level */}
                {factor.subFactors && (
                  <div className="node-level subfactors">
                    {factor.subFactors.map((subFactor, subIndex) => (
                      <React.Fragment key={`subfactor-${subIndex}`}>
                        <div className="tree-connector vertical" />
                        <div className="node subfactor">
                          <div 
                            className="node-content"
                            style={{
                              backgroundColor: theme === 'dark' ? '#1e293b' : '#f8fafc',
                              borderColor: colors.grid
                            }}
                          >
                            <div className="node-header">
                              <span className="node-title">{subFactor.name}</span>
                              {getDirectionIcon(subFactor.direction)}
                            </div>
                            <div className="node-body">
                              <div className="subfactor-metrics">
                                <div className="metric">
                                  <span className="metric-value">
                                    {subFactor.confidence}%
                                  </span>
                                  <span className="metric-label">Confidence</span>
                                </div>
                                {subFactor.value && (
                                  <div className="metric">
                                    <span className="metric-value">
                                      {typeof subFactor.value === 'number' 
                                        ? subFactor.value.toFixed(4) 
                                        : subFactor.value}
                                    </span>
                                    <span className="metric-label">Value</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </React.Fragment>
                    ))}
                  </div>
                )}
              </div>
            </React.Fragment>
          ))}
        </div>
      </div>

      <div className="tree-legend">
        <div className="legend-item">
          <div 
            className="legend-color" 
            style={{ backgroundColor: colors.bullish }}
          />
          <span className="legend-label">Bullish Factors</span>
        </div>
        <div className="legend-item">
          <div 
            className="legend-color" 
            style={{ backgroundColor: colors.bearish }}
          />
          <span className="legend-label">Bearish Factors</span>
        </div>
        <div className="legend-item">
          <div 
            className="legend-color" 
            style={{ backgroundColor: colors.neutral }}
          />
          <span className="legend-label">Neutral Factors</span>
        </div>
      </div>
    </div>
  );
};

ReasoningTree.propTypes = {
  decision: PropTypes.shape({
    direction: PropTypes.oneOf(['bullish', 'bearish', 'neutral']).isRequired,
    confidence: PropTypes.number.isRequired,
    fusionScore: PropTypes.number.isRequired,
    factors: PropTypes.arrayOf(
      PropTypes.shape({
        name: PropTypes.string.isRequired,
        direction: PropTypes.oneOf(['bullish', 'bearish', 'neutral']).isRequired,
        weight: PropTypes.number.isRequired,
        confidence: PropTypes.number.isRequired,
        subFactors: PropTypes.arrayOf(
          PropTypes.shape({
            name: PropTypes.string.isRequired,
            direction: PropTypes.oneOf(['bullish', 'bearish', 'neutral']),
            confidence: PropTypes.number,
            value: PropTypes.oneOfType([PropTypes.number, PropTypes.string])
          })
        )
      })
    ).isRequired
  }).isRequired,
  className: PropTypes.string
};

export default ReasoningTree;