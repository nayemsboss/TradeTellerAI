// ui/dashboard/MarketWatchPanel/AdvancedChart.jsx
import React, { useEffect, useRef, useState } from 'react';
import { fetchChartData } from '../../../services/apiFetcher';
import { calculateSMA, calculateEMA } from '../../../utils/tradingMath';
import { formatTime } from '../../../utils/dateUtils';
import { ReactComponent as FullscreenIcon } from '../../../assets/icons/svg/fullscreen.svg';
import { ReactComponent as IndicatorIcon } from '../../../assets/icons/svg/indicators.svg';
import { ReactComponent as SettingsIcon } from '../../../assets/icons/svg/settings.svg';
import { useTheme } from '../../../constants/uiConstants';

/**
 * AdvancedChart component for displaying interactive price charts
 * @param {Object} props - Component props
 * @param {string} props.symbol - Trading symbol (e.g., 'EUR/USD')
 * @param {string} props.interval - Chart interval (e.g., '1min', '5min', '1h', '4h', '1d')
 * @param {number} [props.width=600] - Chart width in pixels
 * @param {number} [props.height=300] - Chart height in pixels
 */
const AdvancedChart = ({ symbol, interval = '5min', width = 600, height = 300 }) => {
  const [chartData, setChartData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [indicators, setIndicators] = useState({
    sma: false,
    ema: false,
    volume: true
  });
  const [timeRange, setTimeRange] = useState('4h');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const chartRef = useRef(null);
  const canvasRef = useRef(null);
  const theme = useTheme();
  
  // Fetch chart data when symbol, interval, or timeRange changes
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const data = await fetchChartData(symbol, interval, timeRange);
        
        // Calculate technical indicators if enabled
        if (indicators.sma) data.sma = calculateSMA(data.close, 20);
        if (indicators.ema) data.ema = calculateEMA(data.close, 20);
        
        setChartData(data);
        setError(null);
      } catch (err) {
        setError(`Failed to load chart data: ${err.message}`);
        console.error('Chart data error:', err);
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
    
    // Cleanup function
    return () => {
      // Cancel any pending requests or timeouts
    };
  }, [symbol, interval, timeRange, indicators.sma, indicators.ema]);
  
  // Draw chart when data changes
  useEffect(() => {
    if (!chartData || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    // Clear canvas
    ctx.clearRect(0, 0, width, height);
    
    // Chart drawing logic
    drawChart(ctx, chartData, {
      width,
      height,
      theme,
      indicators,
      timeFormat: interval === '1d' ? 'MMM dd' : 'HH:mm'
    });
    
  }, [chartData, width, height, theme, indicators, interval]);
  
  const toggleIndicator = (indicator) => {
    setIndicators(prev => ({
      ...prev,
      [indicator]: !prev[indicator]
    }));
  };
  
  const toggleFullscreen = () => {
    if (!isFullscreen) {
      chartRef.current.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
    setIsFullscreen(!isFullscreen);
  };
  
  if (error) return <div className="chart-error">{error}</div>;
  
  return (
    <div 
      className={`advanced-chart ${isFullscreen ? 'fullscreen' : ''}`}
      ref={chartRef}
      style={{ width: `${width}px`, height: `${height}px` }}
    >
      <div className="chart-controls">
        <div className="time-range-selector">
          {['1h', '4h', '1d', '1w', '1m'].map(range => (
            <button
              key={range}
              className={timeRange === range ? 'active' : ''}
              onClick={() => setTimeRange(range)}
            >
              {range}
            </button>
          ))}
        </div>
        
        <div className="indicator-controls">
          <button 
            className={indicators.sma ? 'active' : ''}
            onClick={() => toggleIndicator('sma')}
            title="Toggle SMA (20)"
          >
            <IndicatorIcon /> SMA
          </button>
          
          <button 
            className={indicators.ema ? 'active' : ''}
            onClick={() => toggleIndicator('ema')}
            title="Toggle EMA (20)"
          >
            <IndicatorIcon /> EMA
          </button>
          
          <button 
            className={indicators.volume ? 'active' : ''}
            onClick={() => toggleIndicator('volume')}
            title="Toggle Volume"
          >
            <IndicatorIcon /> Volume
          </button>
        </div>
        
        <button 
          className="fullscreen-toggle"
          onClick={toggleFullscreen}
          title={isFullscreen ? 'Exit fullscreen' : 'View fullscreen'}
        >
          <FullscreenIcon />
        </button>
      </div>
      
      {loading ? (
        <div className="chart-loading">
          <img 
            src={theme === 'dark' ? 
              '../../../assets/images/loading/spinner-dark.gif' : 
              '../../../assets/images/loading/spinner-light.gif'} 
            alt="Loading chart data"
          />
        </div>
      ) : (
        <canvas 
          ref={canvasRef}
          width={width}
          height={height}
          className="chart-canvas"
        />
      )}
      
      <div className="chart-footer">
        <span className="last-update">
          Last update: {chartData ? formatTime(chartData.timestamp[chartData.timestamp.length - 1]) : '--:--'}
        </span>
        <span className="current-price">
          {chartData?.close[chartData.close.length - 1]?.toFixed(5) || '----'}
        </span>
      </div>
    </div>
  );
};

// Helper function to draw the chart
const drawChart = (ctx, data, options) => {
  const { width, height, theme, indicators, timeFormat } = options;
  const { open, high, low, close, timestamp, volume } = data;
  const candleCount = open.length;
  
  // Chart dimensions and padding
  const padding = {
    top: 20,
    right: 40,
    bottom: 30,
    left: 60
  };
  
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;
  
  // Calculate price range
  const minPrice = Math.min(...low);
  const maxPrice = Math.max(...high);
  const priceRange = maxPrice - minPrice;
  
  // Calculate time range
  const timeRange = timestamp[timestamp.length - 1] - timestamp[0];
  
  // Set chart styles
  const styles = {
    background: theme === 'dark' ? '#1e293b' : '#f8fafc',
    grid: theme === 'dark' ? '#334155' : '#e2e8f0',
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    bullish: theme === 'dark' ? '#10b981' : '#059669',
    bearish: theme === 'dark' ? '#ef4444' : '#dc2626',
    volume: theme === 'dark' ? 'rgba(100, 116, 139, 0.5)' : 'rgba(203, 213, 225, 0.5)',
    indicator: theme === 'dark' ? '#f59e0b' : '#d97706'
  };
  
  // Draw background
  ctx.fillStyle = styles.background;
  ctx.fillRect(0, 0, width, height);
  
  // Draw grid lines
  ctx.strokeStyle = styles.grid;
  ctx.lineWidth = 0.5;
  
  // Horizontal grid lines (price levels)
  const priceSteps = 5;
  for (let i = 0; i <= priceSteps; i++) {
    const y = padding.top + (chartHeight - (chartHeight * (i / priceSteps)));
    ctx.beginPath();
    ctx.moveTo(padding.left, y);
    ctx.lineTo(width - padding.right, y);
    ctx.stroke();
    
    // Price labels
    const price = minPrice + (priceRange * (1 - i / priceSteps));
    ctx.fillStyle = styles.text;
    ctx.textAlign = 'right';
    ctx.fillText(price.toFixed(5), padding.left - 10, y + 4);
  }
  
  // Vertical grid lines (time markers)
  const timeSteps = 6;
  for (let i = 0; i <= timeSteps; i++) {
    const x = padding.left + (chartWidth * (i / timeSteps));
    ctx.beginPath();
    ctx.moveTo(x, padding.top);
    ctx.lineTo(x, height - padding.bottom);
    ctx.stroke();
    
    // Time labels
    const timeIndex = Math.floor((timestamp.length - 1) * (i / timeSteps));
    const timeLabel = formatTime(timestamp[timeIndex], timeFormat);
    ctx.fillStyle = styles.text;
    ctx.textAlign = 'center';
    ctx.fillText(timeLabel, x, height - padding.bottom + 20);
  }
  
  // Draw volume bars if enabled
  if (indicators.volume && volume) {
    const maxVolume = Math.max(...volume);
    const volumeHeightRatio = (chartHeight * 0.2) / maxVolume;
    
    for (let i = 0; i < candleCount; i++) {
      const x = padding.left + (i * (chartWidth / (candleCount - 1)));
      const barHeight = volume[i] * volumeHeightRatio;
      const isBullish = close[i] >= open[i];
      
      ctx.fillStyle = isBullish ? 
        `${styles.bullish}${theme === 'dark' ? '80' : '50'}` : 
        `${styles.bearish}${theme === 'dark' ? '80' : '50'}`;
      
      ctx.fillRect(
        x - (chartWidth / candleCount / 2) + 2,
        height - padding.bottom - barHeight,
        (chartWidth / candleCount) - 4,
        barHeight
      );
    }
  }
  
  // Draw candles
  const candleWidth = (chartWidth / candleCount) * 0.7;
  
  for (let i = 0; i < candleCount; i++) {
    const x = padding.left + (i * (chartWidth / (candleCount - 1)));
    const candleTop = padding.top + chartHeight - ((high[i] - minPrice) / priceRange * chartHeight);
    const candleBottom = padding.top + chartHeight - ((low[i] - minPrice) / priceRange * chartHeight);
    const openY = padding.top + chartHeight - ((open[i] - minPrice) / priceRange * chartHeight);
    const closeY = padding.top + chartHeight - ((close[i] - minPrice) / priceRange * chartHeight);
    
    const isBullish = close[i] >= open[i];
    ctx.strokeStyle = isBullish ? styles.bullish : styles.bearish;
    ctx.fillStyle = isBullish ? styles.bullish : styles.bearish;
    ctx.lineWidth = 1;
    
    // Draw wick
    ctx.beginPath();
    ctx.moveTo(x, candleTop);
    ctx.lineTo(x, candleBottom);
    ctx.stroke();
    
    // Draw candle body
    const bodyTop = Math.min(openY, closeY);
    const bodyHeight = Math.abs(openY - closeY);
    
    if (bodyHeight > 0) {
      ctx.fillRect(
        x - candleWidth / 2,
        bodyTop,
        candleWidth,
        bodyHeight
      );
    } else {
      // Draw line for doji candles
      ctx.beginPath();
      ctx.moveTo(x - candleWidth / 2, bodyTop);
      ctx.lineTo(x + candleWidth / 2, bodyTop);
      ctx.stroke();
    }
  }
  
  // Draw indicators if enabled
  if (indicators.sma && data.sma) {
    ctx.strokeStyle = styles.indicator;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    
    for (let i = 0; i < data.sma.length; i++) {
      const x = padding.left + (i * (chartWidth / (candleCount - 1)));
      const y = padding.top + chartHeight - ((data.sma[i] - minPrice) / priceRange * chartHeight);
      
      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    
    ctx.stroke();
  }
  
  if (indicators.ema && data.ema) {
    ctx.strokeStyle = '#8b5cf6';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    
    for (let i = 0; i < data.ema.length; i++) {
      const x = padding.left + (i * (chartWidth / (candleCount - 1)));
      const y = padding.top + chartHeight - ((data.ema[i] - minPrice) / priceRange * chartHeight);
      
      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    
    ctx.stroke();
  }
  
  // Draw chart border
  ctx.strokeStyle = styles.grid;
  ctx.lineWidth = 1;
  ctx.strokeRect(
    padding.left,
    padding.top,
    chartWidth,
    chartHeight
  );
};

export default AdvancedChart;