// ui/dashboard/MarketWatchPanel/MarketWatch.jsx
import React, { useState, useEffect } from 'react';
import { formatCurrency, formatPercentage } from '../../../utils/tradingMath';
import { getMarketSession } from '../../../utils/dateUtils';
import { useMarketData } from '../../../services/apiFetcher';
import SessionIndicator from './SessionIndicator';
import AdvancedChart from './AdvancedChart';
import { ReactComponent as AlertIcon } from '../../../assets/icons/svg/alertBell.svg';
import { ReactComponent as ChartIcon } from '../../../assets/icons/svg/chart.svg';
import { playAlertSound } from '../../../utils/audioFeedback';

/**
 * MarketWatch component displays real-time market data with advanced controls
 * @param {Object} props - Component props
 * @param {string} props.symbol - Default symbol to display (e.g., 'EUR/USD')
 * @param {function} props.onSymbolChange - Callback when symbol changes
 */
const MarketWatch = ({ symbol = 'EUR/USD', onSymbolChange }) => {
  const [activeSymbol, setActiveSymbol] = useState(symbol);
  const [showAdvancedChart, setShowAdvancedChart] = useState(false);
  const [priceAlert, setPriceAlert] = useState(null);
  const [range, setRange] = useState({ high: 0, low: 0 });
  
  // Fetch real-time market data
  const { data, loading, error } = useMarketData(activeSymbol, '1min');
  
  // Calculate session information
  const session = getMarketSession();
  
  useEffect(() => {
    if (data) {
      // Update price range when new data arrives
      setRange({
        high: Math.max(data.price, range.high || data.price),
        low: Math.min(data.price, range.low || data.price)
      });
      
      // Check for price alerts
      if (priceAlert && 
          ((priceAlert.direction === 'above' && data.price >= priceAlert.price) ||
          (priceAlert.direction === 'below' && data.price <= priceAlert.price))) {
        playAlertSound('price-alert');
      }
    }
  }, [data]);
  
  const handleSymbolChange = (newSymbol) => {
    setActiveSymbol(newSymbol);
    setRange({ high: 0, low: 0 });
    onSymbolChange?.(newSymbol);
  };
  
  const setAlert = (price, direction) => {
    setPriceAlert({ price, direction });
    playAlertSound('notification');
  };
  
  if (error) return <div className="market-watch-error">Error loading market data</div>;
  
  return (
    <div className="market-watch-panel">
      <div className="market-watch-header">
        <div className="symbol-selector">
          <select 
            value={activeSymbol}
            onChange={(e) => handleSymbolChange(e.target.value)}
            className="symbol-dropdown"
          >
            <option value="EUR/USD">EUR/USD</option>
            <option value="GBP/USD">GBP/USD</option>
            <option value="USD/JPY">USD/JPY</option>
            <option value="AUD/USD">AUD/USD</option>
            <option value="XAU/USD">XAU/USD (Gold)</option>
          </select>
          
          <span className="price-display">
            {loading ? 'Loading...' : formatCurrency(data?.price)}
            <span className={`price-change ${data?.change >= 0 ? 'positive' : 'negative'}`}>
              {data && `${data.change >= 0 ? '+' : ''}${formatPercentage(data.change)}`}
            </span>
          </span>
        </div>
        
        <div className="market-actions">
          <button 
            className="chart-toggle"
            onClick={() => setShowAdvancedChart(!showAdvancedChart)}
            aria-label="Toggle advanced chart"
          >
            <ChartIcon />
          </button>
          
          <button 
            className="alert-button"
            onClick={() => setAlert(data?.price, 'above')}
            aria-label="Set price alert"
          >
            <AlertIcon />
          </button>
        </div>
      </div>
      
      <div className="market-details">
        <div className="range-indicator">
          <span>Day Range: {formatCurrency(range.low)} - {formatCurrency(range.high)}</span>
          <span>Volatility: {data?.volatility || 'Medium'}</span>
        </div>
        
        <SessionIndicator session={session} />
      </div>
      
      {showAdvancedChart && (
        <div className="advanced-chart-container">
          <AdvancedChart symbol={activeSymbol} interval="5min" />
        </div>
      )}
      
      {priceAlert && (
        <div className="active-alert">
          Alert: Price {priceAlert.direction} {formatCurrency(priceAlert.price)}
        </div>
      )}
    </div>
  );
};

export default MarketWatch;