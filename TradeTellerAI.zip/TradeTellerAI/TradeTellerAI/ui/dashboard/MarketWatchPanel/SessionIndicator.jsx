// ui/dashboard/MarketWatchPanel/SessionIndicator.jsx
import React from 'react';
import { getMarketSession, getSessionProgress } from '../../../utils/dateUtils';
import { ReactComponent as LondonIcon } from '../../../assets/icons/svg/london.svg';
import { ReactComponent as NewYorkIcon } from '../../../assets/icons/svg/newyork.svg';
import { ReactComponent as TokyoIcon } from '../../../assets/icons/svg/tokyo.svg';
import { ReactComponent as SydneyIcon } from '../../../assets/icons/svg/sydney.svg';
import { useTheme } from '../../../constants/uiConstants';

/**
 * SessionIndicator component displays current market session and activity level
 * @param {Object} props - Component props
 * @param {string} [props.session] - Optional pre-determined session
 * @param {string} [props.className] - Additional CSS classes
 */
const SessionIndicator = ({ session, className = '' }) => {
  const theme = useTheme();
  const currentSession = session || getMarketSession();
  const progress = getSessionProgress(currentSession);
  const activityLevel = getActivityLevel(currentSession);
  
  const sessionIcons = {
    london: <LondonIcon className="session-icon" />,
    newyork: <NewYorkIcon className="session-icon" />,
    tokyo: <TokyoIcon className="session-icon" />,
    sydney: <SydneyIcon className="session-icon" />
  };
  
  const sessionNames = {
    london: 'London',
    newyork: 'New York',
    tokyo: 'Tokyo',
    sydney: 'Sydney',
    closed: 'Market Closed'
  };
  
  function getActivityLevel(session) {
    if (session === 'closed') return 'closed';
    
    const hour = new Date().getUTCHours();
    
    // Overlap periods have high activity
    if (
      (session === 'london' && hour >= 12 && hour < 16) || // London-NY overlap
      (session === 'newyork' && hour >= 13 && hour < 17)   // NY afternoon
    ) {
      return 'high';
    }
    
    // First/last hours of session
    if (
      (session === 'london' && (hour >= 7 && hour < 8 || hour >= 15 && hour < 16)) ||
      (session === 'newyork' && (hour >= 12 && hour < 13 || hour >= 19 && hour < 20)) ||
      (session === 'tokyo' && (hour >= 23 || hour < 2)) ||
      (session === 'sydney' && (hour >= 21 && hour < 23))
    ) {
      return 'medium';
    }
    
    return 'normal';
  }
  
  return (
    <div className={`session-indicator ${className} ${activityLevel}`}>
      <div className="session-header">
        {currentSession !== 'closed' ? (
          <>
            <span className="session-label">Active Session:</span>
            <span className="session-name">
              {sessionIcons[currentSession]}
              {sessionNames[currentSession]}
            </span>
          </>
        ) : (
          <span className="session-name closed">
            {sessionNames.closed}
          </span>
        )}
      </div>
      
      {currentSession !== 'closed' && (
        <div className="session-details">
          <div className="activity-level">
            <span className="label">Activity:</span>
            <span className={`level ${activityLevel}`}>
              {activityLevel === 'high' ? 'High' : 
               activityLevel === 'medium' ? 'Medium' : 'Normal'}
            </span>
          </div>
          
          <div className="session-progress">
            <div 
              className="progress-bar"
              style={{ width: `${progress}%` }}
              title={`${Math.round(progress)}% through session`}
            />
          </div>
        </div>
      )}
      
      {currentSession === 'closed' && (
        <div className="next-session">
          Next session: {getNextSession()}
        </div>
      )}
    </div>
  );
};

// Helper function to determine next session
function getNextSession() {
  const hour = new Date().getUTCHours();
  
  if (hour >= 0 && hour < 7) return 'Tokyo (Opens in ~1 hour)';
  if (hour >= 7 && hour < 12) return 'London (Opens in ~1 hour)';
  if (hour >= 12 && hour < 16) return 'New York (Opens in ~1 hour)';
  if (hour >= 16 && hour < 21) return 'Sydney (Opens in ~1 hour)';
  return 'London (Opens at 7:00 UTC)';
}

export default SessionIndicator;