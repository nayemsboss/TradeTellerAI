// ui/dashboard/TradePlanning/EntryZone.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as EntryIcon } from '../../../../assets/icons/svg/entry.svg';
import { ReactComponent as RangeIcon } from '../../../../assets/icons/svg/range.svg';
import { ReactComponent as FibonacciIcon } from '../../../../assets/icons/svg/fibonacci.svg';
import { useTheme } from '../../../../constants/uiConstants';
import { formatCurrency } from '../../../../utils/tradingMath';
import GaugeMeter from '../../widgets/GaugeMeter';

/**
 * EntryZone component displays optimal entry range with supporting technical levels
 * @param {Object} props - Component props
 * @param {Object} props.entryZone - Entry zone data object
 * @param {string} [props.symbol] - Trading symbol
 * @param {string} [props.timeframe] - Analysis timeframe
 * @param {string} [props.className] - Additional CSS classes
 */
const EntryZone = ({ entryZone, symbol = 'EUR/USD', timeframe = '4H', className = '' }) => {
  const theme = useTheme();

  // Color scheme based on theme
  const colors = {
    primary: theme === 'dark' ? '#3b82f6' : '#2563eb',
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b' : '#f8fafc',
    grid: theme === 'dark' ? '#334155' : '#e2e8f0',
    support: theme === 'dark' ? '#10b981' : '#059669',
    resistance: theme === 'dark' ? '#ef4444' : '#dc2626'
  };

  // Calculate width percentages for the range visualization
  const calculateLevelPosition = (price, min, max) => {
    return ((price - min) / (max - min)) * 100;
  };

  return (
    <div 
      className={`entry-zone ${className}`}
      style={{
        backgroundColor: colors.background,
        borderColor: colors.grid
      }}
    >
      <div className="header">
        <EntryIcon className="panel-icon" />
        <h3 className="title" style={{ color: colors.text }}>
          Optimal Entry Zone
        </h3>
        <span className="symbol-timeframe" style={{ color: colors.text }}>
          {symbol} ({timeframe})
        </span>
      </div>

      <div className="range-visualization">
        <div className="range-scale">
          <span className="min" style={{ color: colors.text }}>
            {formatCurrency(entryZone.range.low)}
          </span>
          <span className="max" style={{ color: colors.text }}>
            {formatCurrency(entryZone.range.high)}
          </span>
        </div>
        
        <div 
          className="range-track"
          style={{
            backgroundColor: theme === 'dark' ? '#334155' : '#e2e8f0'
          }}
        >
          {/* Current price indicator */}
          <div 
            className="current-price"
            style={{
              left: `${calculateLevelPosition(entryZone.currentPrice, entryZone.range.low, entryZone.range.high)}%`,
              backgroundColor: colors.primary
            }}
          >
            <span className="price-label" style={{ color: colors.text }}>
              Current: {formatCurrency(entryZone.currentPrice)}
            </span>
          </div>

          {/* Optimal entry zone */}
          <div 
            className="optimal-zone"
            style={{
              left: `${calculateLevelPosition(entryZone.optimalEntry.low, entryZone.range.low, entryZone.range.high)}%`,
              width: `${calculateLevelPosition(entryZone.optimalEntry.high, entryZone.range.low, entryZone.range.high) - 
                      calculateLevelPosition(entryZone.optimalEntry.low, entryZone.range.low, entryZone.range.high)}%`,
              backgroundColor: `${colors.primary}40`,
              borderColor: colors.primary
            }}
          >
            <span className="zone-label" style={{ color: colors.primary }}>
              {formatCurrency(entryZone.optimalEntry.low)} - {formatCurrency(entryZone.optimalEntry.high)}
            </span>
          </div>

          {/* Key support levels */}
          {entryZone.supports.map((support, index) => (
            <div
              key={`support-${index}`}
              className="support-level"
              style={{
                left: `${calculateLevelPosition(support.price, entryZone.range.low, entryZone.range.high)}%`,
                backgroundColor: colors.support
              }}
            >
              <span className="level-label" style={{ color: colors.text }}>
                S{index + 1}: {formatCurrency(support.price)}
              </span>
            </div>
          ))}

          {/* Key resistance levels */}
          {entryZone.resistances.map((resistance, index) => (
            <div
              key={`resistance-${index}`}
              className="resistance-level"
              style={{
                left: `${calculateLevelPosition(resistance.price, entryZone.range.low, entryZone.range.high)}%`,
                backgroundColor: colors.resistance
              }}
            >
              <span className="level-label" style={{ color: colors.text }}>
                R{index + 1}: {formatCurrency(resistance.price)}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="entry-details">
        <div className="detail-card">
          <div className="detail-header">
            <RangeIcon className="detail-icon" />
            <h4 className="detail-title" style={{ color: colors.text }}>
              Entry Zone Confidence
            </h4>
          </div>
          <GaugeMeter 
            value={entryZone.confidence} 
            color={colors.primary}
            size="small"
          />
          <div className="detail-value" style={{ color: colors.text }}>
            {entryZone.confidence}% Confidence
          </div>
          <div className="detail-description" style={{ color: colors.text }}>
            Based on confluence of {entryZone.confluenceFactors.join(', ')}
          </div>
        </div>

        <div className="detail-card">
          <div className="detail-header">
            <FibonacciIcon className="detail-icon" />
            <h4 className="detail-title" style={{ color: colors.text }}>
              Key Fibonacci Levels
            </h4>
          </div>
          <div className="fibonacci-levels">
            {entryZone.fibonacciLevels.map((level, index) => (
              <div key={`fib-${index}`} className="fib-level">
                <span className="fib-ratio" style={{ color: colors.text }}>
                  {level.ratio}%
                </span>
                <span className="fib-price" style={{ color: colors.text }}>
                  {formatCurrency(level.price)}
                </span>
                {level.isStrong && (
                  <span className="strong-marker" style={{ backgroundColor: colors.primary }} />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="detail-card">
          <div className="detail-header">
            <h4 className="detail-title" style={{ color: colors.text }}>
              Volume Profile
            </h4>
          </div>
          <div className="volume-profile">
            <div className="volume-indicator">
              <span className="label" style={{ color: colors.text }}>High Volume Node:</span>
              <span className="value" style={{ color: colors.text }}>
                {formatCurrency(entryZone.volumeProfile.highVolumeNode)}
              </span>
            </div>
            <div className="volume-indicator">
              <span className="label" style={{ color: colors.text }}>Volume at Zone:</span>
              <span className="value" style={{ color: colors.text }}>
                {formatPercentage(entryZone.volumeProfile.zoneVolume / 100)}
              </span>
            </div>
            <div className="volume-indicator">
              <span className="label" style={{ color: colors.text }}>POC:</span>
              <span className="value" style={{ color: colors.text }}>
                {formatCurrency(entryZone.volumeProfile.poc)}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="entry-strategy">
        <h4 className="strategy-title" style={{ color: colors.text }}>
          Suggested Entry Strategy
        </h4>
        <div className="strategy-steps">
          {entryZone.strategy.map((step, index) => (
            <div key={`step-${index}`} className="strategy-step">
              <div className="step-number" style={{ backgroundColor: colors.primary }}>
                {index + 1}
              </div>
              <p className="step-text" style={{ color: colors.text }}>
                {step}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

EntryZone.propTypes = {
  entryZone: PropTypes.shape({
    range: PropTypes.shape({
      low: PropTypes.number.isRequired,
      high: PropTypes.number.isRequired
    }).isRequired,
    currentPrice: PropTypes.number.isRequired,
    optimalEntry: PropTypes.shape({
      low: PropTypes.number.isRequired,
      high: PropTypes.number.isRequired
    }).isRequired,
    confidence: PropTypes.number.isRequired,
    confluenceFactors: PropTypes.arrayOf(PropTypes.string).isRequired,
    supports: PropTypes.arrayOf(
      PropTypes.shape({
        price: PropTypes.number.isRequired,
        strength: PropTypes.number.isRequired
      })
    ).isRequired,
    resistances: PropTypes.arrayOf(
      PropTypes.shape({
        price: PropTypes.number.isRequired,
        strength: PropTypes.number.isRequired
      })
    ).isRequired,
    fibonacciLevels: PropTypes.arrayOf(
      PropTypes.shape({
        ratio: PropTypes.number.isRequired,
        price: PropTypes.number.isRequired,
        isStrong: PropTypes.bool
      })
    ).isRequired,
    volumeProfile: PropTypes.shape({
      highVolumeNode: PropTypes.number.isRequired,
      zoneVolume: PropTypes.number.isRequired,
      poc: PropTypes.number.isRequired
    }).isRequired,
    strategy: PropTypes.arrayOf(PropTypes.string).isRequired
  }).isRequired,
  symbol: PropTypes.string,
  timeframe: PropTypes.string,
  className: PropTypes.string
};

export default EntryZone;