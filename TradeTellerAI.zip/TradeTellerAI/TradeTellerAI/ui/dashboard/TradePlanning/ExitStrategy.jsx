// ui/dashboard/TradePlanning/ExitStrategy.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as ExitIcon } from '../../../../assets/icons/svg/exit.svg';
import { ReactComponent as TargetIcon } from '../../../../assets/icons/svg/target.svg';
import { ReactComponent as StopLossIcon } from '../../../../assets/icons/svg/stopLoss.svg';
import { ReactComponent as RiskRewardIcon } from '../../../../assets/icons/svg/riskReward.svg';
import { useTheme } from '../../../../constants/uiConstants';
import { formatCurrency, formatPercentage } from '../../../../utils/tradingMath';
import GaugeMeter from '../../widgets/GaugeMeter';

/**
 * ExitStrategy component displays recommended exit points and risk management
 * @param {Object} props - Component props
 * @param {Object} props.strategy - Exit strategy data object
 * @param {string} [props.symbol] - Trading symbol
 * @param {string} [props.timeframe] - Analysis timeframe
 * @param {string} [props.className] - Additional CSS classes
 */
const ExitStrategy = ({ strategy, symbol = 'EUR/USD', timeframe = '4H', className = '' }) => {
  const theme = useTheme();

  // Color scheme based on theme
  const colors = {
    profit: theme === 'dark' ? '#10b981' : '#059669',
    loss: theme === 'dark' ? '#ef4444' : '#dc2626',
    primary: theme === 'dark' ? '#3b82f6' : '#2563eb',
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b' : '#f8fafc',
    grid: theme === 'dark' ? '#334155' : '#e2e8f0'
  };

  // Calculate percentage distance between prices
  const calculatePercentageDistance = (price1, price2) => {
    return Math.abs((price1 - price2) / price2) * 100;
  };

  return (
    <div 
      className={`exit-strategy ${className}`}
      style={{
        backgroundColor: colors.background,
        borderColor: colors.grid
      }}
    >
      <div className="header">
        <ExitIcon className="panel-icon" />
        <h3 className="title" style={{ color: colors.text }}>
          Exit Strategy
        </h3>
        <span className="symbol-timeframe" style={{ color: colors.text }}>
          {symbol} ({timeframe})
        </span>
      </div>

      <div className="strategy-overview">
        <div className="targets-container">
          <div className="targets-header">
            <TargetIcon className="targets-icon" />
            <h4 className="targets-title" style={{ color: colors.text }}>
              Take Profit Targets
            </h4>
          </div>
          
          <div className="target-levels">
            {strategy.takeProfits.map((target, index) => (
              <div 
                key={`target-${index}`} 
                className="target-level"
                style={{ borderColor: colors.profit }}
              >
                <div className="target-marker" style={{ backgroundColor: colors.profit }}>
                  TP{index + 1}
                </div>
                <div className="target-details">
                  <span className="target-price" style={{ color: colors.profit }}>
                    {formatCurrency(target.price)}
                  </span>
                  <span className="target-distance" style={{ color: colors.text }}>
                    ({formatPercentage(calculatePercentageDistance(target.price, strategy.entryPrice) / 100)})
                  </span>
                  {target.partialClose && (
                    <span className="partial-close" style={{ color: colors.text }}>
                      Close {formatPercentage(target.partialClose / 100)} position
                    </span>
                  )}
                  <div className="target-confluence">
                    <span className="label" style={{ color: colors.text }}>Based on:</span>
                    <span className="value" style={{ color: colors.text }}>{target.basis}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="stoploss-container">
          <div className="stoploss-header">
            <StopLossIcon className="stoploss-icon" />
            <h4 className="stoploss-title" style={{ color: colors.text }}>
              Stop Loss
            </h4>
          </div>
          
          <div 
            className="stoploss-level"
            style={{ borderColor: colors.loss }}
          >
            <div className="stoploss-marker" style={{ backgroundColor: colors.loss }}>
              SL
            </div>
            <div className="stoploss-details">
              <span className="stoploss-price" style={{ color: colors.loss }}>
                {formatCurrency(strategy.stopLoss.price)}
              </span>
              <span className="stoploss-distance" style={{ color: colors.text }}>
                ({formatPercentage(calculatePercentageDistance(strategy.stopLoss.price, strategy.entryPrice) / 100)})
              </span>
              <div className="stoploss-confluence">
                <span className="label" style={{ color: colors.text }}>Based on:</span>
                <span className="value" style={{ color: colors.text }}>{strategy.stopLoss.basis}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="risk-management">
        <div className="risk-header">
          <RiskRewardIcon className="risk-icon" />
          <h4 className="risk-title" style={{ color: colors.text }}>
            Risk Management
          </h4>
        </div>

        <div className="risk-metrics">
          <div className="metric">
            <div className="metric-value" style={{ color: colors.text }}>
              {strategy.riskReward.ratio.toFixed(2)}:1
            </div>
            <div className="metric-label" style={{ color: colors.text }}>
              Risk/Reward Ratio
            </div>
          </div>

          <div className="metric">
            <div className="metric-value" style={{ color: colors.text }}>
              {formatPercentage(strategy.riskReward.winProbability / 100)}
            </div>
            <div className="metric-label" style={{ color: colors.text }}>
              Win Probability
            </div>
          </div>

          <div className="metric">
            <div className="metric-value" style={{ color: colors.text }}>
              {formatPercentage(strategy.riskReward.riskPerTrade / 100)}
            </div>
            <div className="metric-label" style={{ color: colors.text }}>
              Risk Per Trade
            </div>
          </div>
        </div>

        <div className="risk-confidence">
          <span className="label" style={{ color: colors.text }}>Strategy Confidence:</span>
          <GaugeMeter 
            value={strategy.confidence} 
            color={strategy.confidence > 70 ? colors.profit : 
                  strategy.confidence < 30 ? colors.loss : colors.primary}
            size="small"
          />
          <span 
            className="confidence-value" 
            style={{ 
              color: strategy.confidence > 70 ? colors.profit : 
                    strategy.confidence < 30 ? colors.loss : colors.primary
            }}
          >
            {strategy.confidence}%
          </span>
        </div>
      </div>

      <div className="exit-tactics">
        <h4 className="tactics-title" style={{ color: colors.text }}>
          Exit Tactics
        </h4>
        <ul className="tactics-list">
          {strategy.tactics.map((tactic, index) => (
            <li key={`tactic-${index}`} className="tactic-item">
              <div className="tactic-marker" style={{ backgroundColor: colors.primary }}>
                {index + 1}
              </div>
              <p className="tactic-text" style={{ color: colors.text }}>
                {tactic}
              </p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

ExitStrategy.propTypes = {
  strategy: PropTypes.shape({
    entryPrice: PropTypes.number.isRequired,
    takeProfits: PropTypes.arrayOf(
      PropTypes.shape({
        price: PropTypes.number.isRequired,
        partialClose: PropTypes.number,
        basis: PropTypes.string.isRequired
      })
    ).isRequired,
    stopLoss: PropTypes.shape({
      price: PropTypes.number.isRequired,
      basis: PropTypes.string.isRequired
    }).isRequired,
    riskReward: PropTypes.shape({
      ratio: PropTypes.number.isRequired,
      winProbability: PropTypes.number.isRequired,
      riskPerTrade: PropTypes.number.isRequired
    }).isRequired,
    confidence: PropTypes.number.isRequired,
    tactics: PropTypes.arrayOf(PropTypes.string).isRequired
  }).isRequired,
  symbol: PropTypes.string,
  timeframe: PropTypes.string,
  className: PropTypes.string
};

export default ExitStrategy;