// ui/dashboard/TradePlanning/RiskCalculator.jsx
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as RiskIcon } from '../../../../assets/icons/svg/risk.svg';
import { ReactComponent as CalculatorIcon } from '../../../../assets/icons/svg/calculator.svg';
import { ReactComponent as WarningIcon } from '../../../../assets/icons/svg/warning.svg';
import { useTheme } from '../../../../constants/uiConstants';
import { formatCurrency, formatPercentage } from '../../../../utils/tradingMath';
import GaugeMeter from '../../widgets/GaugeMeter';

/**
 * RiskCalculator component for interactive risk management calculations
 * @param {Object} props - Component props
 * @param {Object} props.initialData - Initial risk calculation values
 * @param {function} props.onCalculate - Callback when calculations are updated
 * @param {string} [props.symbol] - Trading symbol
 * @param {string} [props.className] - Additional CSS classes
 */
const RiskCalculator = ({ initialData, onCalculate, symbol = 'EUR/USD', className = '' }) => {
  const theme = useTheme();
  const [riskData, setRiskData] = useState(initialData);
  const [isCustom, setIsCustom] = useState(false);

  // Color scheme based on theme
  const colors = {
    positive: theme === 'dark' ? '#10b981' : '#059669',
    negative: theme === 'dark' ? '#ef4444' : '#dc2626',
    primary: theme === 'dark' ? '#3b82f6' : '#2563eb',
    text: theme === 'dark' ? '#e2e8f0' : '#1e293b',
    background: theme === 'dark' ? '#1e293b' : '#f8fafc',
    inputBg: theme === 'dark' ? '#334155' : '#e2e8f0',
    border: theme === 'dark' ? '#475569' : '#cbd5e1'
  };

  // Calculate derived values whenever inputs change
  useEffect(() => {
    const calculated = calculateRisk(riskData);
    setRiskData(prev => ({ ...prev, ...calculated }));
    onCalculate(calculated);
  }, [riskData.accountSize, riskData.riskPercent, riskData.entryPrice, 
      riskData.stopLoss, riskData.positionSize, riskData.lotSize]);

  // Perform all risk calculations
  const calculateRisk = (data) => {
    const riskAmount = data.accountSize * (data.riskPercent / 100);
    const priceDistance = Math.abs(data.entryPrice - data.stopLoss);
    const pipsAtRisk = priceDistance * (symbol.includes('JPY') ? 100 : 10000);
    const calculatedPositionSize = riskAmount / (pipsAtRisk * data.lotSize);
    
    return {
      riskAmount,
      pipsAtRisk,
      positionSize: data.positionSize || calculatedPositionSize,
      dollarPerPip: (calculatedPositionSize * data.lotSize) / (symbol.includes('JPY') ? 100 : 10000)
    };
  };

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setRiskData(prev => ({
      ...prev,
      [name]: parseFloat(value) || 0
    }));
  };

  // Toggle between auto-calculated and manual position size
  const togglePositionSizeMode = () => {
    setIsCustom(!isCustom);
    if (!isCustom) {
      setRiskData(prev => ({
        ...prev,
        positionSize: calculateRisk(prev).positionSize
      }));
    }
  };

  // Get risk level assessment
  const getRiskLevel = () => {
    if (riskData.riskPercent > 2) return { level: 'High', color: colors.negative };
    if (riskData.riskPercent > 1) return { level: 'Moderate', color: theme === 'dark' ? '#f59e0b' : '#d97706' };
    return { level: 'Low', color: colors.positive };
  };

  const riskLevel = getRiskLevel();

  return (
    <div 
      className={`risk-calculator ${className}`}
      style={{
        backgroundColor: colors.background,
        borderColor: colors.border
      }}
    >
      <div className="header">
        <RiskIcon className="panel-icon" />
        <h3 className="title" style={{ color: colors.text }}>
          Risk Calculator
        </h3>
        <span className="symbol" style={{ color: colors.text }}>
          {symbol}
        </span>
      </div>

      <div className="calculator-grid">
        {/* Account Risk Section */}
        <div 
          className="risk-section account-risk"
          style={{ borderColor: colors.border }}
        >
          <div className="section-header">
            <CalculatorIcon className="section-icon" />
            <h4 className="section-title" style={{ color: colors.text }}>
              Account Risk
            </h4>
          </div>

          <div className="input-group">
            <label style={{ color: colors.text }}>Account Size:</label>
            <div className="input-wrapper">
              <span className="currency" style={{ color: colors.text }}>$</span>
              <input
                type="number"
                name="accountSize"
                value={riskData.accountSize}
                onChange={handleInputChange}
                style={{
                  backgroundColor: colors.inputBg,
                  color: colors.text,
                  borderColor: colors.border
                }}
              />
            </div>
          </div>

          <div className="input-group">
            <label style={{ color: colors.text }}>Risk Per Trade:</label>
            <div className="input-wrapper">
              <input
                type="number"
                name="riskPercent"
                value={riskData.riskPercent}
                onChange={handleInputChange}
                min="0.1"
                max="10"
                step="0.1"
                style={{
                  backgroundColor: colors.inputBg,
                  color: riskLevel.color,
                  borderColor: colors.border
                }}
              />
              <span className="percent" style={{ color: riskLevel.color }}>%</span>
            </div>
            <div className="risk-level" style={{ color: riskLevel.color }}>
              {riskLevel.level} Risk
            </div>
          </div>

          <div className="calculated-risk">
            <div className="calculated-value">
              <span className="label" style={{ color: colors.text }}>Risk Amount:</span>
              <span 
                className="value" 
                style={{ 
                  color: riskData.riskAmount > 0 ? colors.primary : colors.text 
                }}
              >
                ${formatCurrency(riskData.riskAmount)}
              </span>
            </div>
            <GaugeMeter 
              value={Math.min(riskData.riskPercent * 10, 100)} 
              color={riskLevel.color}
              size="small"
            />
          </div>
        </div>

        {/* Trade Parameters Section */}
        <div 
          className="risk-section trade-params"
          style={{ borderColor: colors.border }}
        >
          <div className="section-header">
            <h4 className="section-title" style={{ color: colors.text }}>
              Trade Parameters
            </h4>
          </div>

          <div className="input-row">
            <div className="input-group">
              <label style={{ color: colors.text }}>Entry Price:</label>
              <input
                type="number"
                name="entryPrice"
                value={riskData.entryPrice}
                onChange={handleInputChange}
                step="0.00001"
                style={{
                  backgroundColor: colors.inputBg,
                  color: colors.text,
                  borderColor: colors.border
                }}
              />
            </div>

            <div className="input-group">
              <label style={{ color: colors.text }}>Stop Loss:</label>
              <input
                type="number"
                name="stopLoss"
                value={riskData.stopLoss}
                onChange={handleInputChange}
                step="0.00001"
                style={{
                  backgroundColor: colors.inputBg,
                  color: colors.text,
                  borderColor: colors.border
                }}
              />
            </div>
          </div>

          <div className="calculated-metrics">
            <div className="metric">
              <span className="label" style={{ color: colors.text }}>Pips at Risk:</span>
              <span className="value" style={{ color: colors.primary }}>
                {formatCurrency(riskData.pipsAtRisk)}
              </span>
            </div>
            <div className="metric">
              <span className="label" style={{ color: colors.text }}>$ per Pip:</span>
              <span className="value" style={{ color: colors.primary }}>
                ${formatCurrency(riskData.dollarPerPip)}
              </span>
            </div>
          </div>
        </div>

        {/* Position Size Section */}
        <div 
          className="risk-section position-size"
          style={{ borderColor: colors.border }}
        >
          <div className="section-header">
            <h4 className="section-title" style={{ color: colors.text }}>
              Position Size
            </h4>
            <button 
              className="toggle-mode"
              onClick={togglePositionSizeMode}
              style={{
                backgroundColor: isCustom ? colors.primary : colors.inputBg,
                color: isCustom ? colors.background : colors.text
              }}
            >
              {isCustom ? 'Auto' : 'Manual'}
            </button>
          </div>

          <div className="input-group">
            <label style={{ color: colors.text }}>Lot Size:</label>
            <input
              type="number"
              name="lotSize"
              value={riskData.lotSize}
              onChange={handleInputChange}
              step="0.01"
              min="0.01"
              style={{
                backgroundColor: colors.inputBg,
                color: colors.text,
                borderColor: colors.border
              }}
            />
          </div>

          <div className="input-group">
            <label style={{ color: colors.text }}>Position Size:</label>
            <input
              type="number"
              name="positionSize"
              value={riskData.positionSize.toFixed(2)}
              onChange={handleInputChange}
              disabled={!isCustom}
              style={{
                backgroundColor: isCustom ? colors.inputBg : colors.background,
                color: colors.text,
                borderColor: colors.border
              }}
            />
          </div>

          <div className="size-equivalents">
            <div className="equivalent">
              <span className="label" style={{ color: colors.text }}>Standard Lots:</span>
              <span className="value" style={{ color: colors.text }}>
                {(riskData.positionSize / 1).toFixed(2)}
              </span>
            </div>
            <div className="equivalent">
              <span className="label" style={{ color: colors.text }}>Mini Lots:</span>
              <span className="value" style={{ color: colors.text }}>
                {(riskData.positionSize / 0.1).toFixed(2)}
              </span>
            </div>
            <div className="equivalent">
              <span className="label" style={{ color: colors.text }}>Micro Lots:</span>
              <span className="value" style={{ color: colors.text }}>
                {(riskData.positionSize / 0.01).toFixed(2)}
              </span>
            </div>
          </div>
        </div>

        {/* Risk Warnings Section */}
        <div 
          className="risk-section warnings"
          style={{ 
            backgroundColor: theme === 'dark' ? '#7f1d1d20' : '#fee2e2',
            borderColor: theme === 'dark' ? '#7f1d1d' : '#fecaca'
          }}
        >
          <div className="section-header">
            <WarningIcon className="warning-icon" />
            <h4 className="section-title" style={{ color: theme === 'dark' ? '#ef4444' : '#dc2626' }}>
              Risk Warnings
            </h4>
          </div>

          <div className="warning-message">
            {riskData.riskPercent > 2 && (
              <p style={{ color: theme === 'dark' ? '#ef4444' : '#dc2626' }}>
                <strong>Warning:</strong> Risking {riskData.riskPercent}% per trade is considered high risk. 
                Professional traders typically risk 1-2% per trade.
              </p>
            )}
            {riskData.positionSize > (riskData.accountSize / 10) && (
              <p style={{ color: theme === 'dark' ? '#ef4444' : '#dc2626' }}>
                <strong>Overexposure:</strong> This position size represents {formatPercentage(riskData.positionSize / riskData.accountSize * 100)} 
                of your account, which may be too large.
              </p>
            )}
            {riskData.riskPercent <= 2 && riskData.positionSize <= (riskData.accountSize / 10) && (
              <p style={{ color: theme === 'dark' ? '#10b981' : '#059669' }}>
                <strong>Good Practice:</strong> Your risk parameters are within recommended limits.
              </p>
            )}
          </div>

          <div className="risk-summary">
            <div className="summary-item">
              <span className="label" style={{ color: theme === 'dark' ? '#e2e8f0' : '#1e293b' }}>Max Loss:</span>
              <span className="value" style={{ color: theme === 'dark' ? '#ef4444' : '#dc2626' }}>
                ${formatCurrency(riskData.riskAmount)}
              </span>
            </div>
            <div className="summary-item">
              <span className="label" style={{ color: theme === 'dark' ? '#e2e8f0' : '#1e293b' }}>Account Impact:</span>
              <span className="value" style={{ color: theme === 'dark' ? '#e2e8f0' : '#1e293b' }}>
                {formatPercentage(riskData.riskPercent)}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

RiskCalculator.propTypes = {
  initialData: PropTypes.shape({
    accountSize: PropTypes.number.isRequired,
    riskPercent: PropTypes.number.isRequired,
    entryPrice: PropTypes.number.isRequired,
    stopLoss: PropTypes.number.isRequired,
    positionSize: PropTypes.number,
    lotSize: PropTypes.number.isRequired
  }).isRequired,
  onCalculate: PropTypes.func.isRequired,
  symbol: PropTypes.string,
  className: PropTypes.string
};

RiskCalculator.defaultProps = {
  initialData: {
    accountSize: 10000,
    riskPercent: 1,
    entryPrice: 1.0800,
    stopLoss: 1.0750,
    lotSize: 0.1,
    positionSize: 0
  }
};

export default RiskCalculator;