// ui/dashboard/TradingSignal/ConfidenceMeter.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../../../constants/uiConstants';
import { ReactComponent as ConfidenceIcon } from '../../../../assets/icons/svg/confidence.svg';

/**
 * ConfidenceMeter component visually displays AI confidence level
 * @param {Object} props - Component props
 * @param {number} props.level - Confidence level (1-5)
 * @param {string} [props.size] - Size variant ('small' | 'medium' | 'large')
 * @param {string} [props.className] - Additional CSS classes
 */
const ConfidenceMeter = ({ level, size = 'medium', className = '' }) => {
  const theme = useTheme();
  
  // Validate and clamp the confidence level
  const clampedLevel = Math.min(Math.max(level, 1), 5);
  
  // Size variants
  const sizes = {
    small: {
      width: 120,
      barHeight: 6,
      markerSize: 12,
      fontSize: 10
    },
    medium: {
      width: 160,
      barHeight: 8,
      markerSize: 16,
      fontSize: 12
    },
    large: {
      width: 200,
      barHeight: 10,
      markerSize: 20,
      fontSize: 14
    }
  };
  
  const { width, barHeight, markerSize, fontSize } = sizes[size];
  
  // Color scheme based on theme and confidence level
  const getColor = (segmentLevel) => {
    if (segmentLevel <= clampedLevel) {
      // Gradient from red to green based on confidence
      const hue = 120 * (segmentLevel / 5); // 0-120deg in HSL (red to green)
      return theme === 'dark' 
        ? `hsl(${hue}, 80%, 60%)` 
        : `hsl(${hue}, 80%, 45%)`;
    }
    return theme === 'dark' ? '#334155' : '#e2e8f0';
  };
  
  // Confidence labels
  const confidenceLabels = [
    'Very Low',
    'Low',
    'Medium',
    'High',
    'Very High'
  ];

  return (
    <div className={`confidence-meter ${size} ${className}`}>
      <div className="meter-header">
        <ConfidenceIcon className="icon" />
        <span className="title" style={{ fontSize: `${fontSize}px` }}>
          AI Confidence: {confidenceLabels[clampedLevel - 1]}
        </span>
      </div>
      
      <div 
        className="meter-bar"
        style={{
          width: `${width}px`,
          height: `${barHeight}px`,
          backgroundColor: theme === 'dark' ? '#334155' : '#e2e8f0'
        }}
      >
        {[1, 2, 3, 4, 5].map((segment) => (
          <div
            key={segment}
            className="meter-segment"
            style={{
              width: `${width / 5}px`,
              height: `${barHeight}px`,
              backgroundColor: getColor(segment)
            }}
          />
        ))}
        
        <div 
          className="meter-marker"
          style={{
            left: `${((clampedLevel - 1) * (width / 5)) + (width / 10)}px`,
            width: `${markerSize}px`,
            height: `${markerSize}px`,
            backgroundColor: getColor(clampedLevel),
            borderColor: theme === 'dark' ? '#1e293b' : '#f8fafc'
          }}
        />
      </div>
      
      <div className="meter-labels" style={{ width: `${width}px` }}>
        {[1, 2, 3, 4, 5].map((segment) => (
          <span 
            key={segment}
            className="meter-label"
            style={{
              width: `${width / 5}px`,
              fontSize: `${fontSize - 2}px`,
              color: segment <= clampedLevel 
                ? theme === 'dark' ? '#e2e8f0' : '#1e293b' 
                : theme === 'dark' ? '#64748b' : '#94a3b8'
            }}
          >
            {segment}
          </span>
        ))}
      </div>
    </div>
  );
};

ConfidenceMeter.propTypes = {
  level: PropTypes.number.isRequired,
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  className: PropTypes.string
};

export default ConfidenceMeter;