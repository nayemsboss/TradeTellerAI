// ui/dashboard/TradingSignal/SignalStrength.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as SignalIcon } from '../../../../assets/icons/svg/signal.svg';
import { useTheme } from '../../../../constants/uiConstants';

/**
 * SignalStrength component visually represents the strength of a trading signal
 * @param {Object} props - Component props
 * @param {number} props.strength - Signal strength (0-100)
 * @param {string} [props.type] - Signal type ('buy' | 'sell' | 'neutral')
 * @param {string} [props.size] - Size variant ('small' | 'medium' | 'large')
 * @param {boolean} [props.showValue] - Whether to show numeric value
 * @param {string} [props.className] - Additional CSS classes
 */
const SignalStrength = ({ 
  strength, 
  type = 'neutral', 
  size = 'medium', 
  showValue = true,
  className = '' 
}) => {
  const theme = useTheme();
  const clampedStrength = Math.min(Math.max(strength, 0), 100);
  
  // Size variants
  const sizes = {
    small: {
      width: 80,
      barHeight: 6,
      fontSize: 10,
      iconSize: 14
    },
    medium: {
      width: 120,
      barHeight: 8,
      fontSize: 12,
      iconSize: 18
    },
    large: {
      width: 160,
      barHeight: 10,
      fontSize: 14,
      iconSize: 22
    }
  };
  
  const { width, barHeight, fontSize, iconSize } = sizes[size];
  
  // Color scheme based on signal type and theme
  const getSignalColor = () => {
    if (type === 'buy') {
      return theme === 'dark' ? '#10b981' : '#059669'; // Green
    }
    if (type === 'sell') {
      return theme === 'dark' ? '#ef4444' : '#dc2626'; // Red
    }
    return theme === 'dark' ? '#3b82f6' : '#2563eb'; // Blue (neutral)
  };
  
  // Strength level classification
  const getStrengthLevel = () => {
    if (clampedStrength >= 80) return 'Very Strong';
    if (clampedStrength >= 60) return 'Strong';
    if (clampedStrength >= 40) return 'Moderate';
    if (clampedStrength >= 20) return 'Weak';
    return 'Very Weak';
  };
  
  // Segment colors for the strength meter
  const getSegmentColor = (segment) => {
    const segmentValue = segment * 20;
    if (clampedStrength >= segmentValue) {
      return getSignalColor();
    }
    return theme === 'dark' ? '#334155' : '#e2e8f0';
  };
  
  return (
    <div className={`signal-strength ${type} ${size} ${className}`}>
      <div className="signal-header">
        <SignalIcon 
          className="signal-icon" 
          style={{ 
            width: `${iconSize}px`,
            height: `${iconSize}px`,
            color: getSignalColor()
          }} 
        />
        <span 
          className="signal-label"
          style={{
            fontSize: `${fontSize}px`,
            color: theme === 'dark' ? '#e2e8f0' : '#1e293b'
          }}
        >
          Signal Strength: {getStrengthLevel()}
        </span>
      </div>
      
      <div className="signal-meter">
        <div 
          className="meter-background"
          style={{
            width: `${width}px`,
            height: `${barHeight}px`,
            backgroundColor: theme === 'dark' ? '#334155' : '#e2e8f0'
          }}
        >
          {[1, 2, 3, 4, 5].map((segment) => (
            <div
              key={segment}
              className="meter-segment"
              style={{
                width: `${width / 5}px`,
                height: `${barHeight}px`,
                backgroundColor: getSegmentColor(segment)
              }}
            />
          ))}
        </div>
        
        {showValue && (
          <div 
            className="strength-value"
            style={{
              fontSize: `${fontSize}px`,
              color: getSignalColor()
            }}
          >
            {clampedStrength}%
          </div>
        )}
      </div>
    </div>
  );
};

SignalStrength.propTypes = {
  strength: PropTypes.number.isRequired,
  type: PropTypes.oneOf(['buy', 'sell', 'neutral']),
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  showValue: PropTypes.bool,
  className: PropTypes.string
};

export default SignalStrength;