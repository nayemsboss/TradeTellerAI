// ui/dashboard/TradingSignal/ValidUntil.jsx
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { ReactComponent as ClockIcon } from '../../../../assets/icons/svg/clock.svg';
import { formatTimeRemaining, formatExpirationTime } from '../../../../utils/dateUtils';
import { useTheme } from '../../../../constants/uiConstants';

/**
 * ValidUntil component displays signal expiration time with countdown
 * @param {Object} props - Component props
 * @param {string|Date} props.expiration - Expiration timestamp
 * @param {boolean} [props.showCountdown] - Whether to show live countdown
 * @param {string} [props.size] - Size variant ('compact' | 'normal')
 * @param {string} [props.className] - Additional CSS classes
 */
const ValidUntil = ({ expiration, showCountdown = true, size = 'normal', className = '' }) => {
  const theme = useTheme();
  const [timeRemaining, setTimeRemaining] = useState('');
  
  // Update countdown every second if showCountdown is true
  useEffect(() => {
    if (!showCountdown || !expiration) return;
    
    const updateCountdown = () => {
      const remaining = formatTimeRemaining(expiration);
      setTimeRemaining(remaining);
    };
    
    // Initial update
    updateCountdown();
    
    // Set up interval for live updates
    const intervalId = setInterval(updateCountdown, 1000);
    
    // Clean up interval on unmount
    return () => clearInterval(intervalId);
  }, [expiration, showCountdown]);
  
  // Color becomes red when less than 5 minutes remain
  const isExpiringSoon = () => {
    if (!expiration || !showCountdown) return false;
    const expirationDate = new Date(expiration);
    const now = new Date();
    return (expirationDate - now) < (5 * 60 * 1000); // 5 minutes in ms
  };
  
  const expirationColor = isExpiringSoon() 
    ? (theme === 'dark' ? '#ef4444' : '#dc2626') 
    : (theme === 'dark' ? '#e2e8f0' : '#1e293b');
  
  return (
    <div className={`valid-until ${size} ${className}`}>
      <div className="valid-until-container">
        <ClockIcon 
          className="clock-icon" 
          style={{ color: expirationColor }}
        />
        
        <div className="time-display">
          <span 
            className="label"
            style={{ color: theme === 'dark' ? '#94a3b8' : '#64748b' }}
          >
            Valid {showCountdown ? 'for' : 'until'}:
          </span>
          
          <span 
            className="time-value"
            style={{ color: expirationColor }}
          >
            {showCountdown ? timeRemaining : formatExpirationTime(expiration)}
          </span>
        </div>
      </div>
      
      {size === 'normal' && (
        <div 
          className="expiration-bar"
          style={{
            backgroundColor: theme === 'dark' ? '#334155' : '#e2e8f0'
          }}
        >
          <div 
            className="progress"
            style={{
              width: isExpiringSoon() ? '100%' : '50%',
              backgroundColor: expirationColor,
              animation: isExpiringSoon() ? 'pulse 2s infinite' : 'none'
            }}
          />
        </div>
      )}
    </div>
  );
};

ValidUntil.propTypes = {
  expiration: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Date)
  ]).isRequired,
  showCountdown: PropTypes.bool,
  size: PropTypes.oneOf(['compact', 'normal']),
  className: PropTypes.string
};

export default ValidUntil;