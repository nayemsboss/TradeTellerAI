// ui/widgets/AnimatedArrow.jsx
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../services/themeContext';
import { motion } from 'framer-motion';

/**
 * Animated Arrow Component for Market Direction Visualization
 * Shows price movement direction with dynamic animations and colors
 */
const AnimatedArrow = ({
  direction = 'up', // 'up', 'down', or 'neutral'
  size = 'medium', // 'small', 'medium', 'large'
  intensity = 0, // 0-100 for animation intensity
  label = '',
  pulseOnChange = true,
  showPulse = true,
}) => {
  const { theme } = useTheme();
  const [prevDirection, setPrevDirection] = useState(direction);
  const [isAnimating, setIsAnimating] = useState(false);

  // Arrow colors based on direction
  const arrowColors = {
    up: theme.success,
    down: theme.error,
    neutral: theme.warning,
  };

  // Size presets
  const sizePresets = {
    small: {
      width: 16,
      height: 16,
      strokeWidth: 2,
      fontSize: '0.75rem',
    },
    medium: {
      width: 24,
      height: 24,
      strokeWidth: 2.5,
      fontSize: '1rem',
    },
    large: {
      width: 32,
      height: 32,
      strokeWidth: 3,
      fontSize: '1.25rem',
    },
  };

  const { width, height, strokeWidth, fontSize } = sizePresets[size];

  // Arrow path definitions
  const arrowPaths = {
    up: `M${width / 2} ${height * 0.2} L${width * 0.2} ${height * 0.8} L${width * 0.8} ${height * 0.8} Z`,
    down: `M${width / 2} ${height * 0.8} L${width * 0.2} ${height * 0.2} L${width * 0.8} ${height * 0.2} Z`,
    neutral: `M${width * 0.2} ${height / 2} H${width * 0.8} M${width / 2} ${height * 0.2} V${height * 0.8}`,
  };

  // Animation variants
  const arrowVariants = {
    up: {
      scale: [1, 1.1, 1],
      y: [0, -3, 0],
      transition: {
        duration: 0.6 * (intensity / 100),
        ease: 'easeOut',
      },
    },
    down: {
      scale: [1, 1.1, 1],
      y: [0, 3, 0],
      transition: {
        duration: 0.6 * (intensity / 100),
        ease: 'easeOut',
      },
    },
    neutral: {
      rotate: [0, 5, -5, 0],
      transition: {
        duration: 0.8 * (intensity / 100),
        ease: 'easeInOut',
      },
    },
  };

  const pulseVariants = {
    visible: {
      opacity: [0.6, 0],
      scale: [1, 1.5],
      transition: {
        duration: 1.2 * (intensity / 100),
        repeat: Infinity,
        ease: 'easeOut',
      },
    },
    hidden: {
      opacity: 0,
      scale: 1,
    },
  };

  // Trigger animation when direction changes
  useEffect(() => {
    if (direction !== prevDirection && pulseOnChange) {
      setIsAnimating(true);
      const timer = setTimeout(() => setIsAnimating(false), 600);
      setPrevDirection(direction);
      return () => clearTimeout(timer);
    }
  }, [direction, prevDirection, pulseOnChange]);

  return (
    <div
      className="animated-arrow-container"
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        width: `${width}px`,
        height: `${height}px`,
      }}
    >
      {/* Pulse effect */}
      {showPulse && (
        <motion.div
          className="arrow-pulse"
          style={{
            position: 'absolute',
            width: '100%',
            height: '100%',
            borderRadius: '50%',
            backgroundColor: arrowColors[direction],
            zIndex: 0,
          }}
          variants={pulseVariants}
          animate={isAnimating ? 'visible' : 'hidden'}
        />
      )}

      {/* Main arrow */}
      <motion.svg
        width={width}
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        style={{
          zIndex: 1,
          filter: `drop-shadow(0 2px 4px ${theme.shadow})`,
        }}
        variants={arrowVariants}
        animate={direction}
        whileHover={{ scale: 1.1 }}
      >
        <path
          d={arrowPaths[direction]}
          fill={direction === 'neutral' ? 'none' : arrowColors[direction]}
          stroke={arrowColors[direction]}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </motion.svg>

      {/* Optional label */}
      {label && (
        <span
          style={{
            color: theme.textSecondary,
            fontSize,
            marginTop: height * 0.2,
            fontWeight: 500,
          }}
        >
          {label}
        </span>
      )}
    </div>
  );
};

AnimatedArrow.propTypes = {
  direction: PropTypes.oneOf(['up', 'down', 'neutral']),
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  intensity: PropTypes.number,
  label: PropTypes.string,
  pulseOnChange: PropTypes.bool,
  showPulse: PropTypes.bool,
};

export default AnimatedArrow;