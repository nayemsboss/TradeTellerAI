// ui/widgets/ConfidenceBar.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../services/themeContext';
import { motion } from 'framer-motion';

/**
 * Animated Confidence Bar Component
 * Visually represents confidence levels with dynamic coloring and effects
 */
const ConfidenceBar = ({
  confidence, // 0-100
  width = 200,
  height = 24,
  showLabel = true,
  showPercentage = true,
  showThresholds = true,
  animationDuration = 800,
  labelPosition = 'left', // 'left', 'right', 'top', 'bottom'
  style = 'rounded', // 'rounded', 'sharp', 'gradient'
}) => {
  const { theme } = useTheme();
  const clampedConfidence = Math.min(Math.max(confidence, 0), 100);

  // Threshold configuration
  const thresholds = {
    low: 30,
    medium: 70,
    high: 90,
  };

  // Determine color based on confidence level
  const getBarColor = () => {
    if (clampedConfidence < thresholds.low) {
      return theme.error; // Red
    } else if (clampedConfidence < thresholds.medium) {
      return theme.warning; // Yellow
    } else {
      return theme.success; // Green
    }
  };

  // Bar style configurations
  const barStyles = {
    rounded: {
      borderRadius: height / 2,
      innerRadius: height / 2 - 2,
    },
    sharp: {
      borderRadius: 0,
      innerRadius: 0,
    },
    gradient: {
      borderRadius: height / 2,
      innerRadius: height / 2 - 2,
      background: `linear-gradient(90deg, ${theme.error} 0%, ${theme.warning} 50%, ${theme.success} 100%)`,
    },
  };

  // Animation variants
  const barVariants = {
    initial: { width: 0 },
    animate: {
      width: `${clampedConfidence}%`,
      transition: {
        duration: animationDuration / 1000,
        ease: "easeOut",
      },
    },
  };

  // Label positioning
  const labelPositions = {
    left: { flexDirection: 'row', labelMargin: '0 12px 0 0' },
    right: { flexDirection: 'row', labelMargin: '0 0 0 12px' },
    top: { flexDirection: 'column', labelMargin: '0 0 8px 0' },
    bottom: { flexDirection: 'column', labelMargin: '8px 0 0 0' },
  };

  return (
    <div
      className="confidence-bar-container"
      style={{
        display: 'flex',
        ...labelPositions[labelPosition],
        alignItems: 'center',
        width: labelPosition === 'top' || labelPosition === 'bottom' ? 'auto' : width,
      }}
    >
      {showLabel && (
        <div
          className="confidence-label"
          style={{
            margin: labelPositions[labelPosition].labelMargin,
            color: theme.textSecondary,
            fontSize: height * 0.7,
            minWidth: height * 3,
          }}
        >
          Confidence
        </div>
      )}

      <div
        className="confidence-track"
        style={{
          position: 'relative',
          width: '100%',
          height,
          backgroundColor: theme.backgroundTertiary,
          borderRadius: barStyles[style].borderRadius,
          overflow: 'hidden',
          boxShadow: `inset 0 1px 3px ${theme.shadow}`,
        }}
      >
        {/* Background track */}
        {showThresholds && (
          <>
            <div
              style={{
                position: 'absolute',
                left: `${thresholds.low}%`,
                width: `${thresholds.medium - thresholds.low}%`,
                height: '100%',
                backgroundColor: `${theme.warning}20`,
                zIndex: 1,
              }}
            />
            <div
              style={{
                position: 'absolute',
                left: `${thresholds.medium}%`,
                width: `${thresholds.high - thresholds.medium}%`,
                height: '100%',
                backgroundColor: `${theme.success}20`,
                zIndex: 1,
              }}
            />
          </>
        )}

        {/* Animated confidence bar */}
        <motion.div
          className="confidence-fill"
          initial="initial"
          animate="animate"
          variants={barVariants}
          style={{
            position: 'relative',
            height: '100%',
            backgroundColor: style === 'gradient' ? undefined : getBarColor(),
            background: style === 'gradient' ? barStyles.gradient.background : undefined,
            borderRadius: barStyles[style].innerRadius,
            zIndex: 2,
          }}
        >
          {/* Percentage label inside bar */}
          {showPercentage && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: animationDuration / 1000 }}
              style={{
                position: 'absolute',
                right: 8,
                top: '50%',
                transform: 'translateY(-50%)',
                color: clampedConfidence > 50 ? theme.textInverted : theme.textPrimary,
                fontSize: height * 0.6,
                fontWeight: 'bold',
                textShadow: `0 1px 2px ${theme.shadow}`,
              }}
            >
              {clampedConfidence}%
            </motion.div>
          )}
        </motion.div>

        {/* Threshold markers */}
        {showThresholds && (
          <div
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '100%',
              display: 'flex',
              zIndex: 3,
              pointerEvents: 'none',
            }}
          >
            {Object.entries(thresholds).map(([name, value]) => (
              <div
                key={name}
                style={{
                  position: 'absolute',
                  left: `${value}%`,
                  width: 2,
                  height: '100%',
                  backgroundColor: theme.border,
                }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

ConfidenceBar.propTypes = {
  confidence: PropTypes.number.isRequired,
  width: PropTypes.number,
  height: PropTypes.number,
  showLabel: PropTypes.bool,
  showPercentage: PropTypes.bool,
  showThresholds: PropTypes.bool,
  animationDuration: PropTypes.number,
  labelPosition: PropTypes.oneOf(['left', 'right', 'top', 'bottom']),
  style: PropTypes.oneOf(['rounded', 'sharp', 'gradient']),
};

export default ConfidenceBar;