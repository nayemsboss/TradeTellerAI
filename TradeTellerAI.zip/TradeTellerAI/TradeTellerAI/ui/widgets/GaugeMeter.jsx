// ui/widgets/GaugeMeter.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../services/themeContext';
import { calculateGradient } from '../../utils/tradingMath';

/**
 * Interactive Gauge Meter Component for Trading Dashboard
 * Displays metrics with dynamic coloring and animations
 */
const GaugeMeter = ({
  value,
  min = 0,
  max = 100,
  label,
  unit = '%',
  width = 200,
  height = 120,
  showThresholds = true,
  animationDuration = 1000,
}) => {
  const { theme } = useTheme();
  const safeValue = Math.min(Math.max(value, min), max);
  const percentage = ((safeValue - min) / (max - min)) * 100;

  // Calculate dynamic colors based on value
  const { gradientId, needleColor } = calculateGradient(
    percentage,
    theme
  );

  // Gauge dimensions
  const centerX = width / 2;
  const centerY = height;
  const radius = width * 0.4;
  const startAngle = 180;
  const endAngle = 0;
  const arcLength = endAngle - startAngle;
  const needleRotation = startAngle + (percentage / 100) * arcLength;

  // Calculate threshold markers
  const thresholdAngles = showThresholds
    ? {
        low: startAngle + 0.25 * arcLength,
        medium: startAngle + 0.5 * arcLength,
        high: startAngle + 0.75 * arcLength,
      }
    : null;

  // Generate path for the gauge arc
  const getArcPath = () => {
    const startRad = (startAngle * Math.PI) / 180;
    const endRad = (endAngle * Math.PI) / 180;
    const x1 = centerX + radius * Math.cos(startRad);
    const y1 = centerY + radius * Math.sin(startRad);
    const x2 = centerX + radius * Math.cos(endRad);
    const y2 = centerY + radius * Math.sin(endRad);

    return `M ${x1} ${y1} A ${radius} ${radius} 0 0 1 ${x2} ${y2}`;
  };

  // Needle path
  const needleLength = radius * 0.9;
  const needleBaseWidth = radius * 0.1;
  const needlePath = `
    M ${centerX} ${centerY - needleBaseWidth / 2}
    L ${centerX + needleLength} ${centerY}
    L ${centerX} ${centerY + needleBaseWidth / 2}
    Z
  `;

  return (
    <div
      className="gauge-container"
      style={{
        width: `${width}px`,
        height: `${height}px`,
        position: 'relative',
      }}
    >
      <svg
        width={width}
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        className="gauge-svg"
      >
        {/* Gradient-filled gauge arc */}
        <defs>
          <linearGradient
            id={gradientId}
            x1="0%"
            y1="0%"
            x2="100%"
            y2="0%"
          >
            <stop offset="0%" stopColor="#ff3d3d" />
            <stop offset="50%" stopColor="#ffcc00" />
            <stop offset="100%" stopColor="#4caf50" />
          </linearGradient>
        </defs>

        {/* Background arc */}
        <path
          d={getArcPath()}
          stroke="#e0e0e0"
          strokeWidth={radius * 0.2}
          fill="none"
          strokeLinecap="round"
        />

        {/* Colored value arc */}
        <path
          d={getArcPath()}
          stroke={`url(#${gradientId})`}
          strokeWidth={radius * 0.2}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={`${percentage} 100`}
          style={{
            transition: `stroke-dasharray ${animationDuration}ms ease-out`,
          }}
        />

        {/* Threshold markers */}
        {showThresholds && thresholdAngles && (
          <>
            <g className="threshold-markers">
              {Object.entries(thresholdAngles).map(
                ([name, angle]) => {
                  const rad = (angle * Math.PI) / 180;
                  const x = centerX + radius * Math.cos(rad);
                  const y = centerY + radius * Math.sin(rad);
                  return (
                    <circle
                      key={name}
                      cx={x}
                      cy={y}
                      r={radius * 0.05}
                      fill="#fff"
                      stroke="#666"
                      strokeWidth="1"
                    />
                  );
                }
              )}
            </g>
            <g className="threshold-labels">
              {Object.entries(thresholdAngles).map(
                ([name, angle]) => {
                  const rad = (angle * Math.PI) / 180;
                  const x = centerX + (radius * 1.1) * Math.cos(rad);
                  const y = centerY + (radius * 1.1) * Math.sin(rad);
                  return (
                    <text
                      key={`label-${name}`}
                      x={x}
                      y={y}
                      textAnchor="middle"
                      dominantBaseline="middle"
                      fill={theme.textSecondary}
                      fontSize={radius * 0.08}
                    >
                      {name.charAt(0).toUpperCase() + name.slice(1)}
                    </text>
                  );
                }
              )}
            </g>
          </>
        )}

        {/* Needle */}
        <path
          d={needlePath}
          fill={needleColor}
          transform={`rotate(${needleRotation} ${centerX} ${centerY})`}
          style={{
            transformOrigin: `${centerX}px ${centerY}px`,
            transition: `transform ${animationDuration}ms ease-out`,
          }}
        />

        {/* Center circle */}
        <circle
          cx={centerX}
          cy={centerY}
          r={radius * 0.08}
          fill="#333"
        />

        {/* Value display */}
        <text
          x={centerX}
          y={centerY * 0.6}
          textAnchor="middle"
          dominantBaseline="middle"
          fill={theme.textPrimary}
          fontSize={radius * 0.25}
          fontWeight="bold"
        >
          {Math.round(value)}
          {unit}
        </text>

        {/* Label */}
        <text
          x={centerX}
          y={centerY * 0.8}
          textAnchor="middle"
          dominantBaseline="middle"
          fill={theme.textSecondary}
          fontSize={radius * 0.1}
        >
          {label}
        </text>
      </svg>
    </div>
  );
};

GaugeMeter.propTypes = {
  value: PropTypes.number.isRequired,
  min: PropTypes.number,
  max: PropTypes.number,
  label: PropTypes.string.isRequired,
  unit: PropTypes.string,
  width: PropTypes.number,
  height: PropTypes.number,
  showThresholds: PropTypes.bool,
  animationDuration: PropTypes.number,
};

export default GaugeMeter;