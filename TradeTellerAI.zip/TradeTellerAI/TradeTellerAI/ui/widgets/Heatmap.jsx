// ui/widgets/Heatmap.jsx
import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../services/themeContext';
import { scaleLinear } from 'd3-scale';
import { format } from 'd3-format';
import { interpolateRgb } from 'd3-interpolate';

/**
 * Interactive Trading Heatmap Component
 * Visualizes market data intensity, correlations, and performance metrics
 */
const Heatmap = ({
  data,
  width = 600,
  height = 400,
  cellSize = 40,
  margin = { top: 30, right: 20, bottom: 60, left: 60 },
  colorRange = ['#2c7bb6', '#ffff8c', '#d7191c'], // Blue-Yellow-Red
  showValues = true,
  showAxis = true,
  showLegend = true,
  onCellClick,
}) => {
  const { theme } = useTheme();

  // Calculate dimensions
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;
  const numCols = Math.floor(innerWidth / cellSize);
  const numRows = Math.floor(innerHeight / cellSize);

  // Process data and create color scale
  const { processedData, colorScale } = useMemo(() => {
    if (!data || !data.length) return { processedData: [], colorScale: null };

    // Flatten and normalize data
    const flatData = data.flat();
    const minValue = Math.min(...flatData.map(d => d.value));
    const maxValue = Math.max(...flatData.map(d => d.value));
    const absMax = Math.max(Math.abs(minValue), Math.abs(maxValue));

    // Create color scale
    const colorInterpolator = interpolateRgb(colorRange[0], colorRange[1], colorRange[2]);
    const colorScale = scaleLinear()
      .domain([-absMax, 0, absMax])
      .range([colorRange[0], colorRange[1], colorRange[2]]);

    // Process data with normalized values
    const processedData = data.map((row, rowIndex) =>
      row.map((cell, colIndex) => ({
        ...cell,
        normalizedValue: cell.value / absMax,
        color: colorScale(cell.value),
        x: colIndex * cellSize,
        y: rowIndex * cellSize,
        row: rowIndex,
        col: colIndex,
      }))
    );

    return { processedData, colorScale, minValue, maxValue, absMax };
  }, [data, colorRange]);

  // Generate legend gradient
  const legendGradient = `linear-gradient(to right, ${colorRange.join(', ')})`;

  // Formatting functions
  const formatValue = format('.2f');
  const formatPercent = format('.1%');

  // Handle cell click
  const handleCellClick = (cellData) => {
    if (onCellClick) onCellClick(cellData);
  };

  return (
    <div className="heatmap-container" style={{ width, height, position: 'relative' }}>
      <svg width={width} height={height}>
        {/* Background */}
        <rect width={width} height={height} fill={theme.backgroundSecondary} rx="4" />

        {/* Main heatmap group */}
        <g transform={`translate(${margin.left},${margin.top})`}>
          {/* Cells */}
          {processedData.map((row, rowIndex) =>
            row.map((cell, colIndex) => (
              <g
                key={`${rowIndex}-${colIndex}`}
                transform={`translate(${cell.x},${cell.y})`}
                onClick={() => handleCellClick(cell)}
                style={{ cursor: 'pointer' }}
              >
                <rect
                  width={cellSize - 2}
                  height={cellSize - 2}
                  rx="2"
                  fill={cell.color}
                  stroke={theme.border}
                  strokeWidth="0.5"
                />
                {showValues && (
                  <text
                    x={cellSize / 2}
                    y={cellSize / 2}
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fill={
                      Math.abs(cell.normalizedValue) > 0.6
                        ? theme.textInverted
                        : theme.textPrimary
                    }
                    fontSize={cellSize * 0.3}
                    fontWeight="500"
                  >
                    {formatValue(cell.value)}
                  </text>
                )}
                <title>
                  {`${cell.label || `Row ${rowIndex + 1}, Col ${colIndex + 1}`}\nValue: ${cell.value}\n(${formatPercent(cell.normalizedValue)})`}
                </title>
              </g>
            ))
          )}

          {/* X Axis */}
          {showAxis && processedData[0] && (
            <g transform={`translate(0,${numRows * cellSize})`}>
              {processedData[0].map((cell, colIndex) => (
                <text
                  key={`x-${colIndex}`}
                  x={colIndex * cellSize + cellSize / 2}
                  y={20}
                  textAnchor="middle"
                  fill={theme.textSecondary}
                  fontSize={cellSize * 0.25}
                  transform={`rotate(-45, ${colIndex * cellSize + cellSize / 2}, 20)`}
                >
                  {cell.xLabel || `Col ${colIndex + 1}`}
                </text>
              ))}
            </g>
          )}

          {/* Y Axis */}
          {showAxis && (
            <g>
              {processedData.map((row, rowIndex) => (
                <text
                  key={`y-${rowIndex}`}
                  x={-10}
                  y={rowIndex * cellSize + cellSize / 2}
                  textAnchor="end"
                  dominantBaseline="middle"
                  fill={theme.textSecondary}
                  fontSize={cellSize * 0.25}
                >
                  {row[0]?.yLabel || `Row ${rowIndex + 1}`}
                </text>
              ))}
            </g>
          )}
        </g>

        {/* Title */}
        <text
          x={width / 2}
          y={15}
          textAnchor="middle"
          fill={theme.textPrimary}
          fontSize="14"
          fontWeight="600"
        >
          Market Correlation Heatmap
        </text>
      </svg>

      {/* Legend */}
      {showLegend && colorScale && (
        <div
          style={{
            position: 'absolute',
            bottom: margin.bottom - 30,
            left: margin.left,
            width: innerWidth,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}
        >
          <div
            style={{
              width: '100%',
              height: '12px',
              background: legendGradient,
              borderRadius: '4px',
              marginBottom: '8px',
            }}
          />
          <div
            style={{
              width: '100%',
              display: 'flex',
              justifyContent: 'space-between',
              color: theme.textSecondary,
              fontSize: '11px',
            }}
          >
            <span>Negative</span>
            <span>Neutral</span>
            <span>Positive</span>
          </div>
        </div>
      )}
    </div>
  );
};

Heatmap.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.arrayOf(
      PropTypes.shape({
        value: PropTypes.number.isRequired,
        label: PropTypes.string,
        xLabel: PropTypes.string,
        yLabel: PropTypes.string,
      })
    )
  ).isRequired,
  width: PropTypes.number,
  height: PropTypes.number,
  cellSize: PropTypes.number,
  margin: PropTypes.shape({
    top: PropTypes.number,
    right: PropTypes.number,
    bottom: PropTypes.number,
    left: PropTypes.number,
  }),
  colorRange: PropTypes.arrayOf(PropTypes.string),
  showValues: PropTypes.bool,
  showAxis: PropTypes.bool,
  showLegend: PropTypes.bool,
  onCellClick: PropTypes.func,
};

export default Heatmap;