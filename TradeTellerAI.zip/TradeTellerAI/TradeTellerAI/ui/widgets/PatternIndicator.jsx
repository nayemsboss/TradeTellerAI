// ui/widgets/PatternIndicator.jsx
import React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '../../services/themeContext';
import { motion } from 'framer-motion';

/**
 * Candlestick Pattern Visualization Component
 * Displays technical patterns with dynamic styling and animations
 */
const PatternIndicator = ({
  pattern,          // Pattern name (e.g., 'hammer', 'engulfing')
  strength = 0.5,   // 0-1 confidence level
  size = 'medium',  // 'small', 'medium', 'large'
  showLabel = true,
  showStrength = true,
  animated = true,
  onClick,
}) => {
  const { theme } = useTheme();

  // Pattern definitions
  const patternData = {
    hammer: {
      label: 'Hammer',
      color: theme.success,
      shape: (
        <path
          d="M10 4 L10 16 M5 8 L10 4 L15 8"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
      ),
    },
    shootingStar: {
      label: 'Shooting Star',
      color: theme.error,
      shape: (
        <path
          d="M10 16 L10 4 M5 12 L10 16 L15 12"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
      ),
    },
    engulfing: {
      label: 'Engulfing',
      color: theme.success,
      shape: (
        <>
          <rect x="5" y="8" width="10" height="4" rx="1" />
          <rect x="3" y="6" width="14" height="8" rx="1" strokeWidth="1.5" />
        </>
      ),
    },
    darkCloud: {
      label: 'Dark Cloud',
      color: theme.error,
      shape: (
        <>
          <rect x="3" y="6" width="14" height="4" rx="1" />
          <rect x="5" y="10" width="10" height="8" rx="1" strokeWidth="1.5" />
        </>
      ),
    },
    doji: {
      label: 'Doji',
      color: theme.warning,
      shape: (
        <path
          d="M5 10 L15 10 M10 4 L10 16"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
      ),
    },
    morningStar: {
      label: 'Morning Star',
      color: theme.success,
      shape: (
        <>
          <rect x="3" y="4" width="4" height="12" rx="1" />
          <circle cx="10" cy="10" r="3" />
          <rect x="13" y="8" width="4" height="4" rx="1" />
        </>
      ),
    },
    eveningStar: {
      label: 'Evening Star',
      color: theme.error,
      shape: (
        <>
          <rect x="3" y="8" width="4" height="4" rx="1" />
          <circle cx="10" cy="10" r="3" />
          <rect x="13" y="4" width="4" height="12" rx="1" />
        </>
      ),
    },
  };

  // Size presets
  const sizePresets = {
    small: {
      svgSize: 24,
      fontSize: 10,
      strokeWidth: 1.2,
      padding: 4,
    },
    medium: {
      svgSize: 32,
      fontSize: 12,
      strokeWidth: 1.5,
      padding: 6,
    },
    large: {
      svgSize: 48,
      fontSize: 14,
      strokeWidth: 2,
      padding: 8,
    },
  };

  const { svgSize, fontSize, strokeWidth, padding } = sizePresets[size];
  const currentPattern = patternData[pattern] || patternData.doji;
  const clampedStrength = Math.min(Math.max(strength, 0), 1);

  // Animation variants
  const containerVariants = {
    initial: { scale: 0.9, opacity: 0 },
    animate: { 
      scale: 1, 
      opacity: 1,
      transition: { type: 'spring', stiffness: 400, damping: 15 }
    },
    hover: animated ? { scale: 1.05 } : {},
    tap: animated ? { scale: 0.95 } : {},
  };

  const strengthBarVariants = {
    initial: { width: 0 },
    animate: { width: `${clampedStrength * 100}%` },
  };

  return (
    <motion.div
      className="pattern-indicator"
      initial="initial"
      animate="animate"
      whileHover="hover"
      whileTap="tap"
      variants={containerVariants}
      onClick={onClick}
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        cursor: onClick ? 'pointer' : 'default',
        padding,
        width: svgSize + padding * 2,
      }}
    >
      <svg
        width={svgSize}
        height={svgSize}
        viewBox="0 0 20 20"
        style={{
          overflow: 'visible',
          filter: `drop-shadow(0 2px 4px ${theme.shadow}20)`,
        }}
      >
        <g
          stroke={currentPattern.color}
          fill={currentPattern.color}
          strokeWidth={strokeWidth}
          fillOpacity={0.2}
          strokeOpacity={0.8}
        >
          {currentPattern.shape}
        </g>
      </svg>

      {showLabel && (
        <motion.div
          style={{
            color: theme.textSecondary,
            fontSize,
            marginTop: padding / 2,
            textAlign: 'center',
            fontWeight: '500',
          }}
        >
          {currentPattern.label}
        </motion.div>
      )}

      {showStrength && (
        <div
          style={{
            width: '100%',
            height: 2,
            backgroundColor: theme.backgroundTertiary,
            marginTop: padding / 2,
            borderRadius: 1,
            overflow: 'hidden',
          }}
        >
          <motion.div
            variants={strengthBarVariants}
            initial="initial"
            animate="animate"
            transition={{ duration: 0.6, ease: 'easeOut' }}
            style={{
              height: '100%',
              backgroundColor: currentPattern.color,
              borderRadius: 1,
            }}
          />
        </div>
      )}
    </motion.div>
  );
};

PatternIndicator.propTypes = {
  pattern: PropTypes.oneOf([
    'hammer',
    'shootingStar',
    'engulfing',
    'darkCloud',
    'doji',
    'morningStar',
    'eveningStar',
  ]).isRequired,
  strength: PropTypes.number,
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  showLabel: PropTypes.bool,
  showStrength: PropTypes.bool,
  animated: PropTypes.bool,
  onClick: PropTypes.func,
};

// Export pattern types for easy reference
export const PatternTypes = {
  HAMMER: 'hammer',
  SHOOTING_STAR: 'shootingStar',
  ENGULFING: 'engulfing',
  DARK_CLOUD: 'darkCloud',
  DOJI: 'doji',
  MORNING_STAR: 'morningStar',
  EVENING_STAR: 'eveningStar',
};

export default PatternIndicator;