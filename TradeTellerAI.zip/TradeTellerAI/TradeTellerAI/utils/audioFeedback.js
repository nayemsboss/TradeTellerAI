// utils/audioFeedback.js
/**
 * TradeTellerAI - Advanced Audio Feedback System
 * Provides auditory cues for trading events, alerts, and system notifications
 */

// ----------------------------- AUDIO CONFIGURATION -----------------------------

export const SOUND_TYPES = {
  // Trading signals
  BUY_SIGNAL: 'buy_signal',
  SELL_SIGNAL: 'sell_signal',
  STRONG_BUY: 'strong_buy',
  STRONG_SELL: 'strong_sell',
  
  // System alerts
  ALERT_HIGH: 'alert_high',
  ALERT_MEDIUM: 'alert_medium',
  ALERT_LOW: 'alert_low',
  
  // User actions
  ORDER_EXECUTED: 'order_executed',
  ORDER_CANCELLED: 'order_cancelled',
  
  // System events
  NEW_DATA: 'new_data',
  WARNING: 'warning',
  ERROR: 'error'
};

// Predefined audio files (will be encoded as base64)
const SOUND_FILES = {
  buy_signal: 'data:audio/wav;base64,UklGRl...', // Short truncated example
  sell_signal: 'data:audio/wav;base64,UklGRl...',
  strong_buy: 'data:audio/wav;base64,UklGRl...',
  strong_sell: 'data:audio/wav;base64,UklGRl...',
  alert_high: 'data:audio/wav;base64,UklGRl...',
  alert_medium: 'data:audio/wav;base64,UklGRl...',
  alert_low: 'data:audio/wav;base64,UklGRl...',
  order_executed: 'data:audio/wav;base64,UklGRl...',
  order_cancelled: 'data:audio/wav;base64,UklGRl...',
  new_data: 'data:audio/wav;base64,UklGRl...',
  warning: 'data:audio/wav;base64,UklGRl...',
  error: 'data:audio/wav;base64,UklGRl...'
};

// ----------------------------- AUDIO MANAGER -----------------------------

class AudioManager {
  constructor() {
    this.audioContext = null;
    this.sounds = {};
    this.enabled = true;
    this.volume = 0.7;
    this.loaded = false;
    
    // Initialize on first user interaction (browser policy)
    this.initialized = false;
    this.initOnInteraction();
  }
  
  /**
   * Initialize audio context on first user interaction
   */
  initOnInteraction() {
    const init = () => {
      if (this.initialized) return;
      this.initialize();
      this.initialized = true;
      window.removeEventListener('click', init);
      window.removeEventListener('keydown', init);
    };
    
    window.addEventListener('click', init, { once: true });
    window.addEventListener('keydown', init, { once: true });
  }
  
  /**
   * Initialize audio system
   */
  initialize() {
    try {
      this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
      this.loadAllSounds();
      this.loaded = true;
    } catch (e) {
      console.error('Audio initialization failed:', e);
      this.enabled = false;
    }
  }
  
  /**
   * Load all sound files
   */
  async loadAllSounds() {
    try {
      await Promise.all(
        Object.entries(SOUND_FILES).map(([key, data]) => 
          this.loadSound(key, data)
        )
      );
    } catch (e) {
      console.error('Sound loading failed:', e);
    }
  }
  
  /**
   * Load individual sound
   * @param {string} key - Sound identifier
   * @param {string} base64Data - Base64 encoded audio
   */
  async loadSound(key, base64Data) {
    try {
      const response = await fetch(base64Data);
      const arrayBuffer = await response.arrayBuffer();
      const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);
      this.sounds[key] = audioBuffer;
    } catch (e) {
      console.error(`Failed to load sound ${key}:`, e);
    }
  }
  
  /**
   * Play a sound
   * @param {string} soundType - SOUND_TYPES value
   * @param {number} [volume=this.volume] - Playback volume (0-1)
   */
  play(soundType, volume = this.volume) {
    if (!this.enabled || !this.loaded) return;
    if (!this.sounds[soundType]) {
      console.warn(`Sound not loaded: ${soundType}`);
      return;
    }
    
    try {
      const source = this.audioContext.createBufferSource();
      source.buffer = this.sounds[soundType];
      
      const gainNode = this.audioContext.createGain();
      gainNode.gain.value = volume;
      
      source.connect(gainNode);
      gainNode.connect(this.audioContext.destination);
      
      source.start(0);
    } catch (e) {
      console.error(`Error playing sound ${soundType}:`, e);
    }
  }
  
  /**
   * Enable/disable audio feedback
   * @param {boolean} enabled - Whether audio is enabled
   */
  setEnabled(enabled) {
    this.enabled = enabled;
    if (enabled && !this.initialized) {
      this.initialize();
    }
  }
  
  /**
   * Set playback volume
   * @param {number} volume - Volume level (0-1)
   */
  setVolume(volume) {
    this.volume = Math.max(0, Math.min(1, volume));
  }
}

// Singleton instance
const audioManager = new AudioManager();

// ----------------------------- TRADING AUDIO FEEDBACK -----------------------------

/**
 * Play signal sound based on trade direction and confidence
 * @param {string} direction - 'buy' or 'sell'
 * @param {number} confidence - Confidence level (0-1)
 */
export const playTradeSignal = (direction, confidence) => {
  if (confidence >= 0.8) {
    audioManager.play(direction === 'buy' ? SOUND_TYPES.STRONG_BUY : SOUND_TYPES.STRONG_SELL);
  } else {
    audioManager.play(direction === 'buy' ? SOUND_TYPES.BUY_SIGNAL : SOUND_TYPES.SELL_SIGNAL);
  }
};

/**
 * Play alert sound based on priority
 * @param {string} priority - 'high', 'medium', or 'low'
 */
export const playAlert = (priority) => {
  switch (priority) {
    case 'high': audioManager.play(SOUND_TYPES.ALERT_HIGH); break;
    case 'medium': audioManager.play(SOUND_TYPES.ALERT_MEDIUM); break;
    case 'low': audioManager.play(SOUND_TYPES.ALERT_LOW); break;
    default: audioManager.play(SOUND_TYPES.ALERT_MEDIUM);
  }
};

/**
 * Play order execution sound
 * @param {string} action - 'executed' or 'cancelled'
 */
export const playOrderAction = (action) => {
  audioManager.play(action === 'executed' ? SOUND_TYPES.ORDER_EXECUTED : SOUND_TYPES.ORDER_CANCELLED);
};

/**
 * Play system notification sound
 * @param {string} type - 'new_data', 'warning', or 'error'
 */
export const playSystemSound = (type) => {
  audioManager.play(SOUND_TYPES[type.toUpperCase()] || SOUND_TYPES.WARNING);
};

// ----------------------------- UI AUDIO FEEDBACK -----------------------------

/**
 * Play button click sound
 */
export const playButtonClick = () => {
  // Use a simple oscillator for UI sounds to avoid loading files
  if (!audioManager.enabled || !audioManager.audioContext) return;
  
  try {
    const osc = audioManager.audioContext.createOscillator();
    const gain = audioManager.audioContext.createGain();
    
    osc.type = 'sine';
    osc.frequency.value = 600;
    gain.gain.value = 0.1 * audioManager.volume;
    
    osc.connect(gain);
    gain.connect(audioManager.audioContext.destination);
    
    osc.start();
    osc.stop(audioManager.audioContext.currentTime + 0.05);
  } catch (e) {
    console.error('Error playing button click:', e);
  }
};

/**
 * Play toggle sound
 * @param {boolean} state - Toggle state (on/off)
 */
export const playToggleSound = (state) => {
  if (!audioManager.enabled || !audioManager.audioContext) return;
  
  try {
    const osc = audioManager.audioContext.createOscillator();
    const gain = audioManager.audioContext.createGain();
    
    osc.type = 'sine';
    osc.frequency.value = state ? 800 : 400;
    gain.gain.value = 0.1 * audioManager.volume;
    
    osc.connect(gain);
    gain.connect(audioManager.audioContext.destination);
    
    osc.start();
    osc.stop(audioManager.audioContext.currentTime + 0.1);
  } catch (e) {
    console.error('Error playing toggle sound:', e);
  }
};

// ----------------------------- PUBLIC API -----------------------------

export const enableAudio = (enabled) => audioManager.setEnabled(enabled);
export const setAudioVolume = (volume) => audioManager.setVolume(volume);
export const isAudioEnabled = () => audioManager.enabled;

export default {
  SOUND_TYPES,
  playTradeSignal,
  playAlert,
  playOrderAction,
  playSystemSound,
  playButtonClick,
  playToggleSound,
  enableAudio,
  setAudioVolume,
  isAudioEnabled
};