// utils/candleUtils.js
/**
 * TradeTellerAI - Advanced Candlestick Pattern Recognition
 * Contains candlestick pattern detection and analysis utilities
 */

// ----------------------------- PATTERN DEFINITIONS -----------------------------

export const CANDLE_PATTERNS = {
  // Single candle patterns
  DOJI: {
    name: 'Doji',
    description: 'Indecision in the market',
    requiredBodyRatio: 0.05,
    requiredShadowRatio: 0.5
  },
  HAMMER: {
    name: 'Hammer',
    description: 'Potential bullish reversal',
    requiredLowerShadowRatio: 2,
    requiredUpperShadowRatio: 0.1,
    requiredTrend: 'down'
  },
  INVERTED_HAMMER: {
    name: 'Inverted Hammer',
    description: 'Potential bullish reversal after downtrend',
    requiredUpperShadowRatio: 2,
    requiredLowerShadowRatio: 0.1,
    requiredTrend: 'down'
  },
  SHOOTING_STAR: {
    name: 'Shooting Star',
    description: 'Potential bearish reversal after uptrend',
    requiredUpperShadowRatio: 2,
    requiredLowerShadowRatio: 0.1,
    requiredTrend: 'up'
  },
  HANGING_MAN: {
    name: 'Hanging Man',
    description: 'Potential bearish reversal after uptrend',
    requiredLowerShadowRatio: 2,
    requiredUpperShadowRatio: 0.1,
    requiredTrend: 'up'
  },

  // Multi-candle patterns
  ENGULFING: {
    name: 'Engulfing',
    description: 'Strong reversal signal',
    requiredCandles: 2,
    bodyRatio: 1.5
  },
  HARAMI: {
    name: 'Harami',
    description: 'Potential reversal or consolidation',
    requiredCandles: 2,
    bodyContainment: true
  },
  MORNING_STAR: {
    name: 'Morning Star',
    description: 'Bullish reversal pattern',
    requiredCandles: 3,
    middleDojiLike: true
  },
  EVENING_STAR: {
    name: 'Evening Star',
    description: 'Bearish reversal pattern',
    requiredCandles: 3,
    middleDojiLike: true
  },
  THREE_WHITE_SOLDIERS: {
    name: 'Three White Soldiers',
    description: 'Strong bullish continuation',
    requiredCandles: 3,
    consecutiveBullish: true
  },
  THREE_BLACK_CROWS: {
    name: 'Three Black Crows',
    description: 'Strong bearish continuation',
    requiredCandles: 3,
    consecutiveBearish: true
  }
};

// ----------------------------- CORE CANDLE ANALYSIS -----------------------------

/**
 * Analyzes a single candlestick
 * @param {Object} candle - {open, high, low, close}
 * @returns {Object} Analysis results
 */
export const analyzeCandle = (candle) => {
  const bodySize = Math.abs(candle.close - candle.open);
  const totalRange = candle.high - candle.low;
  const isBullish = candle.close > candle.open;
  
  // Calculate shadow sizes
  const upperShadow = isBullish 
    ? candle.high - candle.close 
    : candle.high - candle.open;
  const lowerShadow = isBullish 
    ? candle.open - candle.low 
    : candle.close - candle.low;
  
  // Calculate ratios
  const bodyRatio = totalRange > 0 ? bodySize / totalRange : 0;
  const upperShadowRatio = bodySize > 0 ? upperShadow / bodySize : 0;
  const lowerShadowRatio = bodySize > 0 ? lowerShadow / bodySize : 0;
  
  return {
    bodySize,
    totalRange,
    isBullish,
    upperShadow,
    lowerShadow,
    bodyRatio,
    upperShadowRatio,
    lowerShadowRatio,
    isDoji: bodyRatio <= CANDLE_PATTERNS.DOJI.requiredBodyRatio
  };
};

/**
 * Detects single candle patterns
 * @param {Object} candle - Current candle
 * @param {Object} prevCandle - Previous candle
 * @param {string} trend - Current trend ('up', 'down', 'neutral')
 * @returns {Array} Detected patterns
 */
export const detectSingleCandlePatterns = (candle, prevCandle, trend) => {
  const patterns = [];
  const analysis = analyzeCandle(candle);
  
  // Doji detection
  if (analysis.isDoji) {
    patterns.push({
      name: CANDLE_PATTERNS.DOJI.name,
      type: 'neutral',
      confidence: calculateDojiConfidence(analysis)
    });
  }
  
  // Hammer detection
  if (analysis.lowerShadowRatio >= CANDLE_PATTERNS.HAMMER.requiredLowerShadowRatio &&
      analysis.upperShadowRatio <= CANDLE_PATTERNS.HAMMER.requiredUpperShadowRatio &&
      trend === CANDLE_PATTERNS.HAMMER.requiredTrend) {
    patterns.push({
      name: CANDLE_PATTERNS.HAMMER.name,
      type: 'bullish-reversal',
      confidence: calculateHammerConfidence(analysis)
    });
  }
  
  // Shooting Star detection
  if (analysis.upperShadowRatio >= CANDLE_PATTERNS.SHOOTING_STAR.requiredUpperShadowRatio &&
      analysis.lowerShadowRatio <= CANDLE_PATTERNS.SHOOTING_STAR.requiredLowerShadowRatio &&
      trend === CANDLE_PATTERNS.SHOOTING_STAR.requiredTrend) {
    patterns.push({
      name: CANDLE_PATTERNS.SHOOTING_STAR.name,
      type: 'bearish-reversal',
      confidence: calculateShootingStarConfidence(analysis)
    });
  }
  
  // Hanging Man detection (similar to Hammer but in uptrend)
  if (analysis.lowerShadowRatio >= CANDLE_PATTERNS.HANGING_MAN.requiredLowerShadowRatio &&
      analysis.upperShadowRatio <= CANDLE_PATTERNS.HANGING_MAN.requiredUpperShadowRatio &&
      trend === CANDLE_PATTERNS.HANGING_MAN.requiredTrend) {
    patterns.push({
      name: CANDLE_PATTERNS.HANGING_MAN.name,
      type: 'bearish-reversal',
      confidence: calculateHangingManConfidence(analysis)
    });
  }
  
  return patterns;
};

// ----------------------------- MULTI-CANDLE PATTERNS -----------------------------

/**
 * Detects multi-candle patterns
 * @param {Array<Object>} candles - Array of candles (newest last)
 * @param {string} trend - Current trend ('up', 'down', 'neutral')
 * @returns {Array} Detected patterns
 */
export const detectMultiCandlePatterns = (candles, trend) => {
  const patterns = [];
  
  // Need at least 3 candles for most patterns
  if (candles.length < 3) return patterns;
  
  // Current and previous candles (newest at end of array)
  const [candle2, candle1, candle0] = candles.slice(-3);
  const analysis0 = analyzeCandle(candle0);
  const analysis1 = analyzeCandle(candle1);
  const analysis2 = analyzeCandle(candle2);
  
  // Engulfing pattern
  if (isEngulfingPattern(candle1, candle0)) {
    const type = analysis0.isBullish ? 'bullish-reversal' : 'bearish-reversal';
    patterns.push({
      name: CANDLE_PATTERNS.ENGULFING.name,
      type,
      confidence: calculateEngulfingConfidence(candle1, candle0)
    });
  }
  
  // Harami pattern
  if (isHaramiPattern(candle1, candle0)) {
    patterns.push({
      name: CANDLE_PATTERNS.HARAMI.name,
      type: 'reversal',
      confidence: calculateHaramiConfidence(candle1, candle0)
    });
  }
  
  // Morning Star (bullish reversal)
  if (trend === 'down' &&
      isBearishCandle(candle2) &&
      isDojiLikeCandle(candle1) &&
      isBullishCandle(candle0) &&
      candle0.close > candle2.open * 0.5) {
    patterns.push({
      name: CANDLE_PATTERNS.MORNING_STAR.name,
      type: 'bullish-reversal',
      confidence: calculateMorningStarConfidence(candle2, candle1, candle0)
    });
  }
  
  // Evening Star (bearish reversal)
  if (trend === 'up' &&
      isBullishCandle(candle2) &&
      isDojiLikeCandle(candle1) &&
      isBearishCandle(candle0) &&
      candle0.close < candle2.open * 1.5) {
    patterns.push({
      name: CANDLE_PATTERNS.EVENING_STAR.name,
      type: 'bearish-reversal',
      confidence: calculateEveningStarConfidence(candle2, candle1, candle0)
    });
  }
  
  // Three White Soldiers (bullish continuation)
  if (isThreeWhiteSoldiers(candle2, candle1, candle0)) {
    patterns.push({
      name: CANDLE_PATTERNS.THREE_WHITE_SOLDIERS.name,
      type: 'bullish-continuation',
      confidence: calculateThreeWhiteSoldiersConfidence(candle2, candle1, candle0)
    });
  }
  
  // Three Black Crows (bearish continuation)
  if (isThreeBlackCrows(candle2, candle1, candle0)) {
    patterns.push({
      name: CANDLE_PATTERNS.THREE_BLACK_CROWS.name,
      type: 'bearish-continuation',
      confidence: calculateThreeBlackCrowsConfidence(candle2, candle1, candle0)
    });
  }
  
  return patterns;
};

// ----------------------------- PATTERN DETECTION HELPERS -----------------------------

const isEngulfingPattern = (prevCandle, currentCandle) => {
  const prevBody = Math.abs(prevCandle.close - prevCandle.open);
  const currentBody = Math.abs(currentCandle.close - currentCandle.open);
  
  return currentBody > prevBody * CANDLE_PATTERNS.ENGULFING.bodyRatio &&
    ((currentCandle.close > prevCandle.open && currentCandle.open < prevCandle.close) ||
     (currentCandle.close < prevCandle.open && currentCandle.open > prevCandle.close));
};

const isHaramiPattern = (prevCandle, currentCandle) => {
  const prevHigh = Math.max(prevCandle.open, prevCandle.close);
  const prevLow = Math.min(prevCandle.open, prevCandle.close);
  const currentHigh = Math.max(currentCandle.open, currentCandle.close);
  const currentLow = Math.min(currentCandle.open, currentCandle.close);
  
  return currentHigh < prevHigh && 
         currentLow > prevLow &&
         (prevCandle.close > prevCandle.open) !== (currentCandle.close > currentCandle.open);
};

const isDojiLikeCandle = (candle) => {
  const analysis = analyzeCandle(candle);
  return analysis.bodyRatio <= CANDLE_PATTERNS.DOJI.requiredBodyRatio * 1.5; // Slightly more lenient
};

const isBullishCandle = (candle) => candle.close > candle.open;
const isBearishCandle = (candle) => candle.close < candle.open;

const isThreeWhiteSoldiers = (candle2, candle1, candle0) => {
  return isBullishCandle(candle2) &&
         isBullishCandle(candle1) &&
         isBullishCandle(candle0) &&
         candle1.open > candle2.open &&
         candle1.close > candle2.close &&
         candle0.open > candle1.open &&
         candle0.close > candle1.close;
};

const isThreeBlackCrows = (candle2, candle1, candle0) => {
  return isBearishCandle(candle2) &&
         isBearishCandle(candle1) &&
         isBearishCandle(candle0) &&
         candle1.open < candle2.open &&
         candle1.close < candle2.close &&
         candle0.open < candle1.open &&
         candle0.close < candle1.close;
};

// ----------------------------- CONFIDENCE CALCULATORS -----------------------------

const calculateDojiConfidence = (analysis) => {
  return (1 - (analysis.bodyRatio / CANDLE_PATTERNS.DOJI.requiredBodyRatio)).toFixed(2);
};

const calculateHammerConfidence = (analysis) => {
  const shadowConfidence = Math.min(1, 
    analysis.lowerShadowRatio / CANDLE_PATTERNS.HAMMER.requiredLowerShadowRatio
  );
  const bodyConfidence = 1 - analysis.upperShadowRatio;
  return ((shadowConfidence + bodyConfidence) / 2).toFixed(2);
};

const calculateShootingStarConfidence = (analysis) => {
  const shadowConfidence = Math.min(1,
    analysis.upperShadowRatio / CANDLE_PATTERNS.SHOOTING_STAR.requiredUpperShadowRatio
  );
  const bodyConfidence = 1 - analysis.lowerShadowRatio;
  return ((shadowConfidence + bodyConfidence) / 2).toFixed(2);
};

const calculateHangingManConfidence = (analysis) => {
  return calculateHammerConfidence(analysis); // Same structure as Hammer
};

const calculateEngulfingConfidence = (prevCandle, currentCandle) => {
  const prevBody = Math.abs(prevCandle.close - prevCandle.open);
  const currentBody = Math.abs(currentCandle.close - currentCandle.open);
  return Math.min(1, currentBody / (prevBody * CANDLE_PATTERNS.ENGULFING.bodyRatio)).toFixed(2);
};

const calculateHaramiConfidence = (prevCandle, currentCandle) => {
  const prevSize = prevCandle.high - prevCandle.low;
  const currentSize = currentCandle.high - currentCandle.low;
  return Math.min(1, prevSize / currentSize).toFixed(2);
};

const calculateMorningStarConfidence = (candle2, candle1, candle0) => {
  const trendConfidence = (candle2.close - candle2.open) / candle2.open; // Bearish strength
  const starConfidence = isDojiLikeCandle(candle1) ? 1 : 0.5;
  const confirmationConfidence = (candle0.close - candle1.close) / candle1.close;
  return ((trendConfidence + starConfidence + confirmationConfidence) / 3).toFixed(2);
};

const calculateEveningStarConfidence = (candle2, candle1, candle0) => {
  const trendConfidence = (candle2.close - candle2.open) / candle2.open; // Bullish strength
  const starConfidence = isDojiLikeCandle(candle1) ? 1 : 0.5;
  const confirmationConfidence = (candle1.close - candle0.close) / candle1.close;
  return ((trendConfidence + starConfidence + confirmationConfidence) / 3).toFixed(2);
};

const calculateThreeWhiteSoldiersConfidence = (candle2, candle1, candle0) => {
  const strength1 = (candle1.close - candle1.open) / candle1.open;
  const strength2 = (candle0.close - candle0.open) / candle0.open;
  return ((strength1 + strength2) / 2).toFixed(2);
};

const calculateThreeBlackCrowsConfidence = (candle2, candle1, candle0) => {
  const strength1 = (candle1.open - candle1.close) / candle1.open;
  const strength2 = (candle0.open - candle0.close) / candle0.open;
  return ((strength1 + strength2) / 2).toFixed(2);
};

// ----------------------------- TREND ANALYSIS -----------------------------

/**
 * Determines short-term trend based on candle patterns
 * @param {Array<Object>} candles - Array of candles (newest last)
 * @param {number} [lookback=5] - Number of candles to analyze
 * @returns {string} 'up', 'down', or 'neutral'
 */
export const determineTrend = (candles, lookback = 5) => {
  if (candles.length < lookback) return 'neutral';
  
  const trendCandles = candles.slice(-lookback);
  const closes = trendCandles.map(c => c.close);
  const highs = trendCandles.map(c => c.high);
  const lows = trendCandles.map(c => c.low);
  
  // Simple moving average
  const sum = closes.reduce((a, b) => a + b, 0);
  const avg = sum / lookback;
  
  // Higher highs and higher lows = uptrend
  let higherHighs = 0;
  let higherLows = 0;
  let lowerHighs = 0;
  let lowerLows = 0;
  
  for (let i = 1; i < trendCandles.length; i++) {
    if (highs[i] > highs[i - 1]) higherHighs++;
    if (lows[i] > lows[i - 1]) higherLows++;
    if (highs[i] < highs[i - 1]) lowerHighs++;
    if (lows[i] < lows[i - 1]) lowerLows++;
  }
  
  if (higherHighs >= lookback - 1 && higherLows >= lookback - 1) return 'up';
  if (lowerHighs >= lookback - 1 && lowerLows >= lookback - 1) return 'down';
  
  // Fallback to SMA comparison
  const firstClose = trendCandles[0].close;
  const lastClose = trendCandles[trendCandles.length - 1].close;
  
  if (lastClose > avg && lastClose > firstClose) return 'up';
  if (lastClose < avg && lastClose < firstClose) return 'down';
  
  return 'neutral';
};

// ----------------------------- PATTERN SCANNER -----------------------------

/**
 * Scans candle history for all detectable patterns
 * @param {Array<Object>} candles - Array of candles (newest last)
 * @param {number} [lookback=50] - Maximum candles to scan
 * @returns {Array} All detected patterns with metadata
 */
export const scanCandleHistory = (candles, lookback = 50) => {
  const patterns = [];
  const scanLength = Math.min(candles.length, lookback);
  
  for (let i = 2; i < scanLength; i++) {
    const currentCandle = candles[i];
    const prevCandle = candles[i - 1];
    const prevPrevCandle = candles[i - 2];
    
    // Determine current trend context
    const trend = determineTrend(candles.slice(0, i + 1), 5);
    
    // Detect single candle patterns
    const singlePatterns = detectSingleCandlePatterns(currentCandle, prevCandle, trend);
    singlePatterns.forEach(pattern => {
      patterns.push({
        ...pattern,
        position: i,
        timestamp: currentCandle.timestamp || null
      });
    });
    
    // Detect multi-candle patterns when we have enough history
    if (i >= 3) {
      const multiPatterns = detectMultiCandlePatterns(
        [prevPrevCandle, prevCandle, currentCandle], 
        trend
      );
      multiPatterns.forEach(pattern => {
        patterns.push({
          ...pattern,
          position: i,
          timestamp: currentCandle.timestamp || null,
          candlesInPattern: 3
        });
      });
    }
  }
  
  return patterns;
};

// ----------------------------- EXPORT ALL UTILITIES -----------------------------

export default {
  CANDLE_PATTERNS,
  analyzeCandle,
  detectSingleCandlePatterns,
  detectMultiCandlePatterns,
  determineTrend,
  scanCandleHistory
};