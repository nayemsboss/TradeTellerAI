// utils/chartHelpers.js
/**
 * TradeTellerAI - Advanced Charting Utilities
 * Contains visualization helpers for trading charts and technical indicators
 */

import { 
  calculateSMA, 
  calculateEMA,
  calculateStandardDeviation,
  calculateBollingerBands 
} from './tradingMath';

// ----------------------------- CHART CONFIGURATION -----------------------------

export const CHART_STYLES = {
  LIGHT: {
    bgColor: '#FFFFFF',
    textColor: '#2E2E2E',
    gridColor: '#EAEAEA',
    upCandle: '#26A69A',
    downCandle: '#EF5350',
    volumeUp: 'rgba(38, 166, 154, 0.3)',
    volumeDown: 'rgba(239, 83, 80, 0.3)',
    indicatorColors: {
      sma: '#2962FF',
      ema: '#FF6D00',
      bollinger: '#7B1FA2',
      rsi: '#0091EA',
      macd: '#26C6DA',
      signal: '#FF4081',
      histogram: '#455A64'
    }
  },
  DARK: {
    bgColor: '#121826',
    textColor: '#E0E0E0',
    gridColor: '#2A3040',
    upCandle: '#00C805',
    downCandle: '#FF3B3B',
    volumeUp: 'rgba(0, 200, 5, 0.3)',
    volumeDown: 'rgba(255, 59, 59, 0.3)',
    indicatorColors: {
      sma: '#5C6BC0',
      ema: '#FFA726',
      bollinger: '#AB47BC',
      rsi: '#29B6F6',
      macd: '#26A69A',
      signal: '#FF7043',
      histogram: '#78909C'
    }
  }
};

// ----------------------------- CORE CHART UTILITIES -----------------------------

/**
 * Normalizes chart data for consistent rendering
 * @param {Array} data - Raw chart data
 * @param {string} timeframe - Timeframe string (M1, M5, H1, etc.)
 * @returns {Array} Normalized chart data
 */
export const normalizeChartData = (data, timeframe) => {
  return data.map(item => ({
    timestamp: new Date(item.timestamp).getTime(),
    open: parseFloat(item.open),
    high: parseFloat(item.high),
    low: parseFloat(item.low),
    close: parseFloat(item.close),
    volume: item.volume ? parseFloat(item.volume) : 0,
    timeframe,
    // Optional fields
    ...(item.spread && { spread: parseFloat(item.spread) }),
    ...(item.trades && { trades: parseInt(item.trades) })
  })).sort((a, b) => a.timestamp - b.timestamp);
};

/**
 * Groups tick data into candles
 * @param {Array} ticks - Array of tick data {price, volume, timestamp}
 * @param {string} timeframe - M1, M5, M15, M30, H1, H4, D1, W1
 * @returns {Array} Candlestick data
 */
export const buildCandlesFromTicks = (ticks, timeframe) => {
  if (!ticks.length) return [];
  
  const candles = [];
  let currentCandle = null;
  const timeframeMs = getTimeframeMilliseconds(timeframe);
  
  ticks.forEach(tick => {
    const tickTime = new Date(tick.timestamp).getTime();
    const candleTime = Math.floor(tickTime / timeframeMs) * timeframeMs;
    
    if (!currentCandle || currentCandle.timestamp !== candleTime) {
      if (currentCandle) candles.push(currentCandle);
      currentCandle = {
        timestamp: candleTime,
        open: tick.price,
        high: tick.price,
        low: tick.price,
        close: tick.price,
        volume: tick.volume || 0,
        timeframe
      };
    } else {
      currentCandle.high = Math.max(currentCandle.high, tick.price);
      currentCandle.low = Math.min(currentCandle.low, tick.price);
      currentCandle.close = tick.price;
      currentCandle.volume += tick.volume || 0;
    }
  });
  
  if (currentCandle) candles.push(currentCandle);
  return candles;
};

const getTimeframeMilliseconds = (timeframe) => {
  const minute = 60 * 1000;
  const hour = 60 * minute;
  const day = 24 * hour;
  const week = 7 * day;
  
  switch (timeframe) {
    case 'M1': return minute;
    case 'M5': return 5 * minute;
    case 'M15': return 15 * minute;
    case 'M30': return 30 * minute;
    case 'H1': return hour;
    case 'H4': return 4 * hour;
    case 'D1': return day;
    case 'W1': return week;
    default: return minute;
  }
};

// ----------------------------- INDICATOR CALCULATIONS -----------------------------

/**
 * Calculates all technical indicators for chart display
 * @param {Array} candles - Array of candle data
 * @param {Object} config - Indicator configurations
 * @returns {Object} Calculated indicators
 */
export const calculateChartIndicators = (candles, config = {}) => {
  const closes = candles.map(c => c.close);
  const volumes = candles.map(c => c.volume);
  
  // Default configurations
  const {
    smaPeriods = [20, 50, 200],
    emaPeriods = [9, 21],
    bbPeriod = 20,
    bbStdDev = 2,
    rsiPeriod = 14,
    macdFast = 12,
    macdSlow = 26,
    macdSignal = 9
  } = config;
  
  const indicators = {};
  
  // Moving Averages
  indicators.sma = {};
  smaPeriods.forEach(period => {
    indicators.sma[period] = calculateSMA(closes, period);
  });
  
  indicators.ema = {};
  emaPeriods.forEach(period => {
    indicators.ema[period] = calculateEMA(closes, period);
  });
  
  // Bollinger Bands
  const bb = calculateBollingerBands(closes, bbPeriod, bbStdDev);
  indicators.bb = {
    upper: bb.upperBand,
    middle: bb.middleBand,
    lower: bb.lowerBand
  };
  
  // RSI
  indicators.rsi = calculateRSI(closes, rsiPeriod);
  
  // MACD
  const macd = calculateMACD(closes, macdFast, macdSlow, macdSignal);
  indicators.macd = {
    line: macd.macdLine,
    signal: macd.signalLine,
    histogram: macd.histogram
  };
  
  // Volume SMA
  indicators.volumeSma = calculateSMA(volumes, 20);
  
  return indicators;
};

/**
 * Calculates RSI for chart display
 * @param {Array} closes - Array of closing prices
 * @param {number} period - RSI period
 * @returns {Array} RSI values
 */
const calculateRSI = (closes, period = 14) => {
  if (closes.length < period + 1) return [];
  
  const gains = [];
  const losses = [];
  
  for (let i = 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    gains.push(Math.max(0, diff));
    losses.push(Math.max(0, -diff));
  }
  
  // Initial averages
  let avgGain = gains.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let avgLoss = losses.slice(0, period).reduce((a, b) => a + b, 0) / period;
  
  const rsi = [100 - (100 / (1 + (avgGain / (avgLoss || 0.0001))))];
  
  // Subsequent values
  for (let i = period; i < gains.length; i++) {
    avgGain = ((avgGain * (period - 1)) + gains[i]) / period;
    avgLoss = ((avgLoss * (period - 1)) + losses[i]) / period;
    const rs = avgGain / (avgLoss || 0.0001);
    rsi.push(100 - (100 / (1 + rs)));
  }
  
  return rsi;
};

/**
 * Calculates MACD for chart display
 * @param {Array} closes - Array of closing prices
 * @param {number} fast - Fast EMA period
 * @param {number} slow - Slow EMA period
 * @param {number} signal - Signal line period
 * @returns {Object} MACD components
 */
const calculateMACD = (closes, fast = 12, slow = 26, signal = 9) => {
  if (closes.length < slow + signal) return { macdLine: [], signalLine: [], histogram: [] };
  
  const fastEMA = calculateEMA(closes, fast);
  const slowEMA = calculateEMA(closes, slow);
  
  // MACD Line = Fast EMA - Slow EMA
  const macdLine = [];
  for (let i = slow - fast; i < slowEMA.length; i++) {
    macdLine.push(fastEMA[i + (fast - 1)] - slowEMA[i]);
  }
  
  // Signal Line = EMA of MACD Line
  const signalLine = calculateEMA(macdLine, signal);
  
  // Histogram = MACD Line - Signal Line
  const histogram = [];
  for (let i = signal - 1; i < macdLine.length; i++) {
    histogram.push(macdLine[i] - signalLine[i - (signal - 1)]);
  }
  
  return {
    macdLine: macdLine.slice(signal - 1),
    signalLine,
    histogram
  };
};

// ----------------------------- CHART ANNOTATIONS -----------------------------

/**
 * Generates annotations for significant chart events
 * @param {Array} candles - Candle data
 * @param {Array} patterns - Detected candlestick patterns
 * @param {Array} newsEvents - Relevant news events
 * @returns {Array} Annotation objects
 */
export const generateChartAnnotations = (candles, patterns = [], newsEvents = []) => {
  const annotations = [];
  
  // Add pattern annotations
  patterns.forEach(pattern => {
    if (pattern.position < candles.length) {
      const candle = candles[pattern.position];
      annotations.push({
        type: 'pattern',
        pattern: pattern.name,
        timestamp: candle.timestamp,
        price: pattern.type.includes('bullish') ? candle.low : candle.high,
        direction: pattern.type.includes('bullish') ? 'up' : 'down',
        confidence: pattern.confidence,
        text: `${pattern.name} (${(pattern.confidence * 100).toFixed(0)}%)`,
        color: pattern.type.includes('bullish') ? '#26A69A' : '#EF5350'
      });
    }
  });
  
  // Add news event annotations
  newsEvents.forEach(event => {
    if (event.timestamp) {
      // Find nearest candle
      const eventTime = new Date(event.timestamp).getTime();
      const closestCandle = candles.reduce((prev, curr) => 
        Math.abs(curr.timestamp - eventTime) < Math.abs(prev.timestamp - eventTime) ? curr : prev
      );
      
      if (closestCandle) {
        annotations.push({
          type: 'news',
          event: event.title,
          timestamp: eventTime,
          price: closestCandle.high,
          impact: event.impact || 'medium',
          text: `📰 ${event.title}`,
          color: getNewsImpactColor(event.impact)
        });
      }
    }
  });
  
  return annotations;
};

const getNewsImpactColor = (impact) => {
  switch (impact?.toLowerCase()) {
    case 'high': return '#FF5252';
    case 'medium': return '#FFC107';
    case 'low': return '#757575';
    default: return '#BDBDBD';
  }
};

// ----------------------------- PERFORMANCE OPTIMIZATION -----------------------------

/**
 * Downsample data for improved rendering performance
 * @param {Array} data - Original data
 * @param {number} maxPoints - Maximum points to keep
 * @returns {Array} Downsampled data
 */
export const downsampleData = (data, maxPoints = 500) => {
  if (data.length <= maxPoints) return data;
  
  const step = Math.ceil(data.length / maxPoints);
  const downsampled = [];
  
  for (let i = 0; i < data.length; i += step) {
    const chunk = data.slice(i, i + step);
    if (!chunk.length) continue;
    
    if (chunk[0].open !== undefined) {
      // Candlestick data
      downsampled.push({
        timestamp: chunk[0].timestamp,
        open: chunk[0].open,
        high: Math.max(...chunk.map(c => c.high)),
        low: Math.min(...chunk.map(c => c.low)),
        close: chunk[chunk.length - 1].close,
        volume: chunk.reduce((sum, c) => sum + (c.volume || 0), 0)
      });
    } else {
      // Simple time series
      downsampled.push(chunk[Math.floor(chunk.length / 2)]);
    }
  }
  
  return downsampled;
};

/**
 * Generates efficient rendering ranges for large datasets
 * @param {Array} data - Full dataset
 * @param {number} viewportWidth - Pixels available for rendering
 * @param {number} [minWidth=2] - Minimum pixels per data point
 * @returns {Object} {startIndex, endIndex, step}
 */
export const calculateRenderRange = (data, viewportWidth, minWidth = 2) => {
  const maxPoints = Math.floor(viewportWidth / minWidth);
  const dataLength = data.length;
  
  if (dataLength <= maxPoints) {
    return { startIndex: 0, endIndex: dataLength - 1, step: 1 };
  }
  
  const step = Math.ceil(dataLength / maxPoints);
  const startIndex = Math.max(0, dataLength - maxPoints * step);
  const endIndex = dataLength - 1;
  
  return { startIndex, endIndex, step };
};

// ----------------------------- CHART FORMATTING -----------------------------

/**
 * Formats price for display based on instrument
 * @param {number} price - Raw price
 * @param {string} symbol - Instrument symbol (e.g., EURUSD)
 * @returns {string} Formatted price
 */
export const formatPrice = (price, symbol) => {
  if (!price) return '--';
  
  // Determine decimal places based on symbol type
  let decimals = 5;
  if (symbol.includes('JPY')) decimals = 3;
  if (symbol.includes('XAU') || symbol.includes('XAG')) decimals = 2;
  if (symbol.includes('STOCK')) decimals = 2;
  
  return price.toFixed(decimals);
};

/**
 * Formats volume for display
 * @param {number} volume - Raw volume
 * @returns {string} Formatted volume
 */
export const formatVolume = (volume) => {
  if (volume >= 1000000) return `${(volume / 1000000).toFixed(1)}M`;
  if (volume >= 1000) return `${(volume / 1000).toFixed(1)}K`;
  return volume.toFixed(0);
};

/**
 * Generates axis ticks for time scale
 * @param {Array} timestamps - Array of timestamps
 * @param {string} timeframe - Chart timeframe
 * @returns {Array} Tick values and labels
 */
export const generateTimeTicks = (timestamps, timeframe) => {
  if (!timestamps.length) return [];
  
  const ticks = [];
  const date = new Date(timestamps[0]);
  const endDate = new Date(timestamps[timestamps.length - 1]);
  
  // Determine appropriate interval based on timeframe and duration
  const duration = endDate - date;
  let interval;
  
  if (timeframe === 'D1' || timeframe === 'W1') {
    // Daily/weekly charts show weekly/monthly ticks
    interval = duration > 90 * 86400000 ? 'month' : 'week';
  } else {
    // Intraday charts show hourly/daily ticks
    if (duration > 3 * 86400000) interval = 'day';
    else if (duration > 86400000) interval = '6hour';
    else interval = 'hour';
  }
  
  // Generate ticks
  let currentTick = new Date(date);
  
  switch (interval) {
    case 'month':
      currentTick.setUTCDate(1);
      currentTick.setUTCHours(0, 0, 0, 0);
      while (currentTick <= endDate) {
        ticks.push({
          value: currentTick.getTime(),
          label: currentTick.toLocaleDateString('en-US', { month: 'short', year: '2-digit' })
        });
        currentTick.setUTCMonth(currentTick.getUTCMonth() + 1);
      }
      break;
      
    case 'week':
      currentTick.setUTCDate(currentTick.getUTCDate() - currentTick.getUTCDay());
      currentTick.setUTCHours(0, 0, 0, 0);
      while (currentTick <= endDate) {
        ticks.push({
          value: currentTick.getTime(),
          label: currentTick.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
        });
        currentTick.setUTCDate(currentTick.getUTCDate() + 7);
      }
      break;
      
    case 'day':
      currentTick.setUTCHours(0, 0, 0, 0);
      while (currentTick <= endDate) {
        ticks.push({
          value: currentTick.getTime(),
          label: currentTick.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
        });
        currentTick.setUTCDate(currentTick.getUTCDate() + 1);
      }
      break;
      
    case '6hour':
      currentTick.setUTCHours(Math.floor(currentTick.getUTCHours() / 6) * 6, 0, 0, 0);
      while (currentTick <= endDate) {
        ticks.push({
          value: currentTick.getTime(),
          label: currentTick.toLocaleTimeString('en-US', { hour: 'numeric', hour12: true })
        });
        currentTick.setUTCHours(currentTick.getUTCHours() + 6);
      }
      break;
      
    default: // hour
      currentTick.setUTCHours(currentTick.getUTCHours(), 0, 0, 0);
      while (currentTick <= endDate) {
        ticks.push({
          value: currentTick.getTime(),
          label: currentTick.toLocaleTimeString('en-US', { hour: 'numeric', hour12: true })
        });
        currentTick.setUTCHours(currentTick.getUTCHours() + 1);
      }
  }
  
  return ticks;
};

// ----------------------------- EXPORT ALL UTILITIES -----------------------------

export default {
  CHART_STYLES,
  normalizeChartData,
  buildCandlesFromTicks,
  calculateChartIndicators,
  generateChartAnnotations,
  downsampleData,
  calculateRenderRange,
  formatPrice,
  formatVolume,
  generateTimeTicks
};