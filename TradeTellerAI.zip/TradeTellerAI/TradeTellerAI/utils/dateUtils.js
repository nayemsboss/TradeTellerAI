// utils/dateUtils.js
/**
 * TradeTellerAI - Advanced Date/Time Utilities for Trading
 * Contains all time-related calculations and formatting for market analysis
 */

// ----------------------------- CORE CONSTANTS -----------------------------

export const MARKET_HOLIDAYS = {
  US: [
    '01-01', // New Year's Day
    '01-15', // MLK Day
    '02-19', // Presidents Day
    '03-29', // Good Friday
    '05-27', // Memorial Day
    '06-19', // Juneteenth
    '07-04', // Independence Day
    '09-02', // Labor Day
    '11-28', // Thanksgiving
    '12-25'  // Christmas
  ],
  EU: [
    '01-01', // New Year's Day
    '04-01', // Easter Monday
    '05-01', // Labour Day
    '05-09', // Europe Day
    '12-25', // Christmas
    '12-26'  // Boxing Day
  ],
  ASIA: [
    '01-01', // New Year's Day
    '02-10', // Chinese New Year
    '04-04', // Qingming Festival
    '05-01', // Labour Day
    '06-10', // Dragon Boat Festival
    '09-17', // Mid-Autumn Festival
    '10-01'  // National Day
  ]
};

export const MARKET_SESSIONS = {
  LONDON: { open: 8, close: 16 }, // GMT
  NEW_YORK: { open: 13, close: 20 }, // GMT
  TOKYO: { open: 0, close: 6 }, // GMT
  SYDNEY: { open: 22, close: 5 } // GMT (next day)
};

// ----------------------------- CORE FUNCTIONS -----------------------------

/**
 * Checks if a date is within market hours for a specific session
 * @param {Date} date - Date to check
 * @param {string} session - MARKET_SESSIONS key (LONDON|NEW_YORK|TOKYO|SYDNEY)
 * @returns {boolean} True if during market hours
 */
export const isMarketOpen = (date, session) => {
  const hours = date.getUTCHours();
  const { open, close } = MARKET_SESSIONS[session];
  
  if (session === 'SYDNEY') {
    // Sydney spans midnight GMT
    return hours >= open || hours < close;
  }
  return hours >= open && hours < close;
};

/**
 * Checks if a date is a market holiday
 * @param {Date} date - Date to check
 * @param {string} region - MARKET_HOLIDAYS key (US|EU|ASIA)
 * @returns {boolean} True if holiday
 */
export const isMarketHoliday = (date, region) => {
  const monthDay = `${String(date.getUTCMonth() + 1).padStart(2, '0')}-${String(date.getUTCDate()).padStart(2, '0')}`;
  return MARKET_HOLIDAYS[region].includes(monthDay);
};

/**
 * Gets the current market session based on time
 * @param {Date} date - Date to check
 * @returns {string} Current active session(s)
 */
export const getCurrentSession = (date) => {
  const activeSessions = [];
  
  for (const [session, hours] of Object.entries(MARKET_SESSIONS)) {
    if (isMarketOpen(date, session)) {
      activeSessions.push(session);
    }
  }
  
  return activeSessions.length ? activeSessions.join(' + ') : 'CLOSED';
};

/**
 * Calculates time until next market session opens
 * @param {string} session - Target session
 * @param {Date} [fromDate=new Date()] - Reference date
 * @returns {Object} {hours, minutes, seconds} until open
 */
export const timeUntilSessionOpen = (session, fromDate = new Date()) => {
  const target = new Date(fromDate);
  const { open } = MARKET_SESSIONS[session];
  
  // For sessions that span midnight (Sydney)
  if (session === 'SYDNEY' && fromDate.getUTCHours() >= 5) {
    target.setUTCDate(target.getUTCDate() + 1);
  }
  
  target.setUTCHours(open, 0, 0, 0);
  
  // If already past today's open time, target next day
  if (target <= fromDate) {
    target.setUTCDate(target.getUTCDate() + 1);
  }
  
  const diffMs = target - fromDate;
  return {
    hours: Math.floor(diffMs / (1000 * 60 * 60)),
    minutes: Math.floor((diffMs / (1000 * 60)) % 60),
    seconds: Math.floor((diffMs / 1000) % 60)
  };
};

// ----------------------------- TIME FORMATTING -----------------------------

/**
 * Formats date as trading timestamp (e.g. "2023-12-15 14:30:00 GMT")
 * @param {Date} date - Input date
 * @param {boolean} [includeSeconds=false] - Show seconds
 * @returns {string} Formatted timestamp
 */
export const formatTradingTimestamp = (date, includeSeconds = false) => {
  const pad = n => String(n).padStart(2, '0');
  const year = date.getUTCFullYear();
  const month = pad(date.getUTCMonth() + 1);
  const day = pad(date.getUTCDate());
  const hours = pad(date.getUTCHours());
  const mins = pad(date.getUTCMinutes());
  
  let timestamp = `${year}-${month}-${day} ${hours}:${mins} GMT`;
  
  if (includeSeconds) {
    const secs = pad(date.getUTCSeconds());
    timestamp = `${year}-${month}-${day} ${hours}:${mins}:${secs} GMT`;
  }
  
  return timestamp;
};

/**
 * Formats duration for display (e.g. "2h 15m")
 * @param {number} milliseconds - Duration in ms
 * @returns {string} Formatted duration
 */
export const formatDuration = (milliseconds) => {
  const seconds = Math.floor(milliseconds / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) {
    return `${days}d ${hours % 24}h`;
  }
  if (hours > 0) {
    return `${hours}h ${minutes % 60}m`;
  }
  if (minutes > 0) {
    return `${minutes}m ${seconds % 60}s`;
  }
  return `${seconds}s`;
};

// ----------------------------- CANDLE TIME UTILS -----------------------------

/**
 * Gets candle time for given timeframe
 * @param {Date} date - Input date
 * @param {string} timeframe - M1, M5, M15, M30, H1, H4, D1, W1
 * @returns {Date} Aligned candle time
 */
export const getCandleTime = (date, timeframe) => {
  const d = new Date(date);
  const minute = d.getUTCMinutes();
  const hour = d.getUTCHours();
  
  switch (timeframe) {
    case 'M1':
      d.setUTCSeconds(0, 0);
      break;
    case 'M5':
      d.setUTCMinutes(Math.floor(minute / 5) * 5, 0, 0);
      break;
    case 'M15':
      d.setUTCMinutes(Math.floor(minute / 15) * 15, 0, 0);
      break;
    case 'M30':
      d.setUTCMinutes(Math.floor(minute / 30) * 30, 0, 0);
      break;
    case 'H1':
      d.setUTCMinutes(0, 0, 0);
      break;
    case 'H4':
      d.setUTCHours(Math.floor(hour / 4) * 4, 0, 0, 0);
      break;
    case 'D1':
      d.setUTCHours(0, 0, 0, 0);
      break;
    case 'W1':
      d.setUTCHours(0, 0, 0, 0);
      // Set to previous Monday
      d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
      break;
    default:
      throw new Error(`Invalid timeframe: ${timeframe}`);
  }
  
  return d;
};

/**
 * Calculates next candle time
 * @param {Date} currentTime - Current time
 * @param {string} timeframe - Timeframe string
 * @returns {Date} Next candle open time
 */
export const getNextCandleTime = (currentTime, timeframe) => {
  const candleTime = getCandleTime(currentTime, timeframe);
  const incrementMap = {
    M1: 60000,
    M5: 300000,
    M15: 900000,
    M30: 1800000,
    H1: 3600000,
    H4: 14400000,
    D1: 86400000,
    W1: 604800000
  };
  
  return new Date(candleTime.getTime() + incrementMap[timeframe]);
};

// ----------------------------- TIMEZONE CONVERSION -----------------------------

/**
 * Converts between timezones
 * @param {Date} date - Input date
 * @param {string} fromTz - Source timezone (e.g. "UTC")
 * @param {string} toTz - Target timezone (e.g. "America/New_York")
 * @returns {Date} Converted date
 */
export const convertTimeZone = (date, fromTz, toTz) => {
  if (fromTz === 'UTC' && toTz === 'UTC') return new Date(date);
  
  const utcDate = fromTz === 'UTC' 
    ? date 
    : new Date(date.toLocaleString('en-US', { timeZone: fromTz }));
    
  const targetDate = toTz === 'UTC'
    ? utcDate
    : new Date(utcDate.toLocaleString('en-US', { timeZone: toTz }));
    
  return targetDate;
};

/**
 * Gets market hours in local time
 * @param {string} session - Session key
 * @param {string} timeZone - Target timezone
 * @returns {Object} {open, close} times in local time
 */
export const getLocalSessionHours = (session, timeZone) => {
  const { open, close } = MARKET_SESSIONS[session];
  const openDate = new Date();
  openDate.setUTCHours(open, 0, 0, 0);
  
  const closeDate = new Date();
  closeDate.setUTCHours(close, 0, 0, 0);
  
  return {
    open: convertTimeZone(openDate, 'UTC', timeZone),
    close: convertTimeZone(closeDate, 'UTC', timeZone)
  };
};

// ----------------------------- TIME CALCULATIONS -----------------------------

/**
 * Checks if two dates are in the same trading day
 * @param {Date} date1 - First date
 * @param {Date} date2 - Second date
 * @param {string} [session='NEW_YORK'] - Reference session
 * @returns {boolean} True if same trading day
 */
export const isSameTradingDay = (date1, date2, session = 'NEW_YORK') => {
  const { open } = MARKET_SESSIONS[session];
  
  // Adjust dates to session-based days
  const adjustDate = (date) => {
    const d = new Date(date);
    if (d.getUTCHours() < open) {
      d.setUTCDate(d.getUTCDate() - 1);
    }
    d.setUTCHours(0, 0, 0, 0);
    return d;
  };
  
  return adjustDate(date1).getTime() === adjustDate(date2).getTime();
};

/**
 * Gets trading days between two dates
 * @param {Date} start - Start date
 * @param {Date} end - End date
 * @param {string} [region='US'] - Market region
 * @returns {number} Trading day count
 */
export const getTradingDaysBetween = (start, end, region = 'US') => {
  let count = 0;
  const current = new Date(start);
  current.setUTCHours(12, 0, 0, 0); // Midday to avoid DST issues
  
  while (current <= end) {
    // Check if weekday (0-6 = Sun-Sat)
    const day = current.getUTCDay();
    if (day !== 0 && day !== 6 && !isMarketHoliday(current, region)) {
      count++;
    }
    current.setUTCDate(current.getUTCDate() + 1);
  }
  
  return count;
};

// ----------------------------- EXPORT ALL UTILITIES -----------------------------

export default {
  MARKET_HOLIDAYS,
  MARKET_SESSIONS,
  isMarketOpen,
  isMarketHoliday,
  getCurrentSession,
  timeUntilSessionOpen,
  formatTradingTimestamp,
  formatDuration,
  getCandleTime,
  getNextCandleTime,
  convertTimeZone,
  getLocalSessionHours,
  isSameTradingDay,
  getTradingDaysBetween
};