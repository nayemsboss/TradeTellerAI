// utils/logger.js
/**
 * TradeTellerAI - Advanced Logging System
 * Unified logging with multiple levels, colors, and persistence
 */

// ----------------------------- CONSTANTS -----------------------------

export const LOG_LEVELS = {
  ERROR: 0,
  WARN: 1,
  INFO: 2,
  DEBUG: 3,
  TRACE: 4
};

export const LOG_COLORS = {
  ERROR: '#FF5252',
  WARN: '#FFC107',
  INFO: '#4CAF50',
  DEBUG: '#2196F3',
  TRACE: '#9C27B0',
  TIMESTAMP: '#607D8B'
};

// ----------------------------- CONFIGURATION -----------------------------

const config = {
  level: LOG_LEVELS.INFO,
  persist: false,
  maxLogSize: 1000, // Max entries in memory
  consoleOutput: true,
  extensionStorage: null // Will be set by init()
};

// ----------------------------- LOG STORAGE -----------------------------

let logStorage = [];
let sequenceId = 0;

// ----------------------------- CORE FUNCTIONS -----------------------------

/**
 * Initialize logger with extension storage
 * @param {Object} storage - Chrome extension storage.local reference
 */
export const initLogger = (storage) => {
  config.extensionStorage = storage;
  
  // Load persisted logs if enabled
  if (config.persist && storage) {
    storage.get(['appLogs', 'logSequence'], (result) => {
      if (result.appLogs) {
        logStorage = result.appLogs.slice(-config.maxLogSize);
      }
      if (result.logSequence) {
        sequenceId = result.logSequence;
      }
    });
  }
};

/**
 * Set log level
 * @param {string} level - LOG_LEVELS key (ERROR|WARN|INFO|DEBUG|TRACE)
 */
export const setLogLevel = (level) => {
  if (LOG_LEVELS[level] !== undefined) {
    config.level = LOG_LEVELS[level];
    info(`Log level set to ${level}`);
  } else {
    error(`Invalid log level: ${level}`);
  }
};

/**
 * Toggle log persistence
 * @param {boolean} enable - Whether to persist logs
 */
export const setLogPersistence = (enable) => {
  config.persist = enable;
  info(`Log persistence ${enable ? 'enabled' : 'disabled'}`);
};

// ----------------------------- LOGGING FUNCTIONS -----------------------------

/**
 * Core logging function
 * @param {string} level - Log level
 * @param {string} message - Log message
 * @param {Object} [data] - Additional data
 * @private
 */
const _log = (level, message, data) => {
  if (LOG_LEVELS[level] > config.level) return;
  
  const timestamp = new Date().toISOString();
  const logEntry = {
    id: ++sequenceId,
    timestamp,
    level,
    message,
    data: data || null
  };
  
  // Add to in-memory storage (circular buffer)
  logStorage.push(logEntry);
  if (logStorage.length > config.maxLogSize) {
    logStorage.shift();
  }
  
  // Persist to storage if enabled
  if (config.persist && config.extensionStorage) {
    config.extensionStorage.set({
      appLogs: logStorage,
      logSequence: sequenceId
    });
  }
  
  // Console output with colors
  if (config.consoleOutput) {
    const style = `color: ${LOG_COLORS[level]}; font-weight: bold`;
    const timestampStyle = `color: ${LOG_COLORS.TIMESTAMP}`;
    
    // Format for better Chrome console grouping
    if (data) {
      console.groupCollapsed(
        `%c[${timestamp}] %c${level}: ${message}`,
        timestampStyle,
        style
      );
      console.log('Additional data:', data);
      console.groupEnd();
    } else {
      console.log(
        `%c[${timestamp}] %c${level}: ${message}`,
        timestampStyle,
        style
      );
    }
  }
};

/**
 * Error level log
 * @param {string} message - Log message
 * @param {Object} [data] - Additional data
 */
export const error = (message, data) => {
  _log('ERROR', message, data);
  
  // Send error reports to background for analytics
  try {
    chrome.runtime.sendMessage({
      type: 'ERROR_REPORT',
      payload: {
        message,
        data: data ? JSON.stringify(data) : null,
        timestamp: Date.now()
      }
    });
  } catch (e) {
    // Ignore messaging errors
  }
};

/**
 * Warn level log
 * @param {string} message - Log message
 * @param {Object} [data] - Additional data
 */
export const warn = (message, data) => {
  _log('WARN', message, data);
};

/**
 * Info level log
 * @param {string} message - Log message
 * @param {Object} [data] - Additional data
 */
export const info = (message, data) => {
  _log('INFO', message, data);
};

/**
 * Debug level log
 * @param {string} message - Log message
 * @param {Object} [data] - Additional data
 */
export const debug = (message, data) => {
  _log('DEBUG', message, data);
};

/**
 * Trace level log
 * @param {string} message - Log message
 * @param {Object} [data] - Additional data
 */
export const trace = (message, data) => {
  _log('TRACE', message, data);
};

// ----------------------------- LOG RETRIEVAL -----------------------------

/**
 * Get logs with optional filtering
 * @param {Object} [options] - Filter options
 * @param {string} [options.level] - Minimum log level
 * @param {number} [options.limit] - Max entries to return
 * @param {string} [options.search] - Text search
 * @returns {Array} Filtered log entries
 */
export const getLogs = (options = {}) => {
  let results = [...logStorage];
  
  if (options.level) {
    const minLevel = LOG_LEVELS[options.level] || LOG_LEVELS.INFO;
    results = results.filter(entry => LOG_LEVELS[entry.level] <= minLevel);
  }
  
  if (options.search) {
    const searchTerm = options.search.toLowerCase();
    results = results.filter(entry => 
      entry.message.toLowerCase().includes(searchTerm) ||
      (entry.data && JSON.stringify(entry.data).toLowerCase().includes(searchTerm))
    );
  }
  
  if (options.limit) {
    results = results.slice(-options.limit);
  }
  
  return results;
};

/**
 * Clear all logs
 */
export const clearLogs = () => {
  logStorage = [];
  sequenceId = 0;
  
  if (config.persist && config.extensionStorage) {
    config.extensionStorage.remove(['appLogs', 'logSequence']);
  }
  
  info('Logs cleared');
};

// ----------------------------- PERFORMANCE LOGGING -----------------------------

const perfMetrics = new Map();

/**
 * Start performance timer
 * @param {string} name - Timer name
 */
export const time = (name) => {
  if (LOG_LEVELS.DEBUG > config.level) return;
  perfMetrics.set(name, {
    start: performance.now(),
    memory: window.performance?.memory?.usedJSHeapSize
  });
};

/**
 * End performance timer and log results
 * @param {string} name - Timer name
 */
export const timeEnd = (name) => {
  if (LOG_LEVELS.DEBUG > config.level) return;
  
  const metric = perfMetrics.get(name);
  if (!metric) return;
  
  const duration = performance.now() - metric.start;
  let memoryUsage = '';
  
  if (window.performance?.memory) {
    const endMemory = window.performance.memory.usedJSHeapSize;
    const diff = endMemory - metric.memory;
    memoryUsage = ` | Memory: ${formatBytes(metric.memory)} → ${formatBytes(endMemory)} (${diff >= 0 ? '+' : ''}${formatBytes(diff)})`;
  }
  
  debug(`⏱️ ${name} - ${duration.toFixed(2)}ms${memoryUsage}`);
  perfMetrics.delete(name);
};

/**
 * Format bytes for display
 * @param {number} bytes 
 * @returns {string}
 */
const formatBytes = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  if (!bytes) return 'N/A';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

// ----------------------------- ERROR HANDLING -----------------------------

/**
 * Wrapper for error boundary logging
 * @param {Function} fn - Function to wrap
 * @param {string} context - Context for error messages
 * @returns {*} Function result
 */
export const withErrorLogging = (fn, context) => {
  return (...args) => {
    try {
      return fn(...args);
    } catch (error) {
      error(`Error in ${context}`, { 
        error: error.message,
        stack: error.stack,
        arguments: args 
      });
      throw error;
    }
  };
};

// ----------------------------- EXPORT ALL UTILITIES -----------------------------

export default {
  LOG_LEVELS,
  LOG_COLORS,
  initLogger,
  setLogLevel,
  setLogPersistence,
  error,
  warn,
  info,
  debug,
  trace,
  getLogs,
  clearLogs,
  time,
  timeEnd,
  withErrorLogging
};