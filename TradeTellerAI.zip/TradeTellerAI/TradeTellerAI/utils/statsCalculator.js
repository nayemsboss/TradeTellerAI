// utils/statsCalculator.js
/**
 * TradeTellerAI - Advanced Statistical Calculations for Trading
 * Contains statistical methods for market data analysis
 */

import { calculateSMA, calculateStandardDeviation } from './tradingMath';

// ----------------------------- CORE STATISTICS -----------------------------

/**
 * Calculates probability distribution for price movements
 * @param {Array<number>} priceChanges - Array of price changes
 * @param {number} [bins=20] - Number of distribution bins
 * @returns {Object} {bins, frequencies, mean, stdDev}
 */
export const calculatePriceDistribution = (priceChanges, bins = 20) => {
  if (!priceChanges.length) return null;

  const min = Math.min(...priceChanges);
  const max = Math.max(...priceChanges);
  const range = max - min;
  const binSize = range / bins;

  const distribution = Array(bins).fill(0);
  const binRanges = Array(bins).fill().map((_, i) => ({
    from: min + (i * binSize),
    to: min + ((i + 1) * binSize)
  }));

  priceChanges.forEach(change => {
    let binIndex = Math.floor((change - min) / binSize);
    binIndex = Math.min(binIndex, bins - 1); // Handle max value
    distribution[binIndex]++;
  });

  const frequencies = distribution.map(count => count / priceChanges.length);
  const mean = priceChanges.reduce((sum, val) => sum + val, 0) / priceChanges.length;
  const stdDev = calculateStandardDeviation(priceChanges, mean);

  return {
    bins: binRanges,
    frequencies,
    mean,
    stdDev,
    binSize
  };
};

/**
 * Calculates correlation coefficient between two datasets
 * @param {Array<number>} x - First dataset
 * @param {Array<number>} y - Second dataset
 * @returns {number} Pearson correlation coefficient (-1 to 1)
 */
export const calculateCorrelation = (x, y) => {
  if (x.length !== y.length || x.length < 2) return 0;

  const n = x.length;
  const sumX = x.reduce((a, b) => a + b, 0);
  const sumY = y.reduce((a, b) => a + b, 0);
  const sumXY = x.reduce((a, val, i) => a + val * y[i], 0);
  const sumX2 = x.reduce((a, b) => a + b * b, 0);
  const sumY2 = y.reduce((a, b) => a + b * b, 0);

  const numerator = sumXY - (sumX * sumY / n);
  const denominator = Math.sqrt(
    (sumX2 - (sumX * sumX / n)) * 
    (sumY2 - (sumY * sumY / n))
  );

  return denominator === 0 ? 0 : numerator / denominator;
};

// ----------------------------- TRADING STATISTICS -----------------------------

/**
 * Calculates drawdown statistics
 * @param {Array<number>} equityCurve - Array of account balance values
 * @returns {Object} {maxDrawdown, maxDrawdownPct, drawdownDuration}
 */
export const calculateDrawdown = (equityCurve) => {
  if (!equityCurve.length) return null;

  let peak = equityCurve[0];
  let maxDrawdown = 0;
  let maxDrawdownPct = 0;
  let currentDrawdownDuration = 0;
  let maxDrawdownDuration = 0;

  equityCurve.forEach((value, index) => {
    if (value > peak) {
      peak = value;
      currentDrawdownDuration = 0;
    } else {
      const drawdown = peak - value;
      const drawdownPct = (drawdown / peak) * 100;
      
      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown;
        maxDrawdownPct = drawdownPct;
      }

      currentDrawdownDuration++;
      if (currentDrawdownDuration > maxDrawdownDuration) {
        maxDrawdownDuration = currentDrawdownDuration;
      }
    }
  });

  return {
    maxDrawdown,
    maxDrawdownPct,
    drawdownDuration: maxDrawdownDuration
  };
};

/**
 * Calculates Sharpe ratio for strategy performance
 * @param {Array<number>} returns - Array of daily returns
 * @param {number} [riskFreeRate=0] - Risk-free rate (default 0)
 * @returns {number} Sharpe ratio
 */
export const calculateSharpeRatio = (returns, riskFreeRate = 0) => {
  if (!returns.length) return 0;

  const excessReturns = returns.map(r => r - riskFreeRate);
  const meanReturn = excessReturns.reduce((sum, val) => sum + val, 0) / returns.length;
  const stdDev = calculateStandardDeviation(excessReturns, meanReturn);

  return stdDev === 0 ? 0 : meanReturn / stdDev * Math.sqrt(252); // Annualized
};

/**
 * Calculates Sortino ratio for strategy performance
 * @param {Array<number>} returns - Array of daily returns
 * @param {number} [minAcceptableReturn=0] - Minimum acceptable return
 * @returns {number} Sortino ratio
 */
export const calculateSortinoRatio = (returns, minAcceptableReturn = 0) => {
  if (!returns.length) return 0;

  const downsideReturns = returns
    .map(r => r - minAcceptableReturn)
    .filter(r => r < 0);
  
  if (!downsideReturns.length) return Infinity;

  const meanReturn = returns.reduce((sum, val) => sum + val, 0) / returns.length;
  const downsideStdDev = calculateStandardDeviation(downsideReturns);

  return downsideStdDev === 0 ? 0 : (meanReturn - minAcceptableReturn) / downsideStdDev * Math.sqrt(252);
};

// ----------------------------- PROBABILITY CALCULATIONS -----------------------------

/**
 * Calculates win rate and profit factor
 * @param {Array<Object>} trades - Array of trade objects {profit}
 * @returns {Object} {winRate, profitFactor, avgWin, avgLoss}
 */
export const calculateTradeStats = (trades) => {
  if (!trades.length) return null;

  const winningTrades = trades.filter(t => t.profit > 0);
  const losingTrades = trades.filter(t => t.profit <= 0);
  
  const winRate = winningTrades.length / trades.length;
  const grossProfit = winningTrades.reduce((sum, t) => sum + t.profit, 0);
  const grossLoss = Math.abs(losingTrades.reduce((sum, t) => sum + t.profit, 0));
  
  return {
    winRate,
    profitFactor: grossLoss === 0 ? Infinity : grossProfit / grossLoss,
    avgWin: winningTrades.length ? grossProfit / winningTrades.length : 0,
    avgLoss: losingTrades.length ? grossLoss / losingTrades.length : 0
  };
};

/**
 * Calculates expected value of a trading strategy
 * @param {number} winRate - Probability of winning (0-1)
 * @param {number} avgWin - Average winning trade amount
 * @param {number} avgLoss - Average losing trade amount
 * @returns {number} Expected value per trade
 */
export const calculateExpectedValue = (winRate, avgWin, avgLoss) => {
  return (winRate * avgWin) - ((1 - winRate) * avgLoss);
};

/**
 * Calculates Kelly criterion position sizing
 * @param {number} winProb - Probability of winning (0-1)
 * @param {number} winLossRatio - Ratio of avg win to avg loss
 * @returns {number} Fraction of capital to risk (0-1)
 */
export const calculateKellyCriterion = (winProb, winLossRatio) => {
  return winProb - ((1 - winProb) / winLossRatio);
};

// ----------------------------- TIME SERIES ANALYSIS -----------------------------

/**
 * Calculates rolling statistics for a time series
 * @param {Array<number>} series - Input time series
 * @param {number} window - Rolling window size
 * @returns {Object} {means, stdDevs, min, max}
 */
export const calculateRollingStatistics = (series, window) => {
  if (series.length < window) return null;

  const means = [];
  const stdDevs = [];
  const mins = [];
  const maxs = [];

  for (let i = window - 1; i < series.length; i++) {
    const windowSlice = series.slice(i - window + 1, i + 1);
    const mean = calculateSMA(windowSlice, window)[0];
    const stdDev = calculateStandardDeviation(windowSlice, mean);
    
    means.push(mean);
    stdDevs.push(stdDev);
    mins.push(Math.min(...windowSlice));
    maxs.push(Math.max(...windowSlice));
  }

  return { means, stdDevs, mins, maxs };
};

/**
 * Detects regime changes in market data
 * @param {Array<number>} prices - Price series
 * @param {number} [window=20] - Lookback window
 * @param {number} [threshold=2] - Std dev threshold for change
 * @returns {Array<Object>} Array of change points {index, type, confidence}
 */
export const detectRegimeChanges = (prices, window = 20, threshold = 2) => {
  if (prices.length < window * 2) return [];

  const changes = [];
  const returns = [];
  
  // Calculate returns
  for (let i = 1; i < prices.length; i++) {
    returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
  }

  // Analyze rolling windows
  for (let i = window; i < returns.length; i++) {
    const prevWindow = returns.slice(i - window, i);
    const currentWindow = returns.slice(i, i + window);
    
    if (currentWindow.length < window) break;
    
    const prevMean = prevWindow.reduce((sum, val) => sum + val, 0) / window;
    const currentMean = currentWindow.reduce((sum, val) => sum + val, 0) / window;
    
    const pooledStdDev = Math.sqrt(
      (prevWindow.reduce((sum, val) => sum + Math.pow(val - prevMean, 2), 0) +
      currentWindow.reduce((sum, val) => sum + Math.pow(val - currentMean, 2), 0)
    ) / (window * 2 - 2));

    const tValue = pooledStdDev === 0 ? 0 : 
      (currentMean - prevMean) / (pooledStdDev * Math.sqrt(2 / window));
    
    if (Math.abs(tValue) > threshold) {
      changes.push({
        index: i,
        type: tValue > 0 ? 'bullish' : 'bearish',
        confidence: Math.min(1, Math.abs(tValue) / 3),
        priceAtChange: prices[i]
      });
      i += window; // Skip ahead to avoid overlapping changes
    }
  }

  return changes;
};

// ----------------------------- VOLATILITY MEASURES -----------------------------

/**
 * Calculates historical volatility (annualized)
 * @param {Array<number>} prices - Price series
 * @param {number} [window=20] - Lookback window
 * @param {number} [periodsPerYear=252] - Trading periods per year
 * @returns {Array<number>} Volatility values
 */
export const calculateHistoricalVolatility = (prices, window = 20, periodsPerYear = 252) => {
  if (prices.length < window + 1) return [];

  const volatilities = [];
  const logReturns = [];

  // Calculate log returns
  for (let i = 1; i < prices.length; i++) {
    logReturns.push(Math.log(prices[i] / prices[i - 1]));
  }

  // Calculate rolling volatility
  for (let i = window - 1; i < logReturns.length; i++) {
    const windowSlice = logReturns.slice(i - window + 1, i + 1);
    const mean = windowSlice.reduce((sum, val) => sum + val, 0) / window;
    const variance = windowSlice.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / window;
    const stdDev = Math.sqrt(variance);
    volatilities.push(stdDev * Math.sqrt(periodsPerYear));
  }

  return volatilities;
};

/**
 * Calculates average true range (ATR)
 * @param {Array<Object>} candles - Array of {high, low, close}
 * @param {number} [window=14] - Smoothing window
 * @returns {Array<number>} ATR values
 */
export const calculateATR = (candles, window = 14) => {
  if (candles.length < window + 1) return [];

  const trueRanges = [];
  for (let i = 1; i < candles.length; i++) {
    const prevClose = candles[i - 1].close;
    const currentHigh = candles[i].high;
    const currentLow = candles[i].low;
    
    const tr = Math.max(
      currentHigh - currentLow,
      Math.abs(currentHigh - prevClose),
      Math.abs(currentLow - prevClose)
    );
    trueRanges.push(tr);
  }

  // Initial ATR is SMA of first window TRs
  const atrValues = [calculateSMA(trueRanges.slice(0, window), window)[0]];

  // Subsequent ATRs use smoothing formula
  for (let i = window; i < trueRanges.length; i++) {
    const atr = (atrValues[atrValues.length - 1] * (window - 1) + trueRanges[i]) / window;
    atrValues.push(atr);
  }

  return atrValues;
};

// ----------------------------- EXPORT ALL UTILITIES -----------------------------

export default {
  calculatePriceDistribution,
  calculateCorrelation,
  calculateDrawdown,
  calculateSharpeRatio,
  calculateSortinoRatio,
  calculateTradeStats,
  calculateExpectedValue,
  calculateKellyCriterion,
  calculateRollingStatistics,
  detectRegimeChanges,
  calculateHistoricalVolatility,
  calculateATR
};