// utils/tradingMath.js
/**
 * TradeTellerAI - Advanced Trading Mathematics Utilities
 * Contains all core mathematical operations for technical analysis
 */

// ----------------------------- CORE CALCULATIONS -----------------------------

/**
 * Calculates Relative Strength Index (RSI)
 * @param {Array<number>} prices - Array of closing prices
 * @param {number} [period=14] - Lookback period (default 14)
 * @returns {Array<number>} RSI values array
 */
export const calculateRSI = (prices, period = 14) => {
  if (prices.length < period + 1) {
    throw new Error(`Insufficient data. Need at least ${period + 1} prices for RSI(${period})`);
  }

  const deltas = [];
  for (let i = 1; i < prices.length; i++) {
    deltas.push(prices[i] - prices[i - 1]);
  }

  let gains = [];
  let losses = [];
  
  // Initial average calculations
  let avgGain = 0;
  let avgLoss = 0;
  
  for (let i = 0; i < period; i++) {
    if (deltas[i] >= 0) {
      avgGain += deltas[i];
    } else {
      avgLoss += Math.abs(deltas[i]);
    }
  }
  
  avgGain /= period;
  avgLoss /= period;
  
  const rsiValues = [];
  const firstRS = avgLoss === 0 ? 100 : 100 - (100 / (1 + (avgGain / avgLoss)));
  rsiValues.push(firstRS);
  
  // Subsequent calculations
  for (let i = period; i < deltas.length; i++) {
    const currentDelta = deltas[i];
    let currentGain = 0;
    let currentLoss = 0;
    
    if (currentDelta >= 0) {
      currentGain = currentDelta;
    } else {
      currentLoss = Math.abs(currentDelta);
    }
    
    // Smoothed averages
    avgGain = ((avgGain * (period - 1)) + currentGain) / period;
    avgLoss = ((avgLoss * (period - 1)) + currentLoss) / period;
    
    const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    const rsi = 100 - (100 / (1 + rs));
    rsiValues.push(rsi);
  }
  
  return rsiValues;
};

/**
 * Calculates Moving Average Convergence Divergence (MACD)
 * @param {Array<number>} prices - Array of closing prices
 * @param {number} [fastPeriod=12] - Fast EMA period
 * @param {number} [slowPeriod=26] - Slow EMA period
 * @param {number} [signalPeriod=9] - Signal line period
 * @returns {Object} {macdLine, signalLine, histogram}
 */
export const calculateMACD = (prices, fastPeriod = 12, slowPeriod = 26, signalPeriod = 9) => {
  if (prices.length < slowPeriod + signalPeriod) {
    throw new Error(`Insufficient data. Need at least ${slowPeriod + signalPeriod} prices`);
  }

  const fastEMA = calculateEMA(prices, fastPeriod);
  const slowEMA = calculateEMA(prices, slowPeriod);
  
  // MACD Line = Fast EMA - Slow EMA
  const macdLine = [];
  for (let i = slowPeriod - fastPeriod; i < slowEMA.length; i++) {
    macdLine.push(fastEMA[i + (fastPeriod - 1)] - slowEMA[i]);
  }
  
  // Signal Line = EMA of MACD Line
  const signalLine = calculateEMA(macdLine, signalPeriod);
  
  // Histogram = MACD Line - Signal Line
  const histogram = [];
  for (let i = signalPeriod - 1; i < macdLine.length; i++) {
    histogram.push(macdLine[i] - signalLine[i - (signalPeriod - 1)]);
  }
  
  return {
    macdLine: macdLine.slice(signalPeriod - 1),
    signalLine,
    histogram
  };
};

/**
 * Calculates Exponential Moving Average (EMA)
 * @param {Array<number>} prices - Price data
 * @param {number} period - EMA period
 * @returns {Array<number>} EMA values
 */
export const calculateEMA = (prices, period) => {
  if (prices.length < period) {
    throw new Error(`Insufficient data. Need at least ${period} prices for EMA(${period})`);
  }

  const multiplier = 2 / (period + 1);
  const emaValues = [];
  
  // Start with SMA as initial EMA
  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += prices[i];
  }
  emaValues.push(sum / period);
  
  // Calculate subsequent EMAs
  for (let i = period; i < prices.length; i++) {
    const ema = (prices[i] - emaValues[i - period]) * multiplier + emaValues[i - period];
    emaValues.push(ema);
  }
  
  return emaValues;
};

// ----------------------------- SUPPORT CALCULATIONS -----------------------------

/**
 * Calculates Standard Deviation
 * @param {Array<number>} values 
 * @param {number} mean 
 * @returns {number} Standard deviation
 */
export const calculateStandardDeviation = (values, mean) => {
  const squareDiffs = values.map(val => {
    const diff = val - mean;
    return diff * diff;
  });
  
  const avgSquareDiff = squareDiffs.reduce((sum, val) => sum + val, 0) / values.length;
  return Math.sqrt(avgSquareDiff);
};

/**
 * Calculates Bollinger Bands
 * @param {Array<number>} prices 
 * @param {number} period 
 * @param {number} multiplier 
 * @returns {Object} {upperBand, middleBand, lowerBand}
 */
export const calculateBollingerBands = (prices, period = 20, multiplier = 2) => {
  const middleBand = calculateSMA(prices, period);
  const upperBand = [];
  const lowerBand = [];
  
  for (let i = period - 1; i < prices.length; i++) {
    const slice = prices.slice(i - period + 1, i + 1);
    const mean = middleBand[i - (period - 1)];
    const stdDev = calculateStandardDeviation(slice, mean);
    
    upperBand.push(mean + (stdDev * multiplier));
    lowerBand.push(mean - (stdDev * multiplier));
  }
  
  return { upperBand, middleBand, lowerBand };
};

/**
 * Calculates Simple Moving Average (SMA)
 * @param {Array<number>} prices 
 * @param {number} period 
 * @returns {Array<number>} SMA values
 */
export const calculateSMA = (prices, period) => {
  if (prices.length < period) {
    throw new Error(`Insufficient data. Need at least ${period} prices for SMA(${period})`);
  }

  const smaValues = [];
  for (let i = period - 1; i < prices.length; i++) {
    const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
    smaValues.push(sum / period);
  }
  return smaValues;
};

// ----------------------------- CANDLE PATTERN HELPERS -----------------------------

/**
 * Detects candle patterns in price data
 * @param {Array<Object>} candles - Array of candle objects {open, high, low, close}
 * @returns {Array<Object>} Array of detected patterns
 */
export const detectCandlePatterns = (candles) => {
  const patterns = [];
  
  for (let i = 1; i < candles.length; i++) {
    const current = candles[i];
    const previous = candles[i - 1];
    
    // Hammer detection
    if (isHammer(current)) {
      patterns.push({
        index: i,
        type: 'hammer',
        direction: 'bullish',
        confidence: calculateHammerConfidence(current)
      });
    }
    
    // Engulfing pattern detection
    if (isEngulfing(previous, current)) {
      patterns.push({
        index: i,
        type: 'engulfing',
        direction: current.close > current.open ? 'bullish' : 'bearish',
        confidence: calculateEngulfingConfidence(previous, current)
      });
    }
    
    // Doji detection
    if (isDoji(current)) {
      patterns.push({
        index: i,
        type: 'doji',
        direction: 'neutral',
        confidence: calculateDojiConfidence(current)
      });
    }
  }
  
  return patterns;
};

/**
 * Checks if candle is a Hammer pattern
 */
const isHammer = (candle) => {
  const bodySize = Math.abs(candle.close - candle.open);
  const lowerShadow = candle.open > candle.close 
    ? candle.close - candle.low 
    : candle.open - candle.low;
  const upperShadow = candle.high - Math.max(candle.open, candle.close);
  
  return lowerShadow >= 2 * bodySize && 
         upperShadow <= 0.1 * bodySize &&
         bodySize > 0;
};

/**
 * Checks if two candles form an Engulfing pattern
 */
const isEngulfing = (prevCandle, currentCandle) => {
  const prevBody = Math.abs(prevCandle.close - prevCandle.open);
  const currentBody = Math.abs(currentCandle.close - currentCandle.open);
  
  return currentBody > prevBody && 
         ((currentCandle.close > prevCandle.open && currentCandle.open < prevCandle.close) ||
          (currentCandle.close < prevCandle.open && currentCandle.open > prevCandle.close));
};

/**
 * Checks if candle is a Doji pattern
 */
const isDoji = (candle) => {
  const bodySize = Math.abs(candle.close - candle.open);
  const range = candle.high - candle.low;
  
  return bodySize <= range * 0.05 && range > 0;
};

// ----------------------------- CONFIDENCE CALCULATORS -----------------------------

const calculateHammerConfidence = (candle) => {
  const bodySize = Math.abs(candle.close - candle.open);
  const lowerShadow = Math.min(candle.open, candle.close) - candle.low;
  const ratio = lowerShadow / bodySize;
  
  return Math.min(1, ratio / 2).toFixed(2);
};

const calculateEngulfingConfidence = (prevCandle, currentCandle) => {
  const prevBody = Math.abs(prevCandle.close - prevCandle.open);
  const currentBody = Math.abs(currentCandle.close - currentCandle.open);
  
  return Math.min(1, currentBody / (prevBody * 1.5)).toFixed(2);
};

const calculateDojiConfidence = (candle) => {
  const bodySize = Math.abs(candle.close - candle.open);
  const range = candle.high - candle.low;
  
  return (1 - (bodySize / (range + 0.0001))).toFixed(2);
};

// ----------------------------- VOLUME ANALYSIS -----------------------------

/**
 * Calculates Volume Weighted Average Price (VWAP)
 * @param {Array<Object>} data - Array of {high, low, close, volume}
 * @returns {Array<number>} VWAP values
 */
export const calculateVWAP = (data) => {
  if (!data.length) return [];
  
  const vwapValues = [];
  let cumulativePV = 0;
  let cumulativeVolume = 0;
  
  data.forEach((bar) => {
    const typicalPrice = (bar.high + bar.low + bar.close) / 3;
    cumulativePV += typicalPrice * bar.volume;
    cumulativeVolume += bar.volume;
    vwapValues.push(cumulativePV / cumulativeVolume);
  });
  
  return vwapValues;
};

/**
 * Calculates On-Balance Volume (OBV)
 * @param {Array<Object>} data - Array of {close, volume}
 * @returns {Array<number>} OBV values
 */
export const calculateOBV = (data) => {
  if (!data.length) return [];
  
  const obvValues = [data[0].volume];
  
  for (let i = 1; i < data.length; i++) {
    const currentClose = data[i].close;
    const prevClose = data[i - 1].close;
    
    if (currentClose > prevClose) {
      obvValues.push(obvValues[i - 1] + data[i].volume);
    } else if (currentClose < prevClose) {
      obvValues.push(obvValues[i - 1] - data[i].volume);
    } else {
      obvValues.push(obvValues[i - 1]);
    }
  }
  
  return obvValues;
};

// ----------------------------- RISK CALCULATIONS -----------------------------

/**
 * Calculates Position Size based on risk parameters
 * @param {number} accountSize - Total account balance
 * @param {number} riskPercent - Risk percentage per trade (1-100)
 * @param {number} entryPrice - Entry price
 * @param {number} stopLossPrice - Stop loss price
 * @returns {number} Position size in units
 */
export const calculatePositionSize = (accountSize, riskPercent, entryPrice, stopLossPrice) => {
  const riskAmount = accountSize * (riskPercent / 100);
  const riskPerUnit = Math.abs(entryPrice - stopLossPrice);
  return riskAmount / riskPerUnit;
};

/**
 * Calculates Risk-Reward Ratio
 * @param {number} entryPrice 
 * @param {number} stopLoss 
 * @param {number} takeProfit 
 * @returns {number} Risk-reward ratio
 */
export const calculateRiskRewardRatio = (entryPrice, stopLoss, takeProfit) => {
  const risk = Math.abs(entryPrice - stopLoss);
  const reward = Math.abs(takeProfit - entryPrice);
  return reward / risk;
};

// ----------------------------- EXPORT ALL UTILITIES -----------------------------

export default {
  calculateRSI,
  calculateMACD,
  calculateEMA,
  calculateSMA,
  calculateBollingerBands,
  calculateStandardDeviation,
  detectCandlePatterns,
  calculateVWAP,
  calculateOBV,
  calculatePositionSize,
  calculateRiskRewardRatio
};