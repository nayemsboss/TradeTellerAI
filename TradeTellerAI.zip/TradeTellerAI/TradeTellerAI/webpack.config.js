const path = require('path');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const { WebpackManifestPlugin } = require('webpack-manifest-plugin');
const TerserPlugin = require('terser-webpack-plugin');
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

const isProduction = process.env.NODE_ENV === 'production';
const isAnalyze = process.env.ANALYZE === 'true';

module.exports = {
  mode: isProduction ? 'production' : 'development',
  devtool: isProduction ? 'source-map' : 'cheap-module-source-map',
  entry: {
    background: './background/scheduler.js',
    content: './content/injectScripts.js',
    popup: './popup/popup.js',
    dashboard: './ui/dashboard.js'
  },
  output: {
    filename: '[name].bundle.js',
    path: path.resolve(__dirname, 'dist'),
    publicPath: '',
    assetModuleFilename: 'assets/[hash][ext][query]'
  },
  optimization: {
    minimize: isProduction,
    minimizer: [
      new TerserPlugin({
        parallel: true,
        terserOptions: {
          ecma: 2020,
          compress: {
            drop_console: isProduction,
            passes: 2
          },
          format: {
            comments: false
          }
        },
        extractComments: false
      })
    ],
    splitChunks: {
      chunks: 'all',
      cacheGroups: {
        vendors: {
          test: /[\\/]node_modules[\\/]/,
          priority: -10,
          reuseExistingChunk: true
        },
        tfjs: {
          test: /[\\/]node_modules[\\/]@tensorflow[\\/]/,
          name: 'tfjs',
          chunks: 'all',
          priority: -5
        },
        default: {
          minChunks: 2,
          priority: -20,
          reuseExistingChunk: true
        }
      }
    }
  },
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules\/(?!(lit-html|@tensorflow)\/).*/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: [
              '@babel/preset-env',
              ['@babel/preset-react', { runtime: 'automatic' }]
            ],
            plugins: [
              '@babel/plugin-transform-runtime',
              '@babel/plugin-proposal-class-properties'
            ]
          }
        }
      },
      {
        test: /\.(scss|css)$/,
        use: [
          MiniCssExtractPlugin.loader,
          {
            loader: 'css-loader',
            options: {
              modules: {
                auto: true,
                localIdentName: isProduction 
                  ? '[hash:base64]' 
                  : '[path][name]__[local]'
              },
              sourceMap: !isProduction
            }
          },
          {
            loader: 'postcss-loader',
            options: {
              postcssOptions: {
                plugins: [
                  require('autoprefixer'),
                  require('postcss-combine-media-query'),
                  require('cssnano')({
                    preset: 'default'
                  })
                ]
              }
            }
          },
          'sass-loader'
        ]
      },
      {
        test: /\.(png|jpe?g|gif|svg)$/i,
        type: 'asset/resource',
        generator: {
          filename: 'assets/images/[hash][ext][query]'
        }
      },
      {
        test: /\.(woff|woff2|eot|ttf|otf)$/i,
        type: 'asset/resource',
        generator: {
          filename: 'assets/fonts/[hash][ext][query]'
        }
      },
      {
        test: /\.(mp3|wav)$/i,
        type: 'asset/resource',
        generator: {
          filename: 'assets/sounds/[hash][ext][query]'
        }
      },
      {
        test: /\.(json)$/,
        type: 'javascript/auto',
        use: [
          {
            loader: 'file-loader',
            options: {
              name: '[name].[ext]',
              outputPath: 'models/'
            }
          }
        ]
      }
    ]
  },
  plugins: [
    new CleanWebpackPlugin(),
    new CopyWebpackPlugin({
      patterns: [
        {
          from: '**/*',
          to: '.',
          context: 'public',
          globOptions: {
            ignore: ['**/*.js', '**/*.html', '**/*.scss']
          }
        },
        {
          from: 'manifest.json',
          to: '.',
          transform(content) {
            const manifest = JSON.parse(content.toString());
            if (isProduction) {
              manifest.version = process.env.npm_package_version;
            }
            return Buffer.from(JSON.stringify(manifest, null, 2));
          }
        },
        {
          from: 'assets/icons/*.png',
          to: 'assets/icons/[name][ext]'
        },
        {
          from: 'ai/models/**/*.json',
          to: 'models/[name][ext]'
        },
        {
          from: 'ai/models/**/*.bin',
          to: 'models/[name][ext]'
        }
      ]
    }),
    new HtmlWebpackPlugin({
      template: './popup/popup.html',
      filename: 'popup.html',
      chunks: ['popup'],
      minify: isProduction
    }),
    new HtmlWebpackPlugin({
      template: './ui/dashboard.html',
      filename: 'dashboard.html',
      chunks: ['dashboard'],
      minify: isProduction
    }),
    new MiniCssExtractPlugin({
      filename: 'css/[name].[contenthash].css',
      chunkFilename: 'css/[id].[contenthash].css'
    }),
    new WebpackManifestPlugin({
      fileName: 'asset-manifest.json',
      publicPath: '',
      generate: (seed, files) => ({
        files: files.reduce((manifest, { name, path }) => ({
          ...manifest,
          [name]: path
        }), seed)
      })
    }),
    ...(isAnalyze ? [new BundleAnalyzerPlugin()] : [])
  ],
  resolve: {
    extensions: ['.js', '.jsx', '.json'],
    alias: {
      '@components': path.resolve(__dirname, 'ui/components'),
      '@utils': path.resolve(__dirname, 'utils'),
      '@services': path.resolve(__dirname, 'services'),
      '@assets': path.resolve(__dirname, 'assets')
    },
    fallback: {
      'crypto': false,
      'stream': false,
      'path': false
    }
  },
  performance: {
    hints: isProduction ? 'warning' : false,
    maxAssetSize: 1 * 1024 * 1024, // 1MB
    maxEntrypointSize: 2 * 1024 * 1024 // 2MB
  },
  stats: {
    children: true,
    modules: false,
    chunks: false,
    chunkModules: false
  }
};